#!/usr/bin/python														   #
# -*- coding: utf-8 -*-													   #

#############################=IMPORTS=######################################
	#Kodi Specific
import sys
PY3 = sys.version_info[0] == 3
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
	#Python Specific
import base64,gzip,io,os,re,time,sys,urllib.request
import urllib.parse,urllib.error,json,datetime,shutil
import xml.dom.minidom
import xml.etree.ElementTree as ET
from xml.dom.minidom import Node
from datetime import datetime,timedelta
	#Addon Specific
from resources.modules import control,tools,popup,speedtest
if PY3:
	from urllib.parse import quote, quote_plus, unquote_plus, unquote, urlparse	
else:
	from urllib import quote, quote_plus, unquote_plus, unquote
	from urlparse import urlparse
##########################=VARIABLES=#######################################
ADDON = xbmcaddon.Addon()
ADDONPATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo('id')

DIALOG			  = xbmcgui.Dialog()
DP				  = xbmcgui.DialogProgress()
HOME			  = xbmcvfs.translatePath('special://home/')
ADDONS			  = os.path.join(HOME,	   'addons')
USERDATA		  = os.path.join(HOME,	   'userdata')
PLUGIN			  = os.path.join(ADDONS,   ADDON_ID)
PACKAGES		  = os.path.join(ADDONS,   'packages')
ADDONDATA		  = os.path.join(USERDATA, 'addon_data', ADDON_ID)
ADVANCED		  = os.path.join(USERDATA,	'advancedsettings.xml')
advanced_settings = os.path.join(PLUGIN,'resources', 'advanced_settings')
MEDIA			  = os.path.join(ADDONS,  PLUGIN , 'resources', 'media')
KODIV			  = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
M3U_PATH		  = os.path.join(ADDONDATA,  'm3u.m3u')
##########################=ART PATHS=#######################################
icon			  = os.path.join(PLUGIN,  'icon-blue153.png')
fanart			  = os.path.join(PLUGIN,  'fanart.jpg')
background		  = os.path.join(MEDIA,   'background.jpg')
live			  = os.path.join(MEDIA,   'live.jpg')
catch			  = os.path.join(MEDIA,   'cu.jpg')
Moviesod		  = os.path.join(MEDIA,   'movie.jpg')
Tvseries		  = os.path.join(MEDIA,   'tv.jpg')
iconextras		  = os.path.join(MEDIA,   'iconextras-blue153.png')
iconsettings	  = os.path.join(MEDIA,   'iconsettings-blue153.png')
iconlive		  = os.path.join(MEDIA,   'iconlive-blue153.png')
iconcatchup		  = os.path.join(MEDIA,   'iconcatchup-blue153.png')
iconMoviesod	  = os.path.join(MEDIA,   'iconmovies-blue153.png')
iconTvseries	  = os.path.join(MEDIA,   'icontvseries-blue153.png')
iconsearch		  = os.path.join(MEDIA,   'iconsearch-blue153.png')
iconaccount		  = os.path.join(MEDIA,   'iconaccount-blue153.png')
icontvguide		  = os.path.join(MEDIA,   'iconguide-blue153.png')

#########################=XC VARIABLES=#####################################
dns				  = control.setting('DNS')
username		  = control.setting('Username')
password		  = control.setting('Password')
dns_unblock		  = control.setting('dns_unblock')
live_url = '{0}/player_api.php?username={1}&password={2}&action=get_live_categories'.format(dns, username, password)
vod_url = '{0}/player_api.php?username={1}&password={2}&action=get_vod_categories'.format(dns, username, password)
series_url = '{0}/player_api.php?username={1}&password={2}&action=get_series_categories'.format(dns, username, password)
panel_api		  = '{0}/panel_api.php?username={1}&password={2}'.format(dns,username,password)
player_api		  = '{0}/player_api.php?username={1}&password={2}'.format(dns,username,password)
play_url		  = '{0}/live/{1}/{2}/'.format(dns,username,password)
play_live		  = '{0}/{1}/{2}/'.format(dns,username,password)
play_movies		  = '{0}/movie/{1}/{2}/'.format(dns,username,password)
play_series		  = '{0}/series/{1}/{2}/'.format(dns,username,password)
#############################################################################
adult_tags = ['xxx','xXx','XXX','adult','Adult','ADULT','adults','Adults','ADULTS','porn','Porn','PORN']
_metadata_cache = None

def _metadata_cache_data():
	global _metadata_cache
	if _metadata_cache is not None:
		return _metadata_cache
	_metadata_cache = {}
	path = os.path.join(ADDONDATA, 'metadata_cache.json')
	try:
		if os.path.exists(path) and time.time() - os.path.getmtime(path) < 604800:
			with open(path, 'r', encoding='utf-8') as source:
				_metadata_cache = json.load(source)
	except:
		_metadata_cache = {}
	return _metadata_cache

def _save_metadata_cache():
	try:
		if not os.path.exists(ADDONDATA):
			os.makedirs(ADDONDATA)
		with open(os.path.join(ADDONDATA, 'metadata_cache.json'), 'w', encoding='utf-8') as output:
			json.dump(_metadata_cache, output, ensure_ascii=False)
	except Exception as exc:
		xbmc.log('[%s] Metadata cache write failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)

def _year(value):
	match = re.search(r'(19|20)\d{2}', str(value or ''))
	return match.group(0) if match else '0'

def _metadata_for(item, media_type):
	name = str(item.get('name') or item.get('title') or '')
	meta = {
		'title': name,
		'plot': item.get('plot') or '',
		'year': _year(item.get('releaseDate') or item.get('releasedate') or item.get('year')),
		'cast': item.get('cast') or '',
		'rating': item.get('rating') or item.get('rating_5based') or '0',
		'runtime': item.get('duration_secs') or '0',
		'genre': item.get('genre') or '',
		'poster': item.get('stream_icon') or item.get('cover') or icon,
	}
	if meta['runtime'] == '0' and item.get('episode_run_time'):
		try:
			meta['runtime'] = str(int(float(item.get('episode_run_time'))) * 60)
		except:
			pass
	if control.setting('meta') != 'true':
		return meta
	api_key = control.setting('omdb_api_key').strip()
	if not api_key:
		return meta
	cache = _metadata_cache_data()
	cache_key = '%s|%s|%s' % (media_type, name.lower(), meta['year'])
	remote = cache.get(cache_key)
	if remote is None:
		params = {'apikey': api_key, 'plot': 'full', 'type': media_type}
		imdb_id = item.get('imdb_id') or item.get('imdb')
		if imdb_id and str(imdb_id).startswith('tt'):
			params['i'] = str(imdb_id)
		else:
			params['t'] = name
			if meta['year'] != '0':
				params['y'] = meta['year']
		try:
			request = urllib.request.Request('https://www.omdbapi.com/?' + urllib.parse.urlencode(params), headers={'User-Agent': 'Kodi OTB'})
			with urllib.request.urlopen(request, timeout=8) as response:
				remote = json.loads(response.read().decode('utf-8'))
			if remote.get('Response') != 'True':
				remote = {}
		except Exception as exc:
			xbmc.log('[%s] OMDb lookup failed for %s: %s' % (ADDON_ID, name, exc), xbmc.LOGWARNING)
			remote = {}
		cache[cache_key] = remote
		_save_metadata_cache()
	if remote:
		meta.update({
			'plot': remote.get('Plot') if remote.get('Plot') != 'N/A' else meta['plot'],
			'year': _year(remote.get('Year')) or meta['year'],
			'cast': remote.get('Actors') if remote.get('Actors') != 'N/A' else meta['cast'],
			'rating': remote.get('imdbRating') if remote.get('imdbRating') != 'N/A' else meta['rating'],
			'runtime': str(int(re.sub(r'\D', '', remote.get('Runtime', ''))) * 60) if re.sub(r'\D', '', remote.get('Runtime', '')) else meta['runtime'],
			'genre': remote.get('Genre') if remote.get('Genre') != 'N/A' else meta['genre'],
			'poster': remote.get('Poster') if remote.get('Poster') != 'N/A' else meta['poster'],
		})
	return meta

def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    intbase = int(baseversion[0])
    return intbase

def buildcleanurl(url):
	url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
	return url

def start(signin):
	if username == "":
		dns = tools.keypopup('Enter DNS eg: http://dns.com')
		usern = tools.keypopup('Enter Username')
		passw = tools.keypopup('Enter Password')
		control.setSetting('DNS',dns)
		control.setSetting('Username',usern)
		control.setSetting('Password',passw)
		xbmc.executebuiltin('Container.Refresh')
		auth_url = '{0}/player_api.php?username={1}&password={2}'.format(dns,usern,passw)
		parse = tools.OPEN_URL(auth_url)
		
		login_data = parse['user_info']['auth']
		if login_data == 0:
			line1 = "Incorrect Login Details"
			line2 = "Please Re-enter" 
			line3 = "" 
			xbmcgui.Dialog().ok('Attention', line1+'\n'+line2+'\n'+line3)
			start()
		else:
			line1 = "Login successful!"
			line2 = "Welcome to"+ADDON_NAME
			line3 = ('[B][COLOR white]%s[/COLOR][/B]'%usern)
			xbmcgui.Dialog().ok(ADDON_NAME, line1+'\n' + line2 +'\n' + line3)
			adult_set()
			tvguidesetup()
			addonsettings('ADS2','')
			xbmc.executebuiltin('Container.Refresh')
			home()
	else:
		home()

def home():
	tools.addDir('Account Information','url',6,iconaccount,background,'')
	tools.addDir('Live TV','live',1,iconlive,background,'')
	tools.addDir('TV Guide','pvr',7,icontvguide,background,'')
	tools.addDir('Catch-up TV','url',12,iconcatchup,background,'')
	tools.addDir('TV Shows','live',18,iconTvseries,background,'')
	tools.addDir('Movies','vod',3,iconMoviesod,background,'')
	# tools.addDir('Pesquisa','url',5,iconsearch,background,'')
	tools.addDir('Settings','url',8,iconsettings,background,'')
	tools.addDir('Extras','url',16,iconextras,background,'')

def livecategory():
    vod_cat = tools.OPEN_URL(live_url)
    for cat in vod_cat:
        mystring = cat['category_name'] 
        if xbmcaddon.Addon().getSetting('hidexxx')=='false':
            tools.addDir(mystring,player_api + '&action=get_live_streams&category_id=' + str(cat['category_id']), 2, icon, background, '')
        else :
            if not any(s in name for s in adult_tags):
                tools.addDir(mystring,player_api + '&action=get_live_streams&category_id=' + str(cat['category_id']), 2, icon,background, '')

def _xmltv_time(value):
    value = (value or '').strip()
    for pattern in ('%Y%m%d%H%M%S %z', '%Y%m%d%H%M%S', '%Y%m%d%H%M %z', '%Y%m%d%H%M'):
        try:
            parsed = datetime.strptime(value, pattern)
            if parsed.tzinfo:
                parsed = parsed.astimezone().replace(tzinfo=None)
            return parsed
        except (TypeError, ValueError):
            pass
    return None

def _xmltv_file():
    custom = control.setting('pvr_epg_url').strip()
    epg_url = custom or '{0}/xmltv.php?username={1}&password={2}'.format(
        dns.rstrip('/'), quote(username, safe=''), quote(password, safe=''))
    if not epg_url or (not custom and not dns):
        return None
    if not os.path.exists(ADDONDATA):
        os.makedirs(ADDONDATA)
    cache = os.path.join(ADDONDATA, 'xmltv.xml')
    if os.path.exists(cache) and time.time() - os.path.getmtime(cache) < 900:
        return cache
    try:
        request = urllib.request.Request(epg_url, headers={'User-Agent': 'Kodi OTB/%s' % ADDON.getAddonInfo('version')})
        response = urllib.request.urlopen(request, timeout=25)
        data = response.read()
        if data[:2] == b'\x1f\x8b':
            data = gzip.GzipFile(fileobj=io.BytesIO(data)).read()
        temp = cache + '.tmp'
        with open(temp, 'wb') as output:
            output.write(data)
        os.replace(temp, cache)
        return cache
    except Exception as exc:
        xbmc.log('[%s] XMLTV download failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
        return cache if os.path.exists(cache) else None

def _xmltv_now_next(channel_ids):
    if control.setting('show_now_next') != 'true':
        return {}
    guide_file = _xmltv_file()
    if not guide_file:
        return {}
    wanted = set(str(item).strip().lower() for item in channel_ids if item)
    programmes = {}
    now = datetime.now()
    try:
        for event, element in ET.iterparse(guide_file, events=('end',)):
            if element.tag.rsplit('}', 1)[-1] != 'programme':
                continue
            channel_id = (element.get('channel') or '').strip().lower()
            if channel_id in wanted:
                start_time = _xmltv_time(element.get('start'))
                stop_time = _xmltv_time(element.get('stop'))
                if start_time and stop_time and stop_time > now:
                    title_node = element.find('title')
                    desc_node = element.find('desc')
                    item = {
                        'start': start_time,
                        'stop': stop_time,
                        'title': title_node.text.strip() if title_node is not None and title_node.text else 'Programme',
                        'desc': desc_node.text.strip() if desc_node is not None and desc_node.text else ''
                    }
                    programmes.setdefault(channel_id, []).append(item)
            element.clear()
    except Exception as exc:
        xbmc.log('[%s] XMLTV parse failed: %s' % (ADDON_ID, exc), xbmc.LOGWARNING)
        return {}
    result = {}
    for channel_id, items in programmes.items():
        items.sort(key=lambda item: item['start'])
        current = next((item for item in items if item['start'] <= now < item['stop']), None)
        upcoming = next((item for item in items if item['start'] >= (current['stop'] if current else now)), None)
        result[channel_id] = (current, upcoming)
    return result

def _channel_guide(channel, guide):
    channel_id = str(channel.get('epg_channel_id') or '').strip().lower()
    current, upcoming = guide.get(channel_id, (None, None))
    label = channel.get('name', 'Channel')
    details = []
    if current:
        label += '  [COLOR lime]Now: %s[/COLOR]' % current['title']
        details.append('[B]Now · %s–%s[/B]  %s\n%s' % (
            current['start'].strftime('%H:%M'), current['stop'].strftime('%H:%M'), current['title'], current['desc']))
    if upcoming:
        label += '  [COLOR gray]Next: %s[/COLOR]' % upcoming['title']
        details.append('[B]Next · %s–%s[/B]  %s\n%s' % (
            upcoming['start'].strftime('%H:%M'), upcoming['stop'].strftime('%H:%M'), upcoming['title'], upcoming['desc']))
    return label, '\n\n'.join(details)

def Livelist(url):
    vod_cat = tools.OPEN_URL(url)
    guide = _xmltv_now_next([cat.get('epg_channel_id') for cat in vod_cat])
    background = os.path.join(MEDIA, 'background.jpg')
    for cat in vod_cat:
        url = play_live + str(cat['stream_id'])
        try:
         thumb = cat['stream_icon']
        except:
         thumb =  icon
        
        display_name, description = _channel_guide(cat, guide)
        if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
            tools.addDir(display_name, url, 4, str(thumb), background, description)
        else:
            if not any(s in cat.get('name', '') for s in adult_tags):
                tools.addDir(display_name, url, 4, str(thumb), background, description)

def series_cats(url):
	vod_cat = tools.OPEN_URL(player_api+'&action=get_series_categories')
	
	for cat in vod_cat:
		if xbmcaddon.Addon().getSetting('hidexxx')=='false':
			tools.addDir(cat['category_name'],player_api+'&action=get_series&category_id='+str(cat['category_id']),25,icon,background,'')
		else:
			if not any(s in name for s in adult_tags):
				tools.addDir(cat['category_name'],player_api+'&action=get_series&category_id='+str(cat['category_id']),25,icon,background,'')

# categoria series
def serieslist(url): 
    ser_cat = tools.OPEN_URL(url)
    for ser in ser_cat:
        name = ser.get('name', 'TV Show')
        url = player_api + '&action=get_series_info&series_id=' + str(ser['series_id'])
        meta = _metadata_for(ser, 'series')
        backdrop = ''
        try:
            backdrop = ser.get('backdrop_path', [''])[0]
        except:
            pass
        backdrop = backdrop or os.path.join(MEDIA, 'background.jpg')
        if xbmcaddon.Addon().getSetting('meta') == 'true':
            tools.addDirMeta(name, url, 19, str(meta['poster']), backdrop, meta['plot'], meta['year'], meta['cast'],
                             meta['rating'], meta['runtime'], meta['genre'])
        else:
            tools.addDir(name, url, 19, str(meta['poster']), backdrop, meta['plot'])

def series_seasons(url):
    ser_cat = tools.OPEN_URL(url)
    if not 'episodes'  in ser_cat:
        return
    for ser in ser_cat['episodes']:
        info = ser_cat['info']
        try:
            thumb = info['cover']
        except:
            thumb = ''
        try:
            background = info['backdrop_path'][0]
        except:
            background = ''
        if not background.strip():
            background = os.path.join(MEDIA, 'background.jpg')    
        tools.addDir('Season - ' + ser, url + '&season_number=' + str(ser), 20, str(thumb), background, '')

# listar seasons        
def season_list(url):
    tools.log(url)
    ser_cat = tools.OPEN_URL(url)
    
    info = ser_cat['info']
    ser_cat = ser_cat['episodes']
    
    from urllib.parse import urlparse, parse_qs
    parsed_url = urlparse(url)
    season_number = str(parse_qs(parsed_url.query)['season_number'][0])
    if not 'releaseDate'  in ser_cat[season_number]:  
        cont = 0
    else: 
        cont = 1 
    for ser in ser_cat[season_number]:
        url = play_series + str(ser['id']) + '.' + ser['container_extension']
        try:
            thumb = ser['info']['movie_image']
        except:
            thumb = ''
        try:
            background = ser['info']['movie_image']
        except:
            background = ''
        try:
            plot = ser['info']['plot']
        except:
            plot = ''
        try:
            releasedate = ser['info']['releasedate']
        except:
            releasedate = ''
        try:
            cast = str(info['cast']).split()
        except:
            cast = ('', '')
        try:
            rating_5based = info['rating_5based']
        except:
            rating_5based = ''
        try:
            duration = str(ser['info']['duration'])
        except:
            duration = ''
        try:
            genre = info['genre']
        except:
            genre = ''
        if not background:
            background = os.path.join(MEDIA, 'background.jpg')
        if cont == 0:
            releasedate = '2022-01-01'
        if xbmcaddon.Addon().getSetting('meta') == 'true':
            tools.log(cast)
            tools.addDirMeta(ser['title'], url, 4, str(thumb), background, plot, str(releasedate), cast, rating_5based, duration,
                             genre)
        else:
            tools.addDir(ser['title'], url, 4, str(thumb), background, '')	

def Vodlist(url):
        vod_cat = tools.OPEN_URL(url)
        background = os.path.join(MEDIA, 'background.jpg')
        for cat in vod_cat:
            meta = _metadata_for(cat, 'movie')
            thumb = meta['poster']
            url = play_movies + str(cat['stream_id'])+'.' + cat['container_extension']
            if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
                if xbmcaddon.Addon().getSetting('meta') == 'true':
                    tools.addDirMeta(str(cat['name']), url, 4, str(thumb), background, meta['plot'], meta['year'],
                                     meta['cast'], meta['rating'], meta['runtime'], meta['genre'])
                else:
                    tools.addDir(str(cat['name']), url, 4, str(thumb), background, meta['plot'])
            else:
                if not any(s in cat.get('name', '') for s in adult_tags):
                    if xbmcaddon.Addon().getSetting('meta') == 'true':
                        tools.addDirMeta(str(cat['name']), url, 4, str(thumb), background, meta['plot'], meta['year'],
                                         meta['cast'], meta['rating'], meta['runtime'], meta['genre'])
                    else:
                        tools.addDir(str(cat['name']), url, 4, str(thumb), background, meta['plot'])
def vod(url):
    vod_cat = tools.OPEN_URL(vod_url)
    
   
    for cat in vod_cat:
        mystring = cat['category_name'] 
        if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
            tools.addDir(mystring,
                         player_api + '&action=get_vod_streams&category_id=' + str(cat['category_id']), 9, icon,
                         background, '')
        else:
            if not any(s in name for s in adult_tags):
                tools.addDir(mystring,
                             player_api + '&action=get_vod_streams&category_id=' + str(cat['category_id']), 9, icon,
                             background, '')


def search():
	if mode==3:
		return False
	text = searchdialog()
	xbmc.log(str(text))
	parse = tools.OPEN_URL(panel_api)
	
	all_chans = tools.regex_get_all(open,'{"num":','}')
	for a in all_chans:
		name = tools.regex_from_to(a,'name":"','"')
		url	 = tools.regex_from_to(a,'"stream_id":"','"')
		thumb= tools.regex_from_to(a,'stream_icon":"','"').replace('\\/','/')
		stream_type = tools.regex_from_to(a,'"stream_type":"','"').replace('\\/','/')
		container_extension = tools.regex_from_to(a,'container_extension":"','"')
		if text in name.lower():
			if xbmcaddon.Addon().getSetting('hidexxx')=='false':
				if 'movie' in stream_type:
					tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
				if 'live' in stream_type:
					tools.addDir(name,play_live+url,4,thumb,background,'')
			else:
				if not any(s in name for s in adult_tags):
					if 'movie' in stream_type:
						tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
					if 'live' in stream_type:
						tools.addDir(name,play_live+url,4,thumb,background,'')
		elif text not in name.lower() and text in name:
			if xbmcaddon.Addon().getSetting('hidexxx')=='false':
				if 'movie' in stream_type:
					tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
				if 'live' in stream_type:
					tools.addDir(name,play_live+url,4,thumb,background,'')
			else:
				if not any(s in name for s in adult_tags):
					if 'movie' in stream_type:
						tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
					if 'live' in stream_type:
						tools.addDir(name,play_live+url,4,thumb,background,'')
def catchup():
    listcatchup()
        
def listcatchup():
    channels = tools.OPEN_URL(player_api + '&action=get_live_streams')
    for channel in channels:
        if str(channel.get('tv_archive', '0')) not in ('1', 'true', 'True'):
            continue
        name = channel.get('name') or channel.get('epg_channel_id') or 'Catch-up channel'
        thumb = channel.get('stream_icon') or iconcatchup
        stream_id = str(channel.get('stream_id', ''))
        if stream_id:
            tools.addDir(name, 'url', 13, thumb, fanart, stream_id)

def tvarchive(name,description):
	APIv2 = "{0}/player_api.php?username={1}&password={2}&action=get_simple_data_table&stream_id={3}".format(dns,username,password,description)
	data = tools.OPEN_URL(APIv2)
	
	for streams in data['epg_listings']:
		if not streams['has_archive']:
			continue
		if not streams['start']:
			continue
		try:
			name = base64.b64decode(streams.get('title', '')).decode('UTF-8')
		except:
			name = streams.get('title', 'Programme')
		stream_id = streams['id']
		try:
			plot = base64.b64decode(streams.get('description', '')).decode('UTF-8')
		except:
			plot = streams.get('description', '')
		start = streams['start']
		end = streams['end']
		format = '%Y-%m-%d %H:%M:%S'
		start_obj = datetime(*(time.strptime(start, format)[0:6]))
		end_obj = datetime(*(time.strptime(end, format)[0:6]))
		start_api_obj = start_obj.strftime('%Y-%m-%d:%H-%M')
		end_api_obj = end_obj.strftime('%Y-%m-%d:%H-%M')
		difference = end_obj - start_obj
		duration = difference.total_seconds()
		duration = round(duration / 60)
		start2 = start[:-3]
		editstart = start2
		start2 = str(start2).replace(' ',' - ')
		catchupURL = "{0}/streaming/timeshift.php?username={1}&password={2}&stream={3}&start=".format(dns,username,password,description)
		ResultURL = catchupURL + str(start_api_obj) + "&duration={0}".format(duration)
		Fname = "[B][COLOR white]{0}[/COLOR][/B] - {1}".format(start2,name)
		tools.addDir(Fname,ResultURL,4,iconcatchup,background,plot)

#############################

def tvguide():
		xbmc.executebuiltin('ActivateWindow(TVGuide)')

# converter
		
def basename(p):
	"""Returns the final component of a pathname"""
	i = p.rfind('/') + 1
	return p[i:]  		

def ts_to_m3u8(url):
	try:
		url = unquote_plus(url)
	except:
		pass
	try:
		url = unquote(url)
	except:
		pass        
	if '|' in url:
		url = url.split('|')[0]
	elif '%7C' in url:
		url = url.split('%7C')[0]
	if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
		parsed_url = urlparse(url)
		try:
			host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
			host_part2 = url.split(host_part1)[1]
			url = host_part1 + '/live' + host_part2
			file = basename(url)
			if '.ts' in file:
				file_new = file.replace('.ts', '.m3u8')
				url = url.replace(file, file_new)
			else:
				url = url + '.m3u8'
				# file_new = file + '.m3u8'
				# new_url = url.replace(file, file_new)
		except:
			pass
	return url 

# player
def stream_video(url,iconimage):
	if not iconimage:
		try:
			iconimage = xbmc.getInfoLabel('ListItem.Thumb')
		except:
			try:
				iconimage = xbmc.getInfoLabel('ListItem.Icon')
			except:
				iconimage = ''  	
	if iconimage:
		icon = iconimage
	else:
		icon = ''
	url = buildcleanurl(url)	
	headers = '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'
	#url = url + headers
	try:
		name = xbmc.getInfoLabel('ListItem.Label')
	except:
		name = ''
	description = ''
	if not '.mp4' in url and not '.avi' in url and not '.rmv' in url and not 'rmvb' in url:
		check = True
	else:
		check = False
	if dns_unblock == 'true' and check == True:		
		name = 'XCUI' if not name else name
		url = ts_to_m3u8(url)
		url = url + headers
		if '.m3u8' in url and not 'plugin' in url:
			import hlsretry
			url = 'http://%s:%s/?url=%s'%(str(hlsretry.HOST_NAME),str(hlsretry.PORT_NUMBER),quote(url))
			hlsretry.XtreamProxy().start()	
			liz = xbmcgui.ListItem(name)
			liz.setArt({'icon':icon, 'thumb':icon})
			if get_kversion() > 19:
				info = liz.getVideoInfoTag()
				info.setTitle(name)
				info.setMediaType('video')
				info.setPlot(description)
			else:
				liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
			#liz.setProperty('IsPlayable','true')
			liz.setPath(str(url))
			xbmc.Player().play(item=url, listitem=liz)						
		else:
			url = url + headers
			liz = xbmcgui.ListItem(name)
			liz.setArt({'icon':icon, 'thumb':icon})
			if get_kversion() > 19:
				info = liz.getVideoInfoTag()
				info.setTitle(name)
				info.setMediaType('video')
				info.setPlot(description)
			else:
				liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
			#liz.setProperty('IsPlayable','true')
			liz.setPath(str(url))
			xbmc.Player().play(item=url, listitem=liz)
	elif dns_unblock == 'true' and check == False:
		name = 'XCUI' if not name else name
		import mp4retry
		url = 'http://%s:%s/?url=%s'%(str(mp4retry.HOST_NAME),str(mp4retry.PORT_NUMBER),quote(url))
		mp4retry.XtreamProxy().start()	
		liz = xbmcgui.ListItem(name)
		liz.setArt({'icon':icon, 'thumb':icon})
		if get_kversion() > 19:
			info = liz.getVideoInfoTag()
			info.setTitle(name)
			info.setMediaType('video')
			info.setPlot(description)
		else:
			liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
		#liz.setProperty('IsPlayable','true')
		liz.setPath(str(url))
		xbmc.Player().play(item=url, listitem=liz)			

	else:
		url = url + headers
		liz = xbmcgui.ListItem(name)
		liz.setArt({'icon':icon, 'thumb':icon})
		if get_kversion() > 19:
			info = liz.getVideoInfoTag()
			info.setTitle(name)
			info.setMediaType('video')
			info.setPlot(description)
		else:
			liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
		if not dns_unblock == 'true':
			liz.setProperty('IsPlayable','true')
		liz.setPath(str(url))
		if not dns_unblock == 'true':
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		else:
			xbmc.Player().play(item=url, listitem=liz)

def searchdialog():
	search = control.inputDialog(heading='Search '+ADDON_NAME+':')
	if search=="":
		return
	else:
		return search


### alterar settings
def settingsmenu():
	if xbmcaddon.Addon().getSetting('meta')=='true':
		META = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		META = '[B][COLOR red]OFF[/COLOR][/B]'
	if xbmcaddon.Addon().getSetting('hidexxx')=='true':
		xxx = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		xxx = '[B][COLOR red]OFF[/COLOR][/B]'
	# if xbmcaddon.Addon().getSetting('f4m')=='true':
	# 	f4m_ = '[B][COLOR lime]ON[/COLOR][/B]'
	# else:
	# 	f4m_ = '[B][COLOR red]OFF[/COLOR][/B]'	
	if xbmcaddon.Addon().getSetting('dns_unblock')=='true':
		unblock = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		unblock = '[B][COLOR red]OFF[/COLOR][/B]'				
	tools.addDir('Configure OTB / IPTV Simple','AS',10,iconsettings,background,'')
	tools.addDir('Apply IPTV Simple Settings Now','PVR_APPLY',10,icontvguide,background,'')
	tools.addDir('Open TV Guide','PVR_GUIDE',10,icontvguide,background,'')
	#tools.addDir('Edit Advanced Settings','ADS',10,icon,background,'')
	tools.addDir('DNS UNBLOCK is %s'%unblock,'DNS_UNBLOCK',10,icon,background,unblock)		
	tools.addDir('META is %s'%META,'META',10,icon,background,META)
	tools.addDir('Hide Adult Content is %s'%xxx,'XXX',10,icon,background,xxx)
	tools.addDir('Log Out','LO',10,icon,background,'')

def addonsettings(url,description):
	url	 = buildcleanurl(url)
	if	 url =="clearcache":
		tools.clear_cache()
	elif url =="AS":
		xbmc.executebuiltin('Addon.OpenSettings(%s)'% ADDON_ID)
	elif url =="ADS":
		dialog = xbmcgui.Dialog().select('Edit Advanced Settings', ['Open AutoConfig','Enable Fire TV Stick AS','Enable Fire TV AS','Enable 1GB Ram or Lower AS','Enable 2GB Ram or Higher AS','Enable Nvidia Shield AS','Disable AS'])
		if dialog==0:
			advancedsettings('auto')
		elif dialog==1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog==2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog==3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog==4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog==5:
			advancedsettings('shield')
			tools.ASln()
		elif dialog==6:
			advancedsettings('remove')
			xbmcgui.Dialog().ok(ADDON_NAME, 'Advanced Settings Removed')
	elif url =="ADS2":
		dialog = xbmcgui.Dialog().select('Select Your Device Or Closest To', ['Open AutoConfig','Fire TV Stick ','Fire TV','1GB Ram or Lower','2GB Ram or Higher','Nvidia Shield'])
		if dialog==0:
			advancedsettings('auto')
			tools.ASln()
		elif dialog==1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog==2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog==3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog==4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog==5:
			advancedsettings('shield')
			tools.ASln()
	elif url =="tv":
		dialog = xbmcgui.Dialog().yesno(ADDON_NAME,'Would You like us to Setup the TV Guide for You?')
		if dialog:
			pvrsetup()
			xbmcgui.Dialog().ok(ADDON_NAME, 'PVR Integration Complete, Restart Kodi For Changes To Take Effect')
	elif url =="Itv":
		xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')
	elif url =="PVR_APPLY":
		from pvr_setup import configure
		configure(notify=True)
	elif url =="PVR_GUIDE":
		xbmc.executebuiltin('ActivateWindow(TVGuide)')
	elif url =="ST":
		speedtest.speedtest()
	elif url =="DNS_UNBLOCK":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('dns_unblock','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('dns_unblock','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url =="META":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('meta','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('meta','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url =="XXX":
		if 'ON' in description:
			pas = tools.keypopup('Enter Adult Password:')
			if pas ==control.setting('xxx_pw'):
				xbmcaddon.Addon().setSetting('hidexxx','false')
				xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('hidexxx','true')
			xbmc.executebuiltin('Container.Refresh')		
	elif url =="LO":
		xbmcaddon.Addon().setSetting('DNS','')
		xbmcaddon.Addon().setSetting('Username','')
		xbmcaddon.Addon().setSetting('Password','')
		xbmc.executebuiltin('XBMC.ActivateWindow(Videos,addons://sources/video/)')
		xbmc.executebuiltin('Container.Refresh')
	elif url =="UPDATE":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('update','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('update','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url == "RefM3U":
		DP.create(ADDON_NAME, "Please Wait")
		tools.gen_m3u(panel_api, M3U_PATH)
	elif url == "TEST":
		tester()

def adult_set():
	dialog = DIALOG.yesno(ADDON_NAME,'Would you like to hide the Adult Menu? \nYou can always change this in settings later on.')
	if dialog:
		control.setSetting('xxx_pwset','true')
		pass
	else:
		control.setSetting('xxx_pwset','false')
		pass
	dialog = DIALOG.yesno(ADDON_NAME,'Would you like to Password Protect Adult Content? \nYou can always change this in settings later on.')
	if dialog:
		control.setSetting('xxx_pwset','true')
		adultpw = tools.keypopup('Enter Password')
		control.setSetting('xxx_pw',adultpw)
	else:
		control.setSetting('xxx_pwset','false')
		pass

def advancedsettings(device):
	if device == 'stick':
		file = open(os.path.join(advanced_settings, 'stick.xml'))
	elif device =='auto':
		popup.autoConfigQ()
	elif device == 'firetv':
		file = open(os.path.join(advanced_settings, 'firetv.xml'))
	elif device == 'lessthan':
		file = open(os.path.join(advanced_settings, 'lessthan1GB.xml'))
	elif device == 'morethan':
		file = open(os.path.join(advanced_settings, 'morethan1GB.xml'))
	elif device == 'shield':
		file = open(os.path.join(advanced_settings, 'shield.xml'))
	elif device == 'remove':
		os.remove(ADVANCED)
	try:
		read = file.read()
		f = open(ADVANCED, mode='w+')
		f.write(read)
		f.close()
	except:
		pass

def accountinfo():
	# try:
	# 	parse = tools.OPEN_URL(panel_api)
	# except:
	# 	parse = tools.OPEN_URL(player_api)
	try:
		parse = tools.OPEN_URL(player_api)
	except:
		parse = tools.OPEN_URL(panel_api)

	
	expiry	   = parse['user_info']['exp_date']
	if not expiry=="":
		expiry	   = datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
		expreg	   = re.compile('^(.*?)/(.*?)/(.*?)$',re.DOTALL).findall(expiry)
		for day,month,year in expreg:
			month	  = tools.MonthNumToName(month)
			year	  = re.sub(' -.*?$','',year)
			expiry	  = month+' '+day+' - '+year
			# expiry	  = day+' de '+month+' de '+year
	else:
		expiry = 'Unlimited'
	max_connection = str(parse['user_info']['max_connections'])
	if max_connection == 'None':
		max_connection = 'Unlimited'
	status = parse['user_info']['status']
	if status == 'Active':
		status = 'Active'
	elif status == 'Trial':
		status = 'Test'
	tools.addDir('[B][COLOR white]Username :[/COLOR][/B] '+parse['user_info']['username'],'','',icon,background,'')
	tools.addDir('[B][COLOR white]Password :[/COLOR][/B] '+parse['user_info']['password'],'','',icon,background,'')
	tools.addDir('[B][COLOR white]Expiry Date:[/COLOR][/B] '+expiry,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Account Status :[/COLOR][/B] %s'%status,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Current Connections:[/COLOR][/B] '+ str(parse['user_info']['active_cons']),'','',icon,background,'')
	tools.addDir('[B][COLOR white]Allowed Connections:[/COLOR][/B] '+ max_connection,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Local IP Address:[/COLOR][/B] '+ tools.getlocalip(),'','',icon,background,'')
	tools.addDir('[B][COLOR white]External IP Address:[/COLOR][/B] '+ tools.getexternalip(),'','',icon,background,'')
	tools.addDir('[B][COLOR white]Kodi Version:[/COLOR][/B] '+str(KODIV),'','',icon,background,'')

def waitasec(time_to_wait,title,text):
	FTGcd = xbmcgui.DialogProgress()
	ret = FTGcd.create(' '+title)
	secs=0
	percent=0
	increment = int(100 / time_to_wait)
	cancelled = False
	while secs < time_to_wait:
		secs += 1
		percent = increment*secs
		secs_left = str((time_to_wait - secs))
		remaining_display = "Still " + str(secs_left) + "seconds left"
		FTGcd.update(percent,text+'\n'+remaining_display)
		xbmc.sleep(1000)
		if (FTGcd.iscanceled()):
			cancelled = True
			break
	if cancelled == True:
		return False
	else:
		FTGcd.close()
		return False

def tester():
	FTG = ''

def pvrsetup():
    from pvr_setup import configure
    return configure(notify=True)

def correctPVR():
    return pvrsetup()

def tvguidesetup():
    return pvrsetup()

def num2day(num):
	if num =="0":
		day = 'monday'
	elif num=="1":
		day = 'tuesday'
	elif num=="2":
		day = 'wednesday'
	elif num=="3":
		day = 'thursday'
	elif num=="4":
		day = 'friday'
	elif num=="5":
		day = 'saturday'
	elif num=="6":
		day = 'sunday'
	return day
	
def extras():
	tools.addDir('Run a Speed Test','ST',10,icon,background,'')
	# try:
		# if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
			# tools.addDir('Setup PVR Guide','tv',10,icon,background,'')
		# if not xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
			# tools.addDir('Install PVR Guide','Itv',10,icon,background,'')
		# if os.path.exists(M3U_PATH):
			# tools.addDir('Refresh M3U','RefM3U',10,icon,background,'')
	# except:pass
	tools.addDir('Clear Cache','clearcache',10,icon,background,'')
	#tools.addDir('Tester','TEST',10,icon,background,'')

params=tools.get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None

try:
	url=urllib.parse.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.parse.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
	iconimage = ''
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.parse.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.parse.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.parse.unquote_plus(params["type"])
except:
	pass

if mode==None or url==None or len(url)<1:
	start('false')

elif mode==1:
	livecategory()
	
elif mode==2:
	Livelist(url)
	
elif mode==3:
	vod(url)
	
elif mode==4:
	#stream_video(url)
	stream_video(url,iconimage)
	
elif mode==5:
	search()
	
elif mode==6:
	accountinfo()
	
elif mode==7:
	tvguide()
	
elif mode==8:
	settingsmenu()
	
elif mode == 9:
    Vodlist(url)	
    
elif mode==10:
	addonsettings(url,description)
	
elif mode==11:
	pvrsetup()
	
elif mode==12:
	catchup()

elif mode==13:
	tvarchive(name,description)
	
elif mode==14:
	listcatchup2()
	
# elif mode==15:
# 	ivueint()
	
elif mode==16:
	extras()
	
elif mode==18:
	series_cats(url)

elif mode==25:
	serieslist(url)
	
elif mode==19:
	series_seasons(url)

elif mode==20:
	season_list(url)

# elif mode=='start':
# 	start(signin)

elif mode=='test':
	tester()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
