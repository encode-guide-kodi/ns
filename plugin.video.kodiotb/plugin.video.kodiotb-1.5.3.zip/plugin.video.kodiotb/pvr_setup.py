# -*- coding: utf-8 -*-
"""Configure and enable Kodi's IPTV Simple client from OTB settings."""

import json
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote


ADDON_ID = "plugin.video.kodiotb"
PVR_ID = "pvr.iptvsimple"


def _rpc(method, params):
    request = {"jsonrpc": "2.0", "method": method, "params": params, "id": 1}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as exc:
        xbmc.log("[%s] JSON-RPC error: %s" % (ADDON_ID, exc), xbmc.LOGERROR)
        return {}


def _set_enabled(enabled):
    result = _rpc("Addons.SetAddonEnabled", {"addonid": PVR_ID, "enabled": enabled})
    return "error" not in result


def _urls(settings):
    custom_m3u = settings.getSetting("pvr_playlist_url").strip()
    custom_epg = settings.getSetting("pvr_epg_url").strip()
    server = settings.getSetting("DNS").strip().rstrip("/")
    username = settings.getSetting("Username").strip()
    password = settings.getSetting("Password").strip()

    if custom_m3u:
        m3u_url = custom_m3u
    elif server and username and password:
        output = "m3u8" if settings.getSetting("pvr_output") == "1" else "ts"
        m3u_url = "%s/get.php?username=%s&password=%s&type=m3u_plus&output=%s" % (
            server, quote(username, safe=""), quote(password, safe=""), output)
    else:
        m3u_url = ""

    if custom_epg:
        epg_url = custom_epg
    elif server and username and password:
        epg_url = "%s/xmltv.php?username=%s&password=%s" % (
            server, quote(username, safe=""), quote(password, safe=""))
    else:
        epg_url = ""
    return m3u_url, epg_url


def _read_vfs(path):
    handle = xbmcvfs.File(path)
    try:
        return handle.read()
    finally:
        handle.close()


def _instance_name(path):
    try:
        root = ET.fromstring(_read_vfs(path))
        for item in root.findall("setting"):
            if item.get("id") == "kodi_addon_instance_name":
                return item.text or ""
    except Exception:
        pass
    return ""


def _write_instance(settings, m3u_url, epg_url):
    """Create/update this add-on's own IPTV Simple configuration instance."""
    profile = xbmcvfs.translatePath("special://profile/addon_data/%s/" % PVR_ID)
    xbmcvfs.mkdirs(profile)
    folders, files = xbmcvfs.listdir(profile)
    del folders

    config_name = settings.getSetting("pvr_configuration_name").strip() or "OTB Kodi"
    instance_files = [name for name in files if name.startswith("instance-settings-") and name.endswith(".xml")]
    target = ""
    used_numbers = []
    for filename in instance_files:
        try:
            used_numbers.append(int(filename[len("instance-settings-"):-4]))
        except ValueError:
            pass
        path = profile + filename
        if _instance_name(path) == config_name:
            target = path
            break

    if not target:
        number = 1
        while number in used_numbers:
            number += 1
        target = profile + "instance-settings-%d.xml" % number

    values = [
        ("kodi_addon_instance_name", config_name),
        ("m3uPathType", "1"),
        ("m3uUrl", m3u_url),
        ("m3uCache", "true" if settings.getSetting("pvr_cache") == "true" else "false"),
        ("epgPathType", "1"),
        ("epgUrl", epg_url),
        ("epgCache", "true" if settings.getSetting("pvr_cache") == "true" else "false"),
        ("catchupEnabled", "true" if settings.getSetting("pvr_catchup") == "true" else "false"),
        ("catchupDays", settings.getSetting("pvr_catchup_days") or "5"),
        ("catchupOnlyOnFinishedProgrammes", "false"),
    ]
    body = [u'<?xml version="1.0" encoding="utf-8" standalone="yes"?>', u'<settings version="2">']
    for setting_id, value in values:
        body.append(u'    <setting id="%s">%s</setting>' % (setting_id, escape(value)))
    body.append(u'</settings>')
    handle = xbmcvfs.File(target, "w")
    try:
        handle.write(u"\n".join(body))
    finally:
        handle.close()
    return target


def configure(notify=False):
    settings = xbmcaddon.Addon(ADDON_ID)
    if settings.getSetting("pvr_auto_config") == "true":
        m3u_url, epg_url = _urls(settings)
        if not m3u_url:
            if notify:
                xbmcgui.Dialog().ok("OTB Kodi", "Enter your server, username and password, or provide a custom M3U URL first.")
            return False
        if not epg_url:
            if notify:
                xbmcgui.Dialog().ok("OTB Kodi", "Enter the XMLTV URL before creating the IPTV Simple configuration.")
            return False
        try:
            _write_instance(settings, m3u_url, epg_url)
        except Exception as exc:
            xbmc.log("[%s] IPTV Simple configuration failed: %s" % (ADDON_ID, exc), xbmc.LOGERROR)
            if notify:
                xbmcgui.Dialog().ok("OTB Kodi", "IPTV Simple playlist settings could not be saved.")
            return False

    if notify:
        xbmcgui.Dialog().ok("OTB Kodi", "Settings saved. Close and reopen Kodi normally to load them. If IPTV Simple is disabled, enable it from My add-ons > PVR clients first.")
    return True



if __name__ == "__main__":
    configure(notify=True)
