"""Automatic PVR configuration disabled to avoid interrupting client startup."""
