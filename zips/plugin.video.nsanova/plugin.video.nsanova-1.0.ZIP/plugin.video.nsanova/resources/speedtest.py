import xbmcgui
import time
import socket
from urllib.request import urlopen, Request
from urllib.parse import urlparse

DOWNLOAD_TEST_URL = "http://speedtest.tele2.net/10MB.zip"

PING_LOCATIONS = [
    "http://m3u.sstv.one",
    "http://s1.ix.tc",
    "http://s2.ix.tc",
    "http://s3.ix.tc",
]

def test_download_speed_with_progress(url, progress):
    try:
        request = Request(url)
        with urlopen(request, timeout=10) as response:
            total_size = int(response.getheader("Content-Length", 0))
            downloaded_size = 0
            start_time = time.time()

            while chunk := response.read(1024 * 1024): 
                downloaded_size += len(chunk)
                elapsed_time = time.time() - start_time
                speed_mbps = (downloaded_size * 8) / elapsed_time / 1e6
                percent_complete = int((downloaded_size / total_size) * 100)

                progress.update(percent_complete, f"Download Speed: {speed_mbps:.2f} Mbps\n"
                                                  f"Progress: {percent_complete}%")
                
                if progress.iscanceled():
                    return 0

            return (downloaded_size * 8) / elapsed_time / 1e6
    except Exception as e:
        xbmcgui.Dialog().notification("Download Error", f"Failed to test download: {e}", xbmcgui.NOTIFICATION_ERROR)
        return 0

def test_latency(url):
    try:
        parsed_url = urlparse(url)
        host = parsed_url.netloc or parsed_url.path.split('/')[0]
        port = 80 if parsed_url.scheme == "http" else 443

        start_time = time.time()
        with socket.create_connection((host, port), timeout=2) as sock:
            pass
        latency = (time.time() - start_time) * 1000
        return latency
    except Exception:
        return float('inf')

def run_speed_test():
    try:
        progress = xbmcgui.DialogProgress()
        progress.create("Speed Test", "Initializing...")

        progress.update(0, "Testing download speed...")
        download_speed = test_download_speed_with_progress(DOWNLOAD_TEST_URL, progress)
        if progress.iscanceled():
            progress.close()
            return

        results = []
        for i, location in enumerate(PING_LOCATIONS, start=1):
            progress.update(50 + int((i / len(PING_LOCATIONS)) * 50), f"Testing latency for {location}...")
            latency = test_latency(location)
            results.append({'location': location, 'latency': latency})
            if progress.iscanceled():
                progress.close()
                return

        progress.close()
        results.sort(key=lambda x: x['latency'])

        results_text = f"Download Speed: {download_speed:.2f} Mbps\n\nServer Latency (Ranked):\n"
        for i, result in enumerate(results):
            latency_display = f"{result['latency']:.2f} ms" if result['latency'] != float('inf') else "Unreachable"
            results_text += f"{i + 1}. {result['location']} - {latency_display}\n"

        xbmcgui.Dialog().ok("Speed Test Results", results_text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"An error occurred: {e}")

if __name__ == "__main__":
    run_speed_test()
