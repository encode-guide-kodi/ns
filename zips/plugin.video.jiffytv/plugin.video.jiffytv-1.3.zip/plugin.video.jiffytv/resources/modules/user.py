import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmppZmZ5dHY=')

name = b.b64decode('SmlmZnkgVFY=')

host = b.b64decode('aHR0cDovL2ppZmZ5dHYubmV0')

port = b.b64decode('ODA=')