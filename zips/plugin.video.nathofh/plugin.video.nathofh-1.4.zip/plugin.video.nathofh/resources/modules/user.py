import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm5hdGhvZmg=')

name = b.b64decode('TmF0aG8gRkg=')

host = b.b64decode('aHR0cDovL25hdGhvdGVjaC5uZXQ')

port = b.b64decode('MjA5Ng')