import base64 as b

id   = b.b64decode('plugin.video.nathotemp')

name = b.b64decode('VGVtcG9yYXJ5IE9uZQ==')

host = b.b64decode('aHR0cDovL3RlbXBvcmFyeS5vbmU=')

port = b.b64decode('ODA=')