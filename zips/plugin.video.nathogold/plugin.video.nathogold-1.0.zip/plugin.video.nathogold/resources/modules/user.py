import base64 as b

id   = b.b64decode('plugin.video.nathogold')

name = b.b64decode('NS Gold Sub')

host = b.b64decode('aHR0cDovL2dvbGRzdWIuY29t')

port = b.b64decode('ODA4MA')