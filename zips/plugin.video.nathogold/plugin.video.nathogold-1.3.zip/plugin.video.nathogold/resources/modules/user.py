import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm5hdGhvZ29sZA==')

name = b.b64decode('TlMgR29sZCBTdWI=')

host = b.b64decode('aHR0cDovL2dvbGRzdWIuY29t')

port = b.b64decode('ODA4MA==')