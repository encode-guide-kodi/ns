import base64

addon_name   = base64.b64decode('TmF0aG8gVk9E')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLm5hdGhvc3Vic3ZvZA==')

host         = base64.b64decode('aHR0cDovL3RoZWRhYi54eXo=')
port         = base64.b64decode('ODA=')