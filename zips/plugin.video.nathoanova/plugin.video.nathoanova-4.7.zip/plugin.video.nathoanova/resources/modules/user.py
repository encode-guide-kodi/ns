import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm5hdGhvYW5vdmE=')

name = b.b64decode('QW5vdmEgSVBUVg==')

host = b.b64decode('aHR0cDovL2Fub3ZhbmF0aG8uY29t')

port = b.b64decode('MjU0NjE=')