# -*- coding: utf-8 -*-

# Deleting this file cripples the entire addon

#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
# http://kodi.wiki/view/How-to:Write_Python_Scripts
################################################

from __future__ import unicode_literals
from collections import namedtuple
import codecs
import sys,os,json,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re
import shutil
import base64
import xbmcvfs
import urllib
import random
import hashlib
import cookielib
import pickle
import time
import datetime

addontag = ['plugin.video.jiffytv']
subname       = 'addons2'
addon         = 'script.tvguide.ns'
ADDONID       = addon
maj          = 'script.tvguide.ns'
addonPath     = xbmc.translatePath(os.path.join('special://home/addons', addon))
basePath      = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
tmp_File      = os.path.join(basePath, 'tmp.ini')
icon          = xbmc.translatePath(os.path.join('special://home/addons', addon, 'icon.png'))
dbPath        = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog        = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
subData       = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.tvguide.ns', 'resources', 'config', 'Data.txt'))
subLogos       = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.tvguide.ns', 'resources', 'config', 'Logo.txt'))
inipath       = xbmc.translatePath(os.path.join(basePath))
inifile = os.path.join(inipath, subname+'.ini')


if not os.path.exists(basePath):
    os.makedirs(basePath)
            

def notify(header,msg,icon_path):
    duration=2000
    xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)

def StartCreate():

    if os.path.exists(inifile):
        os.remove(inifile)
    if not os.path.exists(inipath):
        os.makedirs(inipath)
    path = os.path.join(xbmc.translatePath('special://home/addons'), maj) 
    path2 = os.path.join(xbmc.translatePath('special://home/addons'), addon)
    if os.path.exists(path) and os.path.exists(path2):
        add_ini()

    return

def add_ini():
    for FoundAddon in addontag:
        if CheckHasThisAddon(FoundAddon):
            notify('generating channels',FoundAddon,os.path.join('special://home/addons', FoundAddon, 'icon.png'))##NOTIFY##
            ParseData(FoundAddon)
def CheckHasThisAddon(FoundAddon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % FoundAddon) == 1:
        settingsFileCheck = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',FoundAddon,'settings.xml'))
        if os.path.exists(settingsFileCheck):
            return True
    else:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        return False 
#


def ParseData(FoundAddon):
    Addoninipath  = inifile
    response = GrabSettingsFrom(FoundAddon)
    result   = response['result'] 
    ChannelsResult = result['files']    
    ExtrasFileToWrite  = file(Addoninipath, 'w')  
    ExtrasFileToWrite.write('[')
    ExtrasFileToWrite.write(FoundAddon)
    ExtrasFileToWrite.write(']')
    ExtrasFileToWrite.write('\n')   
    TheAddonURL = []   
    for channel in ChannelsResult:
        ParsedChannels = channel['label']
        stream  = channel['file']
        ChannelURL  = GetStuff(FoundAddon, ParsedChannels)
        channel = RemoveChanCrap(FoundAddon, ChannelURL)
        FinalChannelString = channel.split(' -  ')[0] + '\t\t=' + stream
        TheAddonURL.append(FinalChannelString)
        TheAddonURL.sort()
    for item in TheAddonURL:
      ExtrasFileToWrite.write("%s\n" % item.encode('ascii', 'ignore').decode('ascii'))
    ExtrasFileToWrite.close()
    Clean_Names_(Addoninipath,tmp_File)


#
def GrabSettingsFrom(FoundAddon):
	Addon    =  xbmcaddon.Addon(FoundAddon)
	username =  Addon.getSetting('Username')
	password =  Addon.getSetting('Password')
	BeginningOfPluginString   = 'plugin://' + FoundAddon

	urlBody= '/?description&iconimage=&mode=2&name=All&url='
	endOfString    =  GetVariables(FoundAddon)
	startOfString  =  BeginningOfPluginString + urlBody + urllib.quote_plus(endOfString)
	GrabThisUrl = 'username=' + username + '&password=' + password + '&type=get_live_streams&cat_id=0'
	queryURL = BeginningOfPluginString  + '/?action=security_check&extra&page&plot&thumbnail&title=live%20TV&url'
	query = startOfString +  urllib.quote_plus(GrabThisUrl)
	checkthisurl = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % queryURL)
	checkthisurltoo = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query)   
	try:
		#xbmc.executeJSONRPC(checkthisurl)
		response = xbmc.executeJSONRPC(checkthisurltoo)
		content = json.loads(response.decode('utf-8', 'ignore'))
		return content
	except Exception as e:
		xbmc.executebuiltin( "Dialog.Close(busydialog)" )
		#RunSetSetting(e)
		print e
		return {'Error' : 'Plugin Error'}
#    
def GetStuff(FoundAddon, RemoveURLGarbage):
    RemoveURLGarbage = RemoveURLGarbage.replace('COLOR+', '').replace(' [/B]', '').replace('[COLOR WHITE]', '').replace('[/COLOR]', '').replace('[COLOR white]', '').replace('COLOR+steelblue', '').replace('[COLOR steelblue]', '').replace('AR: ', 'AR ').replace('CA: ', 'CA ').replace('EPL: ', 'EPL ').replace('IN:', 'IN ').replace('PAK:', 'PAK ').replace('US: ', 'US ').replace('AR: ', 'AR ')   
    return RemoveURLGarbage
#    
def RemoveChanCrap(FoundAddon, FoundChannels):
    channel = FoundChannels.rsplit('[/B]', 1)[0].split('[B]', 1)[-1]        
    return channel
#       
def GetVariables(FoundAddon):
    Addon    =  xbmcaddon.Addon(FoundAddon) 
    addre_ss =  'http://jiffytv.net' 
    po_rt =  '80'
    correct_address = addre_ss + ':' + po_rt + '/enigma2.php?'
    return correct_address

def Clean_Names_(Clean_Name,tmpFile): 
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    orig=open(tmpFile).read()	
    f=open(Clean_Name,'a')
    f.write(orig)

    r=open(tmpFile).read().splitlines()
    o=open(Clean_Name).read().splitlines()
    for s in r:

        s=s.replace('BBC 1','BBC One')
        s=s.replace('BBC 2','BBC Two')
        if s not in o:
            f.write('\n%s'% (s)) 

    f.close()
    os.remove(tmpFile) 



if __name__ == '__main__':
    if StartCreate():
        StartCreate()
        print 'Subscriptions1'
    else:
        print 'Subscriptions2'