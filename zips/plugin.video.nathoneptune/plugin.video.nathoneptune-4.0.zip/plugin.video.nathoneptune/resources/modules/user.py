import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm5hdGhvbmVwdHVuZQ==')

name = b.b64decode('TmVwdHVuZSBJUFRW')

host = b.b64decode('aHR0cDovL25lcHR1bmVuYXRoby5jb20=')

port = b.b64decode('ODM=')