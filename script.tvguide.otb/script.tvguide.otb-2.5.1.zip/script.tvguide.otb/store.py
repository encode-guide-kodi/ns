"""Streaming import and indexed guide storage. No Kodi dependencies."""
import datetime as dt
import gzip
import hashlib
import re
import sqlite3
import time
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlsplit


def connect(path):
    db = sqlite3.connect(str(path), timeout=5)
    db.row_factory = sqlite3.Row
    db.executescript('''
    CREATE TABLE IF NOT EXISTS channels(id TEXT PRIMARY KEY, name TEXT, epg TEXT,
        tvg_name TEXT, grp TEXT, logo TEXT, url TEXT);
    CREATE INDEX IF NOT EXISTS channel_group ON channels(grp, name);
    CREATE TABLE IF NOT EXISTS programmes(epg TEXT, start INTEGER, stop INTEGER,
        title TEXT, description TEXT);
    CREATE INDEX IF NOT EXISTS programme_time ON programmes(epg, start, stop);
    CREATE TABLE IF NOT EXISTS programme_metadata(epg TEXT, start INTEGER, image TEXT, category TEXT, date TEXT, episode TEXT, PRIMARY KEY(epg,start));
    CREATE TABLE IF NOT EXISTS favourites(id TEXT PRIMARY KEY);
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
    ''')
    return db


def stamp(value):
    parts = value.strip().split()
    raw = parts[0]
    if len(raw) not in (8, 10, 12, 14):
        raise ValueError('Unsupported programme date')
    raw = raw.ljust(14, '0')
    zone = parts[1] if len(parts) > 1 else '+0000'
    zone = {'UTC': '+0000', 'GMT': '+0000', 'BST': '+0100', 'Z': '+0000'}.get(zone, zone)
    if not re.fullmatch(r'[+-][0-9]{4}', zone):
        raise ValueError('Unsupported programme timezone')
    hours, minutes = int(zone[1:3]), int(zone[3:5])
    if hours > 23 or minutes > 59:
        raise ValueError('Invalid programme timezone')
    offset = dt.timedelta(hours=hours, minutes=minutes)
    if zone[0] == '-': offset = -offset
    value = dt.datetime(int(raw[:4]), int(raw[4:6]), int(raw[6:8]),
                        int(raw[8:10]), int(raw[10:12]), int(raw[12:14]),
                        tzinfo=dt.timezone(offset))
    return int(value.timestamp())


def open_data(path):
    with open(path, 'rb') as f:
        compressed = f.read(2) == b'\x1f\x8b'
    return gzip.open(path, 'rb') if compressed else open(path, 'rb')


def playlist(path, base='', live_only=True):
    attrs, name, group = {}, '', ''
    with open_data(path) as source:
        for raw in source:
            line = raw.decode('utf-8-sig', 'replace').strip()
            if line.startswith('#EXTINF:'):
                # The title delimiter is the first comma outside quotes.
                match = re.match(r'#EXTINF:((?:[^"\',]|"[^"]*"|\'[^\']*\')*),(.*)', line)
                if not match:
                    name = ''
                    continue
                attrs = {m[0].lower(): m[2] for m in re.findall(r'([\w-]+)=("|\')(.*?)\2', match[1])}
                name = match[2].strip() or attrs.get('tvg-name', 'Unnamed channel')
                group = attrs.get('group-title', 'Other')
            elif line.startswith('#EXTGRP:'):
                group = line[8:].strip() or 'Other'
            elif line and not line.startswith('#') and name:
                url = urljoin(base, line)
                path_part = urlsplit(url.split('|', 1)[0]).path.lower()
                vod = '/movie/' in path_part or '/series/' in path_part or path_part.endswith(('.mp4', '.mkv', '.avi'))
                if not (live_only and vod):
                    ident = hashlib.sha256((name + '\n' + url).encode()).hexdigest()
                    yield (ident, name, attrs.get('tvg-id', '').strip(), attrs.get('tvg-name', name), group, attrs.get('tvg-logo', ''), url)
                name = ''


def import_guide(db, m3u, xmltv, base='', live_only=True, days=7, progress=lambda msg: None):
    """Replace guide in one transaction; errors/cancellation preserve prior data."""
    now = int(time.time())
    total, programmes, skipped = 0, 0, 0
    with db:
        db.execute('DELETE FROM channels')
        db.execute('DELETE FROM programmes')
        db.execute('DELETE FROM programme_metadata')
        for channel in playlist(m3u, base, live_only):
            db.execute('INSERT OR REPLACE INTO channels VALUES (?,?,?,?,?,?,?)', channel)
            total += 1
            if total % 500 == 0:
                progress('Importing channels: {:,}'.format(total))
        if not total:
            raise ValueError('No channels found. Check the M3U source and movie filter.')
        aliases, epg_ids = {}, set()
        with open_data(xmltv) as source:
            events = ET.iterparse(source, events=('start', 'end'))
            _, root = next(events)
            if root.tag != 'tv':
                raise ValueError('The guide source is not XMLTV.')
            seen = 0
            for event, elem in events:
                if event != 'end' or elem.tag not in ('channel', 'programme'):
                    continue
                seen += 1
                if elem.tag == 'channel':
                    eid = elem.get('id', '')
                    epg_ids.add(eid)
                    for label in elem.findall('display-name'):
                        key = (label.text or '').strip().casefold()
                        if key:
                            aliases.setdefault(key, set()).add(eid)
                else:
                    eid = elem.get('channel', '')
                    epg_ids.add(eid)
                    try:
                        start = stamp(elem.get('start', ''))
                        stop = stamp(elem.get('stop')) if elem.get('stop') else None
                        if stop is not None and stop <= start:
                            raise ValueError('Invalid programme interval')
                        if (stop or start + 86400) > now - 14 * 86400 and start < now + days * 86400:
                            db.execute('INSERT INTO programmes VALUES (?,?,?,?,?)', (eid, start, stop, elem.findtext('title') or 'Untitled', elem.findtext('desc') or ''))
                            icon=elem.find('icon')
                            db.execute('INSERT OR REPLACE INTO programme_metadata VALUES (?,?,?,?,?,?)',
                                (eid,start,icon.get('src','') if icon is not None else '',
                                 ', '.join((n.text or '') for n in elem.findall('category')),
                                 elem.findtext('date') or '',elem.findtext('episode-num') or ''))
                            programmes += 1
                    except (ValueError, IndexError):
                        skipped += 1
                root.remove(elem)
                elem.clear()
                if seen % 500 == 0:
                    progress('Importing guide: {:,} programmes'.format(programmes))
        # Missing stop times use the next programme; the final entry gets 1 hour.
        db.execute('''UPDATE programmes SET stop=COALESCE(
            (SELECT MIN(p.start) FROM programmes p WHERE p.epg=programmes.epg AND p.start>programmes.start), start+3600)
            WHERE stop IS NULL''')
        for row in db.execute('SELECT id, epg, tvg_name, name FROM channels').fetchall():
            if row['epg'] in epg_ids:
                continue
            candidates = aliases.get(row['tvg_name'].strip().casefold(), set()) or aliases.get(row['name'].strip().casefold(), set())
            if len(candidates) == 1:
                db.execute('UPDATE channels SET epg=? WHERE id=?', (next(iter(candidates)), row['id']))
        progress('Finishing import')
        db.execute("INSERT OR REPLACE INTO meta VALUES ('updated',?)", (str(now),))
    matched = db.execute('SELECT COUNT(*) FROM channels c WHERE EXISTS (SELECT 1 FROM programmes p WHERE p.epg=c.epg)').fetchone()[0]
    return total, programmes, matched, skipped


def now_next(db, epg, now=None):
    now = int(time.time()) if now is None else now
    current = db.execute('SELECT * FROM programmes WHERE epg=? AND start<=? AND stop>? ORDER BY start DESC LIMIT 1', (epg, now, now)).fetchone()
    upcoming = db.execute('SELECT * FROM programmes WHERE epg=? AND start>? ORDER BY start LIMIT 1', (epg, now)).fetchone()
    return current, upcoming
