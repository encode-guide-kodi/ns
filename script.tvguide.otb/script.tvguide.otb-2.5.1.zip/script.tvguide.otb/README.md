# OTB TV Guide 2.3.1

Install script.tvguide.otb-2.3.1.zip through Kodi Add-ons > Install from zip file. It updates the existing guide. Version 2.3.0 was installed and visually checked on Windows; 2.3.1 adds image fitting, background loading for visible cards, and TVmaze lookup. The final additions passed automated checks but have not been installed into the active browsing session.

## Changes

- Kodi addon metadata now declares the included icon.png and fanart.jpg.
- Channel and timeline headings sit above the first channel row.
- A featured artwork panel accompanies programme descriptions.
- Movies and TV Shows have wide artwork cards. Available provider backdrops load for the visible titles in the background. Poster artwork remains when no backdrop is supplied.
- XMLTV imports retain programme images, categories, dates and episode numbers. Press Refresh once after updating to import these fields.
- Missing live-show images can use a unique, exact-title TVmaze match. Ambiguous or unavailable matches keep the channel logo. These are show images, not guaranteed images from that exact episode.

TVmaze lookup sends the programme title only, never your OTB login details. Disable it in Settings > Sources and refresh settings > Look up missing show artwork on TVmaze. Results are cached for seven days. Provider artwork remains the first choice.

## Navigation

Up/Down scrolls channels continuously. Back from the grid jumps to categories. Up from categories reaches the toolbar, then the Live TV / Movies / TV Shows tabs. Left/Right chooses an item; OK opens it. Info offers descriptions, hide channel, favourites and catch-up. Settings restores hidden channels. Numbering starts at 101 and stays attached to streams; these are not official Sky channel numbers.

## Validation

Windows Kodi confirmed: addon icon, raised headings, successful refreshed guide (1,245 channels and 34,137 programmes), Movies provider backdrop and description. Earlier testing confirmed repeated channel scrolling, top-tab/category navigation, movie playback and returning to the catalogue after Stop. Automated checks cover metadata import, unique-title artwork matching, caching, rejecting ambiguous matches, scrolling, numbering, filtering and VOD paging. Physical Android remote testing remains device-specific.

## Attribution

Optional show artwork metadata is provided by [TVmaze](https://www.tvmaze.com), under [CC BY-SA](https://creativecommons.org/licenses/by-sa/4.0/), using its [public API](https://www.tvmaze.com/api). Source links are retained in the local metadata cache. OTB guide code remains GPL-2.0-or-later. No Sky branding or reference-photo artwork is included.
