"""Local OTB sources, transactional import, and migration from guide 1.x."""
import os
import sqlite3
import tempfile
import shutil
import time
import traceback
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from store import connect, import_guide

ADDON = xbmcaddon.Addon('script.tvguide.otb')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)

def record_error(context):
    # Keep stack frame locations, not provider URLs or exception messages.
    import sys
    typ, value, tb = sys.exc_info()
    frames = traceback.extract_tb(tb)
    text = context + ': ' + (typ.__name__ if typ else 'unknown') + '\n'
    text += '\n'.join('%s:%s in %s' % (os.path.basename(f.filename), f.lineno, f.name) for f in frames)
    xbmc.log('[OTB Guide] ' + text, xbmc.LOGERROR)
    with open(os.path.join(PROFILE, 'diagnostics.txt'), 'a', encoding='utf-8') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + text + '\n')

def database():
    db = connect(os.path.join(PROFILE, 'guide-v2.db'))
    if not db.execute('SELECT 1 FROM channels LIMIT 1').fetchone():
        old = os.path.join(PROFILE, 'source-omega.db')
        if os.path.exists(old):
            source = None
            try:
                source = sqlite3.connect('file:' + old.replace('\\', '/') + '?mode=ro', uri=True)
                source.row_factory = sqlite3.Row
                with db:
                    for c in source.execute("SELECT * FROM channels WHERE source='otb' AND stream_url IS NOT NULL AND stream_url!='catchup'"):
                        db.execute('INSERT OR REPLACE INTO channels VALUES (?,?,?,?,?,?,?)', (c['id'], c['title'], c['id'], c['title'], c['lineup'] or 'All', c['logo'] or '', c['stream_url']))
                    for p in source.execute("SELECT * FROM programs WHERE source='otb'"):
                        db.execute('INSERT INTO programmes VALUES (?,?,?,?,?)', (p['channel'], int(float(p['start_date'])), int(float(p['end_date'])), p['title'] or 'No listing', p['description'] or ''))
                    db.execute("INSERT OR REPLACE INTO meta VALUES ('updated',?)", (str(int(time.time())),))
            except Exception:
                record_error('Migration')
            finally:
                if source:
                    source.close()
    return db

def sources():
    m, e = ADDON.getSetting('otb.m3u').strip(), ADDON.getSetting('otb.xmltv').strip()
    if not m or not e:
        try:
            otb = xbmcaddon.Addon('plugin.video.kodiotb')
        except RuntimeError:
            raise ValueError('Configure OTB Kodi, or enter both sources in Settings.')
        server = otb.getSetting('DNS').strip().rstrip('/')
        user, password = otb.getSetting('Username').strip(), otb.getSetting('Password').strip()
        query = urlencode({'username': user, 'password': password})
        ready = bool(server and user and password)
        output = 'm3u8' if otb.getSetting('pvr_output') == '1' else 'ts'
        m = m or otb.getSetting('pvr_playlist_url').strip() or (server + '/get.php?' + query + '&type=m3u_plus&output=' + output if ready else '')
        e = e or otb.getSetting('pvr_epg_url').strip() or (server + '/xmltv.php?' + query if ready else '')
    if not m or not e:
        raise ValueError('OTB account details or playlist/XMLTV sources are missing.')
    return m, e

class Cancelled(Exception):
    pass

def refresh(db):
    dialog = xbmcgui.DialogProgress()
    dialog.create('OTB TV Guide', 'Preparing sources')
    monitor = xbmc.Monitor()
    scratch = tempfile.mkdtemp(prefix='import-', dir=PROFILE)
    def update(message):
        if dialog.iscanceled() or monitor.abortRequested():
            raise Cancelled()
        dialog.update(0, message)
    def download(url, target, label):
        remote = urlsplit(url).scheme.lower() in ('http', 'https')
        reader = urlopen(Request(url, headers={'User-Agent': 'OTB-Guide/2.0', 'Accept-Encoding': 'identity'}), timeout=25) if remote else xbmcvfs.File(url)
        size = 0
        try:
            with open(target, 'wb') as f:
                while True:
                    block = reader.read(262144) if remote else reader.readBytes(262144)
                    if not block:
                        break
                    size += len(block)
                    if size > 512 * 1048576:
                        raise ValueError('Source exceeds the 512 MB limit.')
                    f.write(block)
                    update('Downloading {}: {:.1f} MB'.format(label, size / 1048576))
        finally:
            reader.close()
    try:
        m, e = sources()
        mp, ep = os.path.join(scratch, 'm3u'), os.path.join(scratch, 'xmltv')
        download(m, mp, 'channels')
        download(e, ep, 'XMLTV')
        result = import_guide(db, mp, ep, m, True, 7, update)
        dialog.close()
        xbmcgui.Dialog().ok('Import complete', '{:,} channels; {:,} programmes; {:,} channels with listings.'.format(*result[:3]))
        return True
    except Cancelled:
        return False
    except Exception as exc:
        record_error('Import')
        dialog.close()
        xbmcgui.Dialog().ok('Import failed', str(exc) if type(exc) is ValueError else 'Could not download or parse the sources. Previous guide retained.')
        return False
    finally:
        dialog.close()
        shutil.rmtree(scratch, ignore_errors=True)
