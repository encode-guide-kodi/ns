"""Launch installed Android streaming apps through Kodi's app directory."""
import json
import re
import xbmc
import xbmcgui

SERVICES=[('BBC iPlayer',('bbc.iplayer','bbc iPlayer')),('ITVX',('itv','itvx')),('Channel 4',('channel4','channel 4','all4','all 4')),('Netflix',('netflix',))]

def installed():
    result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory','params':{'directory':'androidapp://sources/apps/','media':'files'}})))
    if 'error' in result:raise ValueError('Kodi could not list installed Android apps.')
    return result.get('result',{}).get('files',[])

def menu():
    if not xbmc.getCondVisibility('System.Platform.Android'):
        xbmcgui.Dialog().ok('Apps','BBC iPlayer, ITVX, Channel 4 and Netflix can be opened here when this guide runs on Android.');return
    try:apps=installed()
    except Exception:
        xbmcgui.Dialog().ok('Apps','Kodi could not read the installed apps on this device.');return
    choices=[]
    for name,terms in SERVICES:
        match=next((a for a in apps if any(t.casefold() in (a.get('label','')+' '+a.get('file','')).casefold() for t in terms)),None)
        choices.append((name,match))
    selected=xbmcgui.Dialog().select('Streaming apps',[name if app else name+' - not installed' for name,app in choices])
    if selected<0:return
    name,app=choices[selected]
    if not app:
        xbmcgui.Dialog().ok(name,'This app is not installed or is not visible to Kodi on this device.');return
    package=app['file'].rstrip('/').rsplit('/',1)[-1]
    if not re.fullmatch(r'[A-Za-z0-9_.]+',package):return
    xbmc.Player().stop()
    xbmc.executebuiltin('StartAndroidActivity('+package+')')
