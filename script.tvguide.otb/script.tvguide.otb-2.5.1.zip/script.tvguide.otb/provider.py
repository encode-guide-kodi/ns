"""OTB Xtream catalogue and advertised catch-up support."""
import datetime
import hashlib
import json
import math
import os
import re
import time
from urllib.parse import urlencode, quote, urlsplit
from urllib.request import Request, urlopen
import xbmcaddon
from backend import PROFILE

def account():
    otb = xbmcaddon.Addon('plugin.video.kodiotb')
    server = otb.getSetting('DNS').strip().rstrip('/')
    user, password = otb.getSetting('Username').strip(), otb.getSetting('Password').strip()
    if not all((server,user,password)):
        raise ValueError('Configure your OTB server, username and password to browse movies, series and catch-up.')
    return server,user,password

def api(action, **params):
    server,user,password = account()
    query = dict(username=user,password=password,action=action,**params)
    url = server+'/player_api.php?'+urlencode(query)
    cache = os.path.join(PROFILE,'api-'+hashlib.sha256(url.encode()).hexdigest()+'.json')
    if os.path.exists(cache) and time.time()-os.path.getmtime(cache)<3600:
        with open(cache,encoding='utf-8') as f:
            return json.load(f)
    with urlopen(Request(url,headers={'User-Agent':'OTB-Guide/2.1'}),timeout=25) as r:
        data = r.read(64*1024*1024+1)
    if len(data)>64*1024*1024:
        raise ValueError('Provider catalogue is too large. Choose a smaller category.')
    result=json.loads(data.decode('utf-8-sig'))
    if not isinstance(result,(dict,list)):
        raise ValueError('The provider did not return a catalogue.')
    with open(cache+'.tmp','w',encoding='utf-8') as f:
        json.dump(result,f)
    os.replace(cache+'.tmp',cache)
    return result

def stream(kind,ident,extension='mp4'):
    server,user,password=account()
    if not re.fullmatch(r'\d+',str(ident)) or not re.fullmatch(r'[A-Za-z0-9]+',extension or ''):
        raise ValueError('Invalid provider stream details.')
    return '{}/{}/{}/{}/{}.{}'.format(server,kind,quote(user,safe=''),quote(password,safe=''),ident,extension)

def catchup_url(channel, programme):
    if not programme or programme['stop']>time.time():
        raise ValueError('Select a completed programme to watch catch-up.')
    server,user,password=account()
    parsed=urlsplit(channel['url'].split('|',1)[0])
    if parsed.netloc != urlsplit(server).netloc:
        raise ValueError('This stream does not match the OTB account server; catch-up cannot be verified.')
    ident=parsed.path.rsplit('/',1)[-1].split('.')[0]
    records=api('get_live_streams')
    record=next((c for c in records if str(c.get('stream_id'))==ident),None) if isinstance(records,list) else None
    if not record or str(record.get('tv_archive','0')) not in ('1','true','True'):
        raise ValueError('Your provider does not advertise catch-up for this channel.')
    days=int(record.get('tv_archive_duration') or 0)
    if days<=0 or programme['start']<time.time()-days*86400:
        raise ValueError('This programme is outside the provider catch-up window.')
    minutes=max(1,int(math.ceil((programme['stop']-programme['start'])/60)))
    # Use the provider's archive start string: servers may use a different
    # timezone from XMLTV and from the Windows device.
    table=api('get_simple_data_table',stream_id=ident)
    listings=table.get('epg_listings',[]) if isinstance(table,dict) else []
    entry=None
    for listing in listings:
        try:
            if abs(int(listing.get('start_timestamp'))-programme['start'])<120 and str(listing.get('has_archive','0')) in ('1','true','True'):
                entry=listing;break
        except (ValueError,TypeError):
            continue
    if entry is None:
        raise ValueError('The provider has no matching archived programme for this listing.')
    start=datetime.datetime.fromisoformat(entry['start']).strftime('%Y-%m-%d:%H-%M')
    return server+'/streaming/timeshift.php?'+urlencode(dict(username=user,password=password,stream=ident,start=start,duration=minutes))

def vod_info(kind,item):
    if kind=='movies':
        data=api('get_vod_info',vod_id=item['stream_id'])
        info=data.get('info') or {}
        return info if isinstance(info,dict) else {}
    return item
