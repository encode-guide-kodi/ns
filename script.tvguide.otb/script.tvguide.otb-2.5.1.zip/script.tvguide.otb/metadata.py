"""Optional TVmaze show artwork. Public titles only, never account details.
TVmaze metadata: CC BY-SA, https://www.tvmaze.com/api .
"""
import hashlib
import json
import os
import re
import time
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from backend import PROFILE, ADDON

def normal(title):
    return re.sub(r'[^a-z0-9]+','',re.sub(r'^new:\s*','',title.lower()))

def request(path):
    time.sleep(0.6)
    with urlopen(Request('https://api.tvmaze.com'+path,headers={'User-Agent':'OTBGuide/2.3'}),timeout=8) as response:
        raw=response.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('Metadata response too large')
    return json.loads(raw)

def tvmaze(title):
    key=normal(title)
    path=os.path.join(PROFILE,'art-'+hashlib.sha256(key.encode()).hexdigest()+'.json')
    if os.path.exists(path) and time.time()-os.path.getmtime(path)<7*86400:
        with open(path,encoding='utf-8') as f:return json.load(f)
    matches=[r['show'] for r in request('/search/shows?'+urlencode({'q':title})) if normal(r['show'].get('name',''))==key]
    result={}
    if len(matches)==1:
        show=matches[0]
        images=request('/shows/'+str(int(show['id']))+'/images')
        art=next((i['resolutions']['original']['url'] for i in images if i.get('type')=='background'),None)
        art=art or (show.get('image') or {}).get('original','')
        result={'image':art,'source':show.get('url','https://www.tvmaze.com'),'credit':'Artwork: TVmaze'}
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(result,f)
    os.replace(path+'.tmp',path)
    return result


def tmdb(title):
    api_key=ADDON.getSetting('art.tmdb_key').strip()
    if not api_key:return {}
    clean=re.sub(r'\s*\(\d{4}\)\s*$','',re.sub(r'^new:\s*','',title,flags=re.I)).strip()
    year=re.search(r'\((\d{4})\)\s*$',title)
    key=hashlib.sha256(('tmdb:'+title).encode()).hexdigest()
    path=os.path.join(PROFILE,'art-'+key+'.json')
    if os.path.exists(path) and time.time()-os.path.getmtime(path)<7*86400:
        with open(path,encoding='utf-8') as f:return json.load(f)
    query=urlencode({'api_key':api_key,'query':clean,'language':'en-GB','include_adult':'false'})
    with urlopen(Request('https://api.themoviedb.org/3/search/multi?'+query,headers={'User-Agent':'OTBGuide/2.5'}),timeout=8) as response:
        raw=response.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('Metadata response too large')
    matches=[m for m in json.loads(raw).get('results',[]) if m.get('media_type') in ('tv','movie') and normal(m.get('name') or m.get('title') or '')==normal(clean)]
    if year:matches=[m for m in matches if (m.get('release_date') or m.get('first_air_date') or '').startswith(year[1])]
    result={}
    if len(matches)==1 and matches[0].get('backdrop_path'):
        result={'image':'https://image.tmdb.org/t/p/w1280'+matches[0]['backdrop_path'],'credit':'Artwork: TMDB','source':'https://www.themoviedb.org/'+matches[0]['media_type']+'/'+str(matches[0]['id'])}
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(result,f)
    os.replace(path+'.tmp',path)
    return result

def lookup(title):
    try:
        result=tmdb(title)
        if result:return result
    except Exception:pass
    if ADDON.getSetting('art.tvmaze')!='false':return tvmaze(title)
    return {}
