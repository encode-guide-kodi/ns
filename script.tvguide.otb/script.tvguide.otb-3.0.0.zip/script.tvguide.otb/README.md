# Version 2.8.0

- Recent is now a permanent top-bar shortcut. It lists the last eight live channels watched, most recent first, and switches immediately to the selected channel. Mini-guide channel changes also feed the same history.
- Playback recovery keeps the guide alive when a live stream errors or fails to start. It offers Retry and, where duplicate mappings exist for the same EPG/name, another mapped stream.
- Existing EPG listings remain available during refresh. Downloads and XMLTV parsing are built in a staging database and then applied in a short transaction. A discreet footer shows Updating guide, the last successful update time, or a failed-update status.
- Remote INFO opens a dedicated native scrollable programme-description viewer. The compact description panel no longer auto-scrolls.
- Preference backups are version 2 and now include reminders, recent channels, custom Android shortcuts, built-in Android app mappings and non-sensitive guide settings, alongside channel numbering/order, hidden channels/categories, favourites and collections. Source URLs, account credentials and API keys remain excluded. Version 1 backups are still accepted.

Automated validation covers Python/XML packaging, preference round-trips, staging-database EPG replacement and control-ID/layout checks. Live provider failure recovery and physical Android remote behaviour still need device testing.

# Version 2.7.10

In Live TV, type a channel number with the remote numeric buttons or keyboard. After 1.5 seconds the guide highlights the channel; OK plays it. OK during entry only completes the jump, so press OK again to play. Back cancels entry. Hidden channels and hidden categories stay excluded. Successful jumps clear the category/search/favourites filters and preserve the timeline and current playback. No change to fullscreen playback numeric controls. Android hardware testing is outstanding.

# Version 2.7.9

Remembers the selected live channel, category and timeline on guide exit. Follow-now views reopen at the current time; historical views older than seven days reset to now. Mini guide selects the current live or catch-up channel where the playing URL can be identified. Archive matching retries a fresh response after a cache miss and supports millisecond timestamps. No live fallback for missing archives.

Automated checks passed; this version has not been installed or tested on an Android device. Successful provider archive streaming is still unverified.

# Version 2.7.8

The top-right clock is formatted directly as 24-hour HH:mm, independently of Kodi regional settings, and updates across Live TV, Movies and TV Shows. Includes the previous Now-button navigation fixes.

# Version 2.7.7

Top-right clock uses explicit 24-hour HH:mm format, including a leading zero. Includes the 2.7.6 Now-button remote navigation.

# Version 2.7.6

Down from the bottom live channel row focuses Now. Down again advances eight channels and focuses the first channel on the next page, without changing the timeline. OK on Now restores current listings. Up returns to the last row. Down at the final page stays on Now. Page Down still advances directly.

# Version 2.7.5

- Past programme selections in the main guide and mini guide use provider catch-up. Unavailable archives show a message and never tune live instead.
- A clock/arrow icon marks channels advertising catch-up with positive retention. Individual recordings remain subject to provider availability.
- Now replaces the bottom Previous, Next and Full screen buttons. Up from any top tab focuses Now; OK returns to current listings while keeping the channel page. Up from Now returns to the grid; Down returns to Live TV. Channel paging still works at row boundaries and with page keys.
- Artwork-source text is hidden from the guide. Existing XMLTV, OTB catalogue and optional TMDB/TVmaze image support remains.
- Includes the Python 3 fullscreen overlay port from 2.7.4, using Action(reloadkeymaps).

# OTB TV Guide 2.7.4

Playback-control correction: ported the guarded On-Tapp change.py overlay entry point to Python 3, with its copyright/GPL notices retained. The session keymap calls the standalone overlay from Kodi fullscreen playback. Keymap installation and removal now use Action(reloadkeymaps), correcting the invalid standalone command in previous builds. Covers keyboard, remote and joystick Up.

Fully exit the old guide before installing, then reopen OTB. Select a live channel, wait for playback, and press Up. Back closes the mini-guide; Back from fullscreen returns to the guide preview.

Install the ZIP through Kodi > Add-ons > Install from zip file. Keep your working OTB video addon configured. Restart Kodi after updating so the reminder service is running.

Changes in 2.7.3:

- Reworked the fullscreen Up shortcut: it now signals the running guide rather than starting a second script. Added FullscreenLiveTV and modern joystick mappings alongside keyboard/remote support. The request is handled even when the timeline is showing earlier/later programmes. Close the old guide before updating, then reopen it to load the revised session binding. This revision has automated checks but has not been tested on the affected device.

Previous playback changes:

- Selecting a live channel starts fullscreen playback. Back returns to the still-open guide with the stream continuing in its picture-in-picture panel. Selecting the same playing channel opens fullscreen again without restarting it. Full guide exit still stops the stream.

Previous changes:

- Press Up during fullscreen video in an open OTB guide session to open the mini-guide. This temporarily maps fullscreen keyboard/remote/gamepad Up and restores the previous mappings on normal guide exit. Other keymap files are not changed. If Kodi is forcibly terminated, reopen and normally exit the guide to clear a leftover session binding.
- Apps > Add your own shortcut chooses an installed Android app or accepts its package name, then lets you name the shortcut. Manage custom shortcuts renames/removes them. Apps must be installed to launch; manually entering a package does not install it.
- Removed More to discover from Movies and TV Shows.
- At the left/right edge of a programme row, another Left/Right pages the timeline by four hours. Earlier/Later programme options also move four hours. Arrow presses within a row continue selecting adjacent cells. Jump to now resumes automatic current-time tracking.

New features adapted from the interaction patterns reviewed in On-Tapp.EPG:

- Options > Search programmes: search imported programme titles, with past/live/upcoming labels, channel and date/time. Results are paged in groups of 100. Select a result for information, live playback, provider-eligible catch-up or reminders.
- Programme information > Remind me / Remind for this series: notifications one minute before the start, while Kodi is running. Series matches use the same exact programme title and XMLTV channel; they are not season-ID matching. Options > Programme reminders removes subscriptions. Notifications persist across Kodi restarts. A startup within five minutes of a programme's start can show its reminder if the programme is still running. No recording or automatic channel switching is enabled.
- Options > Custom collections: create, rename and delete your own Live TV categories; choose multiple channels for each. A channel can belong to several collections. Collections appear in the Live TV category bar and can be hidden/reordered like provider groups.
- Options > Back up preferences / Restore preferences: portable JSON containing channel numbering, order, visibility, favourites, collections and category preferences. Configure/import channels on the destination first. Restore matches exact guide ID and channel name, skips ambiguous/unmatched channels, and reports the count. It replaces collections/category preferences and updates matching channels. Stream URLs, passwords, source settings, Android app shortcuts and reminders are not exported. Movies/TV Shows category IDs need to match the provider on the destination.
- Options > Playback mini-guide: browse channels over the video panel, Left/Right to browse their programmes, OK to tune live, Back to dismiss without stopping playback. Also adds an OTB playback mini-guide entry to Kodi's main item context menu when video is playing; availability depends on where the skin exposes that menu. This is not a replacement for every skin's fullscreen playback controls.
- Ordering editor: swipe Left to pick up, swipe Up/Down to move, swipe Right to place. Remote ordering, visibility and Save/Cancel remain available. Page moves use ten rows in the editor; the main guide retains eight-channel paging.

Previous Android app shortcuts, landscape artwork matching, TMDB setting, guide auto-refresh, Apps centring and stop-on-full-guide-exit remain included. Android app launching and swipe gestures need device testing.

The features were reimplemented for our Python 3 / Kodi 21 architecture. Inspiration: On-Tapp.EPG 4.1.3; source headers credit On-Tapp-Networks Limited, Sean Poyser and Richard Dean and declare GPL v2 or later. Its old startup logic, provider integrations and Python 2 modules were not imported. OTB remains GPL-2.0-or-later; see LICENSE.txt.

TMDB: https://developer.themoviedb.org/docs/getting-started
This product uses the TMDB API but is not endorsed or certified by TMDB.
Optional TVmaze metadata: https://www.tvmaze.com/api (CC BY-SA).

Verification: 33 automated checks passed, including saved ordering, touch action handling, collections, programme search, reminder persistence/deduplication, backup restore rollback, custom Android shortcuts, four-hour timeline paging, keymap cleanup, artwork matching and playback/catch-up logic. Python 3.8 syntax and XML packaging are validated. The 2.7.0 mini-guide was exercised in local Windows Kodi over live video: next-programme browsing, channel browsing and return to the guide worked. The new 2.7.3 Up binding has automated coverage but has not been exercised in Kodi. Physical Android launching/swipes and a timed notification after a real Kodi restart remain unverified. No live test of the final 2.7.3 ZIP is claimed.


## 2.8.1
- Replaced the Android Apps dialog with a full-screen, remote-friendly TV launcher inspired by the supplied Sky Apps & inputs layout.
- Added focused app hero details, Android app artwork, a two-row tile launcher, All apps access and in-launcher shortcut management.
