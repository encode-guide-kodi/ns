"""Optional TVmaze show artwork. Public titles only, never account details.
TVmaze metadata: CC BY-SA, https://www.tvmaze.com/api .
"""
import hashlib
import json
import os
import re
import time
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from backend import PROFILE, ADDON

def normal(title):
    return re.sub(r'[^a-z0-9]+','',re.sub(r'^new:\s*','',title.lower()))

def request(path):
    time.sleep(0.6)
    with urlopen(Request('https://api.tvmaze.com'+path,headers={'User-Agent':'OTBGuide/2.3'}),timeout=8) as response:
        raw=response.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('Metadata response too large')
    return json.loads(raw)

def tvmaze(title):
    key=normal(title)
    path=os.path.join(PROFILE,'art-wide-'+hashlib.sha256(key.encode()).hexdigest()+'.json')
    if os.path.exists(path) and time.time()-os.path.getmtime(path)<7*86400:
        with open(path,encoding='utf-8') as f:return json.load(f)
    matches=[r['show'] for r in request('/search/shows?'+urlencode({'q':title})) if normal(r['show'].get('name',''))==key]
    result={}
    if len(matches)==1:
        show=matches[0]
        images=request('/shows/'+str(int(show['id']))+'/images')
        art=next((i['resolutions']['original']['url'] for i in images if i.get('type')=='background'),None)
        # Portrait posters are unsuitable for the widescreen guide hero.
        result={'image':art,'source':show.get('url','https://www.tvmaze.com'),'credit':'Artwork: TVmaze'}
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(result,f)
    os.replace(path+'.tmp',path)
    return result


def tmdb(title, date="", category=""):
    api_key=ADDON.getSetting('art.tmdb_key').strip()
    if not api_key:return {}
    clean=re.sub(r'\s*\(\d{4}\)\s*$','',re.sub(r'^new:\s*','',title,flags=re.I)).strip()
    supplied_year=re.match(r'^(\d{4})',date or '')
    year=re.search(r'\((\d{4})\)\s*$',title)
    key=hashlib.sha256(('tmdb-v2:'+title+':'+date+':'+category).encode()).hexdigest()
    path=os.path.join(PROFILE,'art-'+key+'.json')
    if os.path.exists(path) and time.time()-os.path.getmtime(path)<7*86400:
        with open(path,encoding='utf-8') as f:return json.load(f)
    query=urlencode({'api_key':api_key,'query':clean,'language':'en-GB','include_adult':'false'})
    with urlopen(Request('https://api.themoviedb.org/3/search/multi?'+query,headers={'User-Agent':'OTBGuide/2.5'}),timeout=8) as response:
        raw=response.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('Metadata response too large')
    matches=[m for m in json.loads(raw).get('results',[]) if m.get('media_type') in ('tv','movie') and normal(m.get('name') or m.get('title') or '')==normal(clean)]
    is_movie=bool(re.search(r'\b(movie|film|cinema)\b',category,re.I))
    if is_movie:matches=[m for m in matches if m.get('media_type')=='movie']
    year=year or (supplied_year if is_movie else None)
    if year:matches=[m for m in matches if (m.get('release_date') or m.get('first_air_date') or '').startswith(year[1])]
    result={}
    if len(matches)==1 and matches[0].get('backdrop_path'):
        result={'image':'https://image.tmdb.org/t/p/w1280'+matches[0]['backdrop_path'],'credit':'Artwork: TMDB','source':'https://www.themoviedb.org/'+matches[0]['media_type']+'/'+str(matches[0]['id'])}
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(result,f)
    os.replace(path+'.tmp',path)
    return result

_catalogues={}

def provider_art(item):
    import provider
    title=re.sub(r'\s*\(\d{4}\)\s*$','',item['title'])
    movie=bool(re.search(r'\b(movie|film|cinema)\b',item.get('category',''),re.I))
    kinds=['movies'] if movie else ['series','movies']
    matches=[]
    for kind in kinds:
        cached=_catalogues.get(kind)
        if cached is None or time.time()-cached[0]>3600:
            try:rows=provider.api('get_vod_streams' if kind=='movies' else 'get_series')
            except Exception:rows=[]
            _catalogues[kind]=(time.time(),rows if isinstance(rows,list) else [])
        for row in _catalogues[kind][1]:
            name=re.sub(r'\s*\(\d{4}\)\s*$','',row.get('name',''))
            if normal(name)!=normal(title):continue
            year=str(row.get('year') or row.get('releaseDate') or '')[:4]
            wanted=(item.get('date') or '')[:4]
            if kind=='movies' and wanted and year and wanted!=year:continue
            matches.append((kind,row))
    # Avoid substituting an unrelated remake or same-name film/series.
    if len(matches)!=1:return {}
    kind,row=matches[0]
    data=provider.vod_info(kind,row) if kind=='movies' else provider.api('get_series_info',series_id=row['series_id']).get('info',{})
    art=data.get('backdrop_path') or row.get('backdrop_path') or ''
    if isinstance(art,list):art=next((a for a in art if isinstance(a,str) and a),'')
    if isinstance(art,str) and art.startswith(('https://','http://')):
        return {'image':art,'credit':'Artwork: OTB catalogue'}
    return {}

def lookup(item):
    if isinstance(item,str):item={'title':item}
    if ADDON.getSetting('art.provider')!='false':
        try:
            result=provider_art(item)
            if result:return result
        except Exception:pass
    try:
        result=tmdb(item['title'],item.get('date',''),item.get('category',''))
        if result:return result
    except Exception:pass
    if ADDON.getSetting('art.tvmaze')=='true':return tvmaze(item['title'])
    return {}
