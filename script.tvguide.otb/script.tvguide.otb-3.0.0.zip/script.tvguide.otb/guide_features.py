"""OTB-skinned programme search, collections, recent channels and preferences transfer."""
import json
import time
import uuid
import xbmcgui
import xbmcvfs
import guide_data
import android_apps
import ui
from backend import ADDON

SAFE_SETTINGS=('otb.matched','otb.hours','art.provider','art.tvmaze')


def programme_information(guide):
    if not guide.selected:
        return
    channel,p=guide.selected
    if not p:
        ui.textviewer(channel['name'],'No programme information is available for this channel.')
        return
    heading='{}  |  {} - {}'.format(channel['name'],time.strftime('%H:%M',time.localtime(p['start'])),time.strftime('%H:%M',time.localtime(p['stop'])))
    body=p['title']+'\n\n'+(p['description'] or 'No programme description supplied.')
    # Dedicated OTB text view is remote-scrollable and does not auto-scroll.
    ui.textviewer(p['title'],body,heading)


def recent_channels(guide):
    rows=guide_data.recent_channels(guide.db,8)
    if not rows:
        ui.message('Recent channels','No recently watched channels yet.')
        return
    labels=[]
    now=int(time.time())
    for c in rows:
        p=guide.db.execute('SELECT title FROM programmes WHERE epg=? AND start<=? AND stop>? ORDER BY start DESC LIMIT 1',(c['epg'],now,now)).fetchone()
        labels.append(c['name']+('  |  '+p['title'] if p else ''))
    choice=ui.select('Recent channels',labels,'Your most recently watched live channels')
    if choice>=0:
        guide.watch(rows[choice])


def programme_search(guide):
    term=ui.input_text('Search programme titles')
    if term is None or not term.strip():return
    offset=0
    while True:
        rows=guide_data.search(guide.db,term,offset,101)
        visible=rows[:100];now=time.time()
        labels=[]
        for r in visible:
            state='Past' if r['stop']<=now else 'Live' if r['start']<=now else 'Upcoming'
            labels.append('%s | %s | %s | %s'%(state,time.strftime('%a %d %b %H:%M',time.localtime(r['start'])),r['channel_name'],r['title']))
        if not rows and offset==0:ui.message('Programme search','No matching programmes in the imported guide.');return
        navigation=[]
        if offset:navigation.append(('Previous results',-100))
        if len(rows)>100:navigation.append(('Next results',100))
        selected=ui.select('Programme results',labels+[n[0] for n in navigation],term)
        if selected<0:return
        if selected>=len(visible):offset+=navigation[selected-len(visible)][1];continue
        p=visible[selected];c=guide.db.execute('SELECT * FROM channels WHERE id=?',(p['channel_id'],)).fetchone()
        guide.selected=(c,p)
        guide.details()
        if not guide.active:return


def reminders(guide):
    rows=guide.db.execute('SELECT * FROM reminders ORDER BY title,start').fetchall()
    if not rows:ui.message('Reminders','Select a programme, open Programme information, then choose a reminder.');return
    labels=[r['title']+(' (series on this channel)' if r['series'] else ' - '+time.strftime('%d %b %H:%M',time.localtime(r['start']))) for r in rows]
    selected=ui.select('Select a reminder to remove',labels)
    if selected>=0:
        with guide.db:
            guide.db.execute('DELETE FROM reminders WHERE id=?',(rows[selected]['id'],))
            guide.db.execute('DELETE FROM reminder_sent WHERE reminder=?',(rows[selected]['id'],))


def add_reminder(guide,series):
    if not guide.selected or not guide.selected[1]:return
    p=guide.selected[1]
    if not series and p['start']<=time.time():ui.message('Reminder','Choose an upcoming programme.');return
    guide_data.add_reminder(guide.db,p,series)
    ui.message('Reminder saved','One minute before '+p['title'])


def collections(guide):
    rows=guide.db.execute('SELECT * FROM collections ORDER BY name').fetchall()
    choice=ui.select('Custom channel collections',['Create collection']+[r['name'] for r in rows])
    if choice<0:return
    if choice==0:
        value=ui.input_text('Collection name');name=(value or '').strip()
        if not name:return
        ident='collection:'+uuid.uuid4().hex
        with guide.db:guide.db.execute('INSERT INTO collections VALUES (?,?)',(ident,name))
    else:
        ident=rows[choice-1]['id'];name=rows[choice-1]['name']
        action=ui.select(name,['Choose channels','Rename','Delete collection'])
        if action<0:return
        if action==1:
            value=ui.input_text('Collection name',name);name=(value or '').strip()
            if name:
                with guide.db:guide.db.execute('UPDATE collections SET name=? WHERE id=?',(name,ident))
            guide.render();return
        if action==2:
            with guide.db:
                guide.db.execute('DELETE FROM collections WHERE id=?',(ident,))
                guide.db.execute('DELETE FROM collection_members WHERE collection=?',(ident,))
                guide.db.execute("DELETE FROM display_order WHERE kind='categories:live' AND item=?",(ident,))
                guide.db.execute("DELETE FROM hidden_categories WHERE mode='live' AND category=?",(ident,))
            guide.group='';guide.render();return
    channels=guide.db.execute('SELECT * FROM channels ORDER BY name').fetchall()
    members={r[0] for r in guide.db.execute('SELECT url FROM collection_members WHERE collection=?',(ident,))}
    selection=ui.multiselect('Channels in '+name,[c['name'] for c in channels],preselect=[i for i,c in enumerate(channels) if c['url'] in members])
    if selection is not None:
        with guide.db:
            guide.db.execute('DELETE FROM collection_members WHERE collection=?',(ident,))
            guide.db.executemany('INSERT INTO collection_members VALUES (?,?)',[(ident,channels[i]['url']) for i in selection])
    guide.render()


def _portable_settings():
    return {key:ADDON.getSetting(key) for key in SAFE_SETTINGS}


def _restore_settings(data):
    if data is None:return
    if not isinstance(data,dict):raise ValueError('Invalid guide settings backup')
    for key,value in data.items():
        if key not in SAFE_SETTINGS:raise ValueError('Unsupported guide setting in backup')
        ADDON.setSetting(key,str(value))


def backup(guide,restore=False):
    """Back up/restore preferences without opening Kodi's file browser UI."""
    import os
    folder=os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),'backups')
    os.makedirs(folder,exist_ok=True)
    if restore:
        files=sorted([name for name in os.listdir(folder) if name.lower().endswith('.json')],reverse=True)
        if not files:
            ui.message('Restore preferences','No OTB preference backups were found. Create a backup first.')
            return
        choice=ui.select('Restore preferences',files,'Backups stored in the OTB profile')
        if choice<0:return
        path=os.path.join(folder,files[choice])
        with open(path,'r',encoding='utf-8') as f:raw=f.read(8*1024*1024+1)
        if len(raw)>8*1024*1024:raise ValueError('Backup is too large')
        data=json.loads(raw)
        if data.get('version')==2:
            android=data.get('android_shortcuts',{})
            if not isinstance(android,dict):raise ValueError('Invalid Android shortcut backup')
            settings=data.get('guide_settings',{})
            if not isinstance(settings,dict):raise ValueError('Invalid guide settings backup')
        if not ui.confirm('Restore preferences','Restore channel order, favourites, hidden categories, collections, reminders, recent channels and Android shortcuts?','Restore','Cancel'):return
        matched,skipped=guide_data.restore_preferences(guide.db,data)
        if data.get('version')==2:
            android_apps.restore_shortcut_preferences(data.get('android_shortcuts',{}))
            _restore_settings(data.get('guide_settings',{}))
        guide.group='';guide.offset=0;guide.render()
        ui.message('Preferences restored','%d channels matched; %d unmatched or ambiguous channels skipped. Reminders and shortcuts were restored where present.'%(matched,skipped))
    else:
        path=os.path.join(folder,'OTB-preferences-'+time.strftime('%Y%m%d-%H%M%S')+'.json')
        data=guide_data.export_preferences(guide.db)
        data['android_shortcuts']=android_apps.export_shortcut_preferences()
        data['guide_settings']=_portable_settings()
        with open(path,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
        ui.message('Preferences backed up','Saved as '+os.path.basename(path)+' in the OTB profile backups folder. Channel order, favourites, hidden categories, collections, reminders and Android shortcuts are included.')
