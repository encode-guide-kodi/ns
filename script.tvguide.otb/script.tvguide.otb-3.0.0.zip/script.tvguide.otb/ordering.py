"""Remote ordering editor based on the original ChannelsMenu interaction."""
import xbmcgui

class OrderEditor(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.items=[]
        self.original=[]
        self.hidden=set()
        self.saved=False
        self.title='Organise channels'
        self.moving=False

    def onInit(self):
        self.getControl(10).setLabel(self.title)
        self.populate(0)
        self.setFocusId(6000 if self.items else 6004)

    def label(self,index):
        key,name=self.items[index]
        return '%d. %s%s'%(index+1,name,'  [Hidden]' if key in self.hidden else '')

    def populate(self,index):
        control=self.getControl(6000)
        control.reset()
        control.addItems([xbmcgui.ListItem(self.label(i)) for i in range(len(self.items))])
        if self.items:control.selectItem(max(0,min(index,len(self.items)-1)))

    def pickup(self):
        if not self.items:return
        self.moving=True
        self.getControl(6002).setLabel('Moving: '+self.items[self.getControl(6000).getSelectedPosition()][1])
        self.setFocusId(6002)

    def move(self,delta):
        control=self.getControl(6000)
        source=control.getSelectedPosition()
        target=max(0,min(source+delta,len(self.items)-1))
        if source==target:return
        self.items.insert(target,self.items.pop(source))
        # Only changed rows are relabelled; the list keeps its scroll position.
        for i in range(min(source,target),max(source,target)+1):
            control.getListItem(i).setLabel(self.label(i))
        control.selectItem(target)

    def drop(self):
        self.moving=False
        self.getControl(6002).setLabel('Move selected item')
        self.setFocusId(6000)

    def onAction(self,action):
        ident=action.getId()
        ident={511:1,521:2,531:3,541:4}.get(ident,ident)
        if ident in (9,10,92):
            if self.moving:self.drop()
            else:self.close()
            return
        focus=self.getFocusId()
        if focus==6002 and self.moving:
            if ident in (3,4,5,6):self.move({3:-1,4:1,5:-10,6:10}[ident])
            elif ident==2:self.drop()
        elif focus==6000 and ident in (1,117):self.pickup()

    def onClick(self,ident):
        if ident==6000 and self.items:
            control=self.getControl(6000);index=control.getSelectedPosition()
            key=self.items[index][0]
            if key in self.hidden:self.hidden.remove(key)
            else:self.hidden.add(key)
            control.getListItem(index).setLabel(self.label(index))
        elif ident==6002:
            if self.moving:self.drop()
            else:self.pickup()
        elif ident==6003:self.saved=True;self.close()
        elif ident==6004:self.close()
        elif ident==6005:self.items=list(self.original);self.populate(0);self.setFocusId(6000)


def edit(root,title,items,original,hidden):
    dialog=OrderEditor('order.xml',root,'Default','720p')
    dialog.title=title;dialog.items=list(items);dialog.original=list(original);dialog.hidden=set(hidden)
    dialog.doModal()
    result=(dialog.items,dialog.hidden) if dialog.saved else None
    del dialog
    return result
