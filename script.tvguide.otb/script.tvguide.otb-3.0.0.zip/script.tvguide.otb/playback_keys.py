"""Session-scoped playback bindings and in-process mini-guide requests."""
import xbmc
import xbmcgui
import xbmcvfs
PATH='special://profile/keymaps/zz-otb-guide-session.xml'
PROPERTY='OTB.MiniGuideRequested'
ACTION='RunScript(special://home/addons/script.tvguide.otb/playback_overlay.py,UP)'
DEVICES='<keyboard><up>{0}</up></keyboard><remote><up>{0}</up></remote><gamepad><dpadup>{0}</dpadup></gamepad><joystick profile="game.controller.default"><up>{0}</up></joystick>'.format(ACTION)
XML='<keymap>'+''.join('<{0}>{1}</{0}>'.format(window,DEVICES) for window in ('FullscreenVideo','FullscreenLiveTV'))+'</keymap>'

def install():
    try:
        xbmcgui.Window(10000).clearProperty(PROPERTY)
        xbmcvfs.mkdirs('special://profile/keymaps/')
        f=xbmcvfs.File(PATH,'w')
        try:ok=f.write(XML)
        finally:f.close()
        if not ok:raise OSError('Keymap write failed')
        xbmc.executebuiltin('Action(reloadkeymaps)')
        return True
    except Exception:
        xbmc.log('OTB: Mini-guide key binding could not be written',xbmc.LOGWARNING)
        return False

def remove():
    try:
        xbmcgui.Window(10000).clearProperty(PROPERTY)
        if xbmcvfs.exists(PATH):
            xbmcvfs.delete(PATH)
            xbmc.executebuiltin('Action(reloadkeymaps)')
    except Exception:xbmc.log('OTB: Mini-guide key binding could not be removed',xbmc.LOGWARNING)
