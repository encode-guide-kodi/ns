"""OTB Guide 2: explicit XML shell, bounded grid and native live playback."""
import json
import playback_state
import os
import time
import threading
import xbmc
import xbmcgui
import xbmcvfs
import provider
import metadata
import android_apps
import ordering
import guide_data
import guide_features
import ui
import mini_guide
import playback_keys
from backend import ADDON, PROFILE, database, refresh, refresh_background, record_error

ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA = os.path.join(ROOT, 'resources', 'media')
ROWS, LEFT, TOP, WIDTH, HEIGHT = 8, 310, 350, 946, 38

def stamp(ts, full=False):
    return time.strftime('%a %d %b %H:%M' if full else '%H:%M', time.localtime(ts))

def cell(start, end, window):
    x = LEFT + int(round(max(0, min(7200, start-window)) * WIDTH / 7200.0))
    right = LEFT + int(round(max(0, min(7200, end-window)) * WIDTH / 7200.0))
    return x, max(0, right-x)

class Guide(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.db = database()
        guide_data.initialize(self.db)
        self.number_entry=""
        self.number_deadline=0
        self.restore_pending=True
        self.active = False
        self.follow_now = True
        self.next_update = 0
        self.offset = 0
        self.when = int(time.time()) // 1800 * 1800
        self.group, self.query, self.fav = '', '', False
        self.buttons, self.mapping, self.lines = [], {}, []
        self.selected = None
        self.ready = False
        self.pending = None
        self.preview_player = SessionPlayer()
        self.preview_url = None
        self.archive_ids=set()
        self.archive_dirty=False
        self.art_results=[]
        self.vod_details={}
        self.art_request=None
        self.art_serial=0
        self.art_stop=threading.Event()
        self.art_thread=None
        self.art_queue=[]
        self.view_serial=0
        self.mode = 'live'
        self.category_offset = 0
        self.catalogue = []
        self.catalogue_groups = []
        self.history = []
        self.refresh_running = False
        self.refresh_state = ''
        self.refresh_detail = ''
        self.refresh_completed = False
        self.playback_failure = None
        self.playback_prompted = False
        self.preview_channel = None
        self.preview_started_deadline = 0
        self.db.execute('CREATE TABLE IF NOT EXISTS hidden(url TEXT PRIMARY KEY, name TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS channel_numbers(url TEXT PRIMARY KEY, number INTEGER UNIQUE)')
        self.db.execute('CREATE TABLE IF NOT EXISTS hidden_categories(mode TEXT, category TEXT, PRIMARY KEY(mode,category))')
        self.db.execute('CREATE TABLE IF NOT EXISTS display_order(kind TEXT, item TEXT, position INTEGER, PRIMARY KEY(kind,item))')
        self.db.commit()
        if ADDON.getSetting('v21.initialized') != 'true':
            ADDON.setSetting('otb.matched','false')
            ADDON.setSetting('v21.initialized','true')

    def onInit(self):
        if self.ready:
            return
        self.ready = True
        self.update_clock()
        threading.Thread(target=self.load_archives,daemon=True).start()
        self.window_id = xbmcgui.getCurrentWindowId()
        self.getControl(19).setImage(os.path.join(MEDIA, "stream-fade.png"))
        if self.art_thread is None:
            self.art_thread=threading.Thread(target=self.art_worker,daemon=True)
            self.art_thread.start()
        try:
            self.restore_position()
            self.render()
            self.focus_saved_channel()
            if not self.db.execute('SELECT 1 FROM channels LIMIT 1').fetchone():
                if ui.confirm('Welcome to OTB TV Guide', 'Import channels and XMLTV from your OTB settings now?', 'Import', 'Not now'):
                    refresh(self.db)
                    self.render()
            else:
                row = self.db.execute("SELECT value FROM meta WHERE key='updated'").fetchone()
                hours = max(1, int(ADDON.getSetting('otb.hours') or '24'))
                if not row or time.time() - int(row[0]) > hours * 3600:
                    self.start_background_refresh()
                self.update_refresh_status()
        except Exception:
            record_error('Open guide')
            ui.message('OTB TV Guide', 'Could not open the guide. Use Settings > Export diagnostics.')

    def restore_position(self):
        if not self.restore_pending:return
        self.restore_pending=False
        try:
            row=self.db.execute("SELECT value FROM meta WHERE key='view_position'").fetchone()
            state=json.loads(row[0]) if row else {}
            self.group=str(state.get('group',''))
            self.saved_channel=str(state.get('channel',''))
            self.follow_now=bool(state.get('follow_now',True))
            saved=int(state.get('when',self.when))
            if not self.follow_now and abs(time.time()-saved)<7*86400:self.when=saved
            else:self.follow_now=True
            where,params=self.filtered()
            rows=self.db.execute('SELECT c.id FROM channels c WHERE '+where+' ORDER BY COALESCE((SELECT position FROM display_order WHERE kind="channels" AND item=c.url),2147483647),c.rowid',params).fetchall()
            if not rows:self.group='';self.offset=0;return
            index=next((i for i,c in enumerate(rows) if str(c[0])==self.saved_channel),0)
            self.offset=index//ROWS*ROWS
        except (ValueError,TypeError):
            self.group='';self.offset=0;self.follow_now=True

    def focus_saved_channel(self):
        for line in self.lines:
            if str(self.mapping[line[0].getId()][0]['id'])==getattr(self,'saved_channel',''):
                self.setFocus(line[0]);return
        if self.lines:self.setFocus(self.lines[0][0])

    def save_position(self):
        if self.mode!='live':return
        channel=self.selected[0]['id'] if self.selected else ''
        state=dict(group=self.group,channel=str(channel),when=self.when,follow_now=self.follow_now)
        with self.db:self.db.execute("INSERT OR REPLACE INTO meta VALUES ('view_position',?)",(json.dumps(state),))

    def load_archives(self):
        try:
            self.archive_ids=provider.archive_channels()
            self.archive_dirty=True
        except Exception:
            pass

    def filtered(self):
        where, params = ['NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=c.url)'], []
        if ADDON.getSetting('otb.matched') == 'true':
            where.append('EXISTS(SELECT 1 FROM programmes p WHERE p.epg=c.epg)')
        hidden=[r[0] for r in self.db.execute("SELECT category FROM hidden_categories WHERE mode='live'")]
        if hidden:
            where.append('grp NOT IN ('+','.join('?' for _ in hidden)+')'); params.extend(hidden)
        if self.group:
            if self.group.startswith('collection:'):
                where.append('EXISTS(SELECT 1 FROM collection_members m WHERE m.url=c.url AND m.collection=?)');params.append(self.group)
            else:
                where.append('grp=?'); params.append(self.group)
        if self.query:
            where.append('name LIKE ?'); params.append('%'+self.query+'%')
        if self.fav:
            where.append('EXISTS(SELECT 1 FROM favourites f WHERE f.id=c.id)')
        return ' AND '.join(where), params

    def button(self, x, y, width, text, channel, programme=None, channel_button=False):
        control = xbmcgui.ControlButton(int(x), int(y), max(2, int(width)), HEIGHT-4, text,
            focusTexture=os.path.join(MEDIA, 'focus.png'), noFocusTexture=os.path.join(MEDIA, 'channel.png' if channel_button else 'cell.png'),
            textColor='FFF1F5FA', focusedColor='FFFFFFFF', font='font13', alignment=0, textOffsetX=10, textOffsetY=0)
        self.addControl(control)
        self.buttons.append(control)
        self.mapping[control.getId()] = (channel, programme)
        return control

    def render(self):
        self.setFocusId(100)
        self.art_serial+=1
        self.view_serial+=1
        self.art_queue=[]
        self.art_request=None
        self.getControl(18).setImage('')
        if self.buttons:
            self.removeControls(self.buttons)
        self.buttons, self.mapping, self.lines = [], {}, []
        self.getControl(17).setVisible(self.mode == 'live')
        self.getControl(35).setVisible(self.mode != 'live')
        self.getControl(36).setVisible(False)
        self.getControl(31).setImage('')
        self.getControl(32).setLabel('')
        self.getControl(33).setLabel('')
        self.getControl(33).setVisible(False)
        self.draw_categories()
        self.update_refresh_status()
        if self.mode != 'live':
            return self.render_catalogue()
        with self.db:
            number = self.db.execute('SELECT COALESCE(MAX(number),100) FROM channel_numbers').fetchone()[0]
            for row in self.db.execute('SELECT url FROM channels ORDER BY rowid').fetchall():
                if not self.db.execute('SELECT 1 FROM channel_numbers WHERE url=?',(row[0],)).fetchone():
                    number += 1
                    self.db.execute('INSERT INTO channel_numbers VALUES (?,?)',(row[0],number))
        now=int(time.time())
        boundary=self.db.execute('SELECT MIN(stop) FROM programmes WHERE stop>?',(now,)).fetchone()[0]
        self.next_update=min(boundary or now+60,(now//1800+1)*1800)
        where, params = self.filtered()
        self.total = self.db.execute('SELECT COUNT(*) FROM channels c WHERE '+where, params).fetchone()[0]
        self.offset = max(0, min(self.offset, max(0, (self.total-1)//ROWS*ROWS)))
        rows = self.db.execute('SELECT c.* FROM channels c WHERE '+where+' ORDER BY COALESCE((SELECT position FROM display_order WHERE kind="channels" AND item=c.url),2147483647), c.rowid LIMIT ? OFFSET ?', params+[ROWS, self.offset]).fetchall()
        self.getControl(12).setLabel(stamp(self.when, True) + '  •  ' + (self.group or 'All groups'))
        for col in range(4):
            self.getControl(20+col).setLabel(stamp(self.when+col*1800))
        filters = (' • Search: '+self.query if self.query else '') + (' • Favourites' if self.fav else '')
        self.getControl(14).setLabel('{}–{} of {:,} channels{}'.format(self.offset+1 if rows else 0, self.offset+len(rows), self.total, filters))
        self.getControl(15).setText('Select a programme to play live or catch-up. INFO opens the full scrollable description. Right-click / C opens programme options.')
        for i, channel in enumerate(rows):
            y = TOP+i*HEIGHT
            number = self.db.execute('SELECT number FROM channel_numbers WHERE url=?',(channel['url'],)).fetchone()[0]
            line = [self.button(24, y, LEFT-32, '', channel, channel_button=True)]
            name = xbmcgui.ControlLabel(34, y, LEFT-130, HEIGHT-4, channel['name'], font='font13', textColor='FFFFFFFF')
            number_label = xbmcgui.ControlLabel(LEFT-68, y, 48, HEIGHT-4, str(number), font='font13', textColor='FFFFFFFF', alignment=1)
            for label in (name,number_label):
                self.addControl(label); self.buttons.append(label)
            if provider.supports_archive(channel,self.archive_ids):
                icon=xbmcgui.ControlImage(LEFT-100,y+5,23,23,os.path.join(MEDIA,'catchup.png'))
                self.addControl(icon);self.buttons.append(icon)
            programmes = self.db.execute('SELECT * FROM programmes WHERE epg=? AND start<? AND stop>? ORDER BY start LIMIT 80', (channel['epg'], self.when+7200, self.when)).fetchall()
            cursor = self.when
            def add_segment(start, end, title, p=None):
                x, width = cell(start, end, self.when)
                if width > 3:
                    line.append(self.button(x, y, width-3, title if width>45 else '', channel, p))
            for programme in programmes:
                start, end = max(cursor, programme['start']), programme['stop']
                if start > cursor:
                    add_segment(cursor, start, 'No listing — watch live')
                if end > start:
                    add_segment(start, end, programme['title'], programme)
                    cursor = max(cursor, end)
                if cursor >= self.when+7200:
                    break
            if cursor < self.when+7200:
                add_segment(cursor, self.when+7200, 'No listing — watch live')
            self.lines.append(line)
        self.lock_navigation()
        if self.lines:
            self.setFocus(self.lines[0][0])
        else:
            self.getControl(15).setText('No matching channels. Try Refresh, Groups or Search to reset the filter.')

    def onFocus(self, ident):
        if self.mode!='live' and ident in getattr(self,'vod_mapping',{}):
            item=self.vod_mapping[ident]
            cached=self.vod_details.get(self.vod_key(self.mode,item))
            display=dict(item)
            if cached:display.update(cached)
            info=display.get('info') or {}
            self.getControl(16).setLabel(item.get('name') or item.get('title') or '')
            self.getControl(15).setText(str(display.get('plot') or info.get('plot') or 'Select to view details, play, or browse seasons.'))
            self.getControl(18).setImage(self.artwork(display))
            self.getControl(32).setLabel('  •  '.join(str(v) for v in (item.get('year') or info.get('releasedate'),item.get('genre') or info.get('genre'),item.get('rating') and 'Rating '+str(item['rating'])) if v))
            self.art_serial+=1
            self.art_request=None if cached is not None else (self.art_serial,self.mode,dict(item),time.time())
            return
        if ident in self.mapping:
            self.selected = self.mapping[ident]
            channel, p = self.selected
            if not p:
                p = self.db.execute('SELECT * FROM programmes WHERE epg=? AND start<=? AND stop>? ORDER BY start LIMIT 1',(channel['epg'],int(time.time()) if self.follow_now else self.when,int(time.time()) if self.follow_now else self.when)).fetchone()
                self.selected=(channel,p)
            text = p['title'] if p else channel['name']
            self.getControl(31).setImage(channel['logo'] or '')
            timing = '{} min | {} - {}'.format(max(1,(p['stop']-p['start'])//60),stamp(p['start']),stamp(p['stop'])) if p else ''
            self.getControl(32).setLabel(channel['name']+' | '+timing if timing else channel['name'])
            self.getControl(33).setLabel('')
            self.getControl(16).setLabel(text)
            self.getControl(15).setText(p['description'] if p else 'No programme description supplied.')
            meta=self.db.execute('SELECT * FROM programme_metadata WHERE epg=? AND start=?',(channel['epg'],p['start'])).fetchone() if p else None
            self.getControl(18).setImage(meta['image'] if meta and meta['image'] else '')
            if meta:
                extra=' / '.join(v for v in (meta['category'],meta['date'],meta['episode']) if v)
                if extra:self.getControl(12).setLabel(extra)
            self.art_serial+=1
            self.art_request=None
            if p and not (meta and meta['image']) and (ADDON.getSetting('art.provider')!='false' or ADDON.getSetting('art.tmdb_key') or ADDON.getSetting('art.tvmaze')=='true'):
                self.art_request=(self.art_serial,'live',{'title':p['title'],'date':meta['date'] if meta else '', 'category':meta['category'] if meta else ''},time.time())

    @staticmethod
    def artwork(item):
        info=item.get('info') or {}
        art=item.get('backdrop_path') or info.get('backdrop_path') or item.get('cover_big') or info.get('cover_big') or item.get('stream_icon') or item.get('cover') or item.get('movie_image') or info.get('movie_image') or ''
        if isinstance(art,list):art=next((a for a in art if isinstance(a,str) and a),'')
        return art if isinstance(art,str) else ''

    @staticmethod
    def vod_key(mode,item):
        return (mode,str(item.get('stream_id') or item.get('series_id') or item.get('id') or item.get('name')))

    def apply_art_results(self):
        # Only the UI update loop changes controls; replies are selection-scoped.
        while self.art_results:
            serial,mode,item,data=self.art_results.pop(0)
            if self.art_stop.is_set() or serial!=self.art_serial or mode!=self.mode:
                continue
            if mode=='live':
                if data.get('image'):self.getControl(18).setImage(data['image'])
            else:
                self.vod_details[self.vod_key(mode,item)]=data
                art=self.artwork(data)
                if art and art!=self.artwork(item):self.getControl(18).setImage(art)
                plot=data.get('plot') or item.get('plot')
                if plot:self.getControl(15).setText(str(plot))

    def art_worker(self):
        handled=None
        while not self.art_stop.wait(0.15):
            request=self.art_request
            if not request or request[0]==handled:continue
            if time.time()-request[3]<0.4:continue
            serial,mode,item,_=request;handled=serial
            try:
                if mode=='live':data=metadata.lookup(item)
                elif mode=='movies':data=provider.vod_info(mode,item)
                elif mode=='series':data=provider.api('get_series_info',series_id=item['series_id']).get('info',{})
                else:continue
                if isinstance(data,dict) and not self.art_stop.is_set():
                    self.art_results.append((serial,mode,item,data))
            except Exception:
                pass  # Artwork is optional; catalogue and playback stay usable.

    def watch(self, channel):
        url = channel['url']
        if isinstance(url, bytes):
            url = url.decode('utf-8', 'replace')
        if not url:
            ui.message('OTB TV Guide', 'No stream mapped to this channel. Refresh the playlist.')
            return
        if self.preview_url == url and self.preview_player.isPlayingVideo():
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            return
        self.preview_url = url
        self.preview_channel = channel
        self.playback_failure = None
        self.playback_prompted = False
        self.preview_player.reset()
        li = xbmcgui.ListItem(label=channel['name'], path=url)
        li.getVideoInfoTag().setTitle(channel['name'])
        # Keep the guide window alive behind fullscreen video. Kodi Back returns
        # to this window, whose video control shows the continuing stream.
        self.preview_player.play(url, li, windowed=False)
        self.preview_started_deadline = time.time()+15
        playback_state.remember(channel,url)
        if self.db.execute('SELECT 1 FROM channels WHERE url=?',(url,)).fetchone():
            guide_data.remember_channel(self.db,channel)

    def alternate_streams(self, channel):
        epg=str(channel['epg'] or '')
        name=str(channel['name'] or '')
        tvg=str(channel['tvg_name'] or '')
        rows=self.db.execute('''SELECT * FROM channels WHERE url<>? AND (
          (epg<>'' AND epg=?) OR lower(name)=lower(?) OR (tvg_name<>'' AND lower(tvg_name)=lower(?)))
          AND NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=channels.url)
          AND NOT EXISTS(SELECT 1 FROM hidden_categories h WHERE h.mode='live' AND h.category=channels.grp)
          ORDER BY CASE WHEN epg=? AND epg<>'' THEN 0 ELSE 1 END,grp,name LIMIT 12''',
          (channel['url'],epg,name,tvg,epg)).fetchall()
        return rows

    def recover_playback(self):
        failure=self.playback_failure
        self.playback_failure=None
        if not failure or self.playback_prompted:return
        self.playback_prompted=True
        channel=failure
        alternatives=self.alternate_streams(channel)
        labels=['Retry '+channel['name']]
        if alternatives:labels.append('Try another mapped stream')
        labels.append('Return to guide')
        choice=ui.select('Playback recovery',labels,'The guide stays open while you choose another stream.')
        if choice==0:
            self.playback_prompted=False;self.watch(channel);return
        if alternatives and choice==1:
            pick=ui.select('Mapped streams',[c['name']+'  |  '+(c['grp'] or 'Other') for c in alternatives])
            if pick>=0:
                self.playback_prompted=False;self.watch(alternatives[pick]);return
        self.preview_url=None;self.preview_channel=None

    def play_programme(self,channel,programme):
        try:
            url=provider.programme_url(channel,programme)
            selected=dict(channel);selected['url']=url
            if programme:selected['name']=programme['title']
            self.watch(selected)
        except ValueError as exc:
            ui.message('Programme playback',str(exc))
        except Exception:
            ui.message('Programme playback','Could not verify catch-up with the provider. Please try again.')

    def details(self):
        if not self.selected:
            return
        channel, p = self.selected
        choice = ui.select(channel['name'], ['Watch live', 'Programme information', 'Add / remove favourite', 'Hide channel', 'Watch catch-up','Remind me','Remind for this series'], 'Programme actions')
        if choice == 0:
            self.watch(channel)
        elif choice == 1:
            guide_features.programme_information(self)
        elif choice == 2:
            with self.db:
                if self.db.execute('SELECT 1 FROM favourites WHERE id=?', (channel['id'],)).fetchone():
                    self.db.execute('DELETE FROM favourites WHERE id=?', (channel['id'],))
                else:
                    self.db.execute('INSERT INTO favourites VALUES (?)', (channel['id'],))
            self.render()

        elif choice == 3:
            with self.db:
                self.db.execute('INSERT OR REPLACE INTO hidden VALUES (?,?)', (channel['url'],channel['name']))
            self.render()
        elif choice == 4:
            try:
                selected=dict(channel);selected['url']=provider.catchup_url(channel,p);selected['name']=p['title']
                self.watch(selected)
            except ValueError as exc:
                ui.message('Catch-up',str(exc))

        elif choice in (5,6):guide_features.add_reminder(self,choice==6)

    def settings(self):
        choice = ui.select('Guide settings', ['Sources and refresh settings', 'Clear search and group filters', 'Export diagnostics', 'Restore hidden channels'], 'All controls use the OTB interface.')
        if choice == 0:
            ui.settings(ADDON)
            self.render()
        elif choice == 1:
            self.query, self.group, self.fav = '', '', False
            self.offset = 0
            self.render()
        elif choice == 2:
            path = os.path.join(os.path.expanduser('~'), 'Downloads', 'OTB-Guide-Diagnostics.txt')
            source = os.path.join(PROFILE, 'diagnostics.txt')
            with open(path, 'w', encoding='utf-8') as out:
                out.write('OTB Guide 2.8.2\nKodi: '+xbmc.getInfoLabel('System.BuildVersion')+'\n')
                if os.path.exists(source):
                    with open(source, encoding='utf-8') as f:
                        out.write(f.read())
                else:
                    out.write('No recorded guide exceptions.\n')
            ui.message('Diagnostics exported', path)

        elif choice == 3:
            rows=self.db.execute('SELECT url,name FROM hidden ORDER BY name').fetchall()
            selected=ui.multiselect('Restore hidden channels',[r['name'] for r in rows])
            if selected:
                with self.db:
                    self.db.executemany('DELETE FROM hidden WHERE url=?', [(rows[i]['url'],) for i in selected])
                self.render()

    def update_refresh_status(self):
        try:
            if self.refresh_running or self.refresh_state=='updating':
                self.getControl(38).setLabel('Updating guide…')
                return
            row=self.db.execute("SELECT value FROM meta WHERE key='updated'").fetchone()
            if row:
                updated=int(row[0])
                today=time.localtime(updated).tm_yday==time.localtime().tm_yday
                label=time.strftime('%H:%M',time.localtime(updated)) if today else time.strftime('%d %b %H:%M',time.localtime(updated))
                prefix='Update failed • last ' if self.refresh_state=='failed' else 'Guide updated '
                self.getControl(38).setLabel(prefix+label)
            else:self.getControl(38).setLabel('Update failed' if self.refresh_state=='failed' else 'Guide not updated')
        except Exception:
            self.getControl(38).setLabel('')

    def start_background_refresh(self,manual=False):
        if self.refresh_running:
            if manual:
                self.refresh_detail='An EPG refresh is already running.'
                self.getControl(38).setLabel('Guide update already running')
            return
        self.refresh_running=True;self.refresh_state='updating';self.refresh_completed=False
        self.update_refresh_status()
        def status(state,detail=''):
            self.refresh_state=state;self.refresh_detail=detail
        def worker():
            result=refresh_background(status)
            self.refresh_running=False
            self.refresh_completed=bool(result)
        threading.Thread(target=worker,daemon=True).start()
        if manual:self.getControl(38).setLabel('Updating guide… current listings remain available')

    def draw_categories(self):
        if self.mode == 'live':
            self.category_list=[('', 'All channels')]+[(r[0],r[0]) for r in self.db.execute('SELECT DISTINCT grp FROM channels ORDER BY grp')]
        else:
            self.category_list=[('', 'All categories')]+[(str(r['category_id']),r['category_name']) for r in self.catalogue_groups]
        if self.mode=='live':self.category_list += [(r[0],r[1]) for r in self.db.execute('SELECT id,name FROM collections ORDER BY name')]
        order=dict(self.db.execute('SELECT item,position FROM display_order WHERE kind=?',('categories:'+self.mode,)))
        self.category_list=self.category_list[:1]+sorted(self.category_list[1:],key=lambda c:order.get(c[0],2147483647))
        hidden={r[0] for r in self.db.execute('SELECT category FROM hidden_categories WHERE mode=?',(self.mode,))}
        self.category_list=[c for c in self.category_list if c[0] not in hidden]
        self.category_offset=max(0,min(self.category_offset,max(0,len(self.category_list)-6)))
        for i in range(6):
            n=self.category_offset+i
            c=self.getControl(200+i)
            c.setVisible(n<len(self.category_list))
            if n<len(self.category_list):
                c.setLabel(self.category_list[n][1])

    def switch_mode(self,mode):
        self.art_serial+=1
        self.art_request=None
        self.art_results=[]
        self.mode=mode; self.group=''; self.query=''; self.offset=0; self.category_offset=0; self.history=[]
        if mode != 'live':
            action='get_vod_categories' if mode=='movies' else 'get_series_categories'
            self.catalogue_groups=provider.api(action)
            self.load_catalogue()
        self.render()

    def load_catalogue(self):
        action='get_vod_streams' if self.mode=='movies' else 'get_series'
        params={'category_id':self.group} if self.group else {}
        self.catalogue=provider.api(action,**params)
        if not isinstance(self.catalogue,list):
            raise ValueError('Provider returned an invalid catalogue.')

    def render_catalogue(self):
        self.getControl(12).setLabel({'movies':'MOVIES','series':'TV SHOWS','episodes':'EPISODES'}.get(self.mode,self.mode))
        for i in range(4): self.getControl(20+i).setLabel('')
        hidden={r[0] for r in self.db.execute('SELECT category FROM hidden_categories WHERE mode=?',(self.mode,))}
        entries=[c for c in self.catalogue if str(c.get('category_id','')) not in hidden and self.query.casefold() in (c.get('name') or c.get('title') or '').casefold()]
        self.total=len(entries)
        self.offset=max(0,min(self.offset,max(0,(self.total-1)//ROWS*ROWS)))
        rows=entries[self.offset:self.offset+ROWS]
        self.vod_mapping={}
        for i,item in enumerate(rows):
            x=24+(i%4)*310; y=352+(i//4)*164
            title=item.get('name') or item.get('title') or 'Untitled'
            art=self.artwork(item)
            image=xbmcgui.ControlImage(x+4,y+4,294,110,str(art or ''),aspectRatio=1)
            self.addControl(image); self.buttons.append(image)
            # Keep catalogue artwork stable; enrich only the selected hero.
            b=xbmcgui.ControlButton(x,y,302,150,title,
                focusTexture=os.path.join(MEDIA,'tile-focus.png'),noFocusTexture=os.path.join(MEDIA,'tile-clear.png'),
                textColor='FFFFFFFF',focusedColor='FFFFFFFF',font='font13',textOffsetX=10,textOffsetY=118,alignment=0)
            self.addControl(b);self.buttons.append(b)
            self.mapping[b.getId()]=({},None)
            del self.mapping[b.getId()]
            self.vod_mapping[b.getId()]=item
            self.lines.append([b])
        self.lock_navigation()
        self.getControl(14).setLabel('{}–{} of {:,} titles'.format(self.offset+1 if rows else 0,self.offset+len(rows),self.total))
        if rows: self.setFocus(self.lines[0][0])

    def open_vod(self,item):
        if self.mode=='series':
            data=provider.api('get_series_info',series_id=item['series_id'])
            episodes=data.get('episodes') or {}
            seasons=sorted(episodes,key=lambda x:int(x) if str(x).isdigit() else 999)
            choice=ui.select(item.get('name','Seasons'),['Season '+str(n) for n in seasons])
            if choice>=0:
                self.history.append((self.mode,self.catalogue,self.offset))
                self.catalogue=episodes[seasons[choice]]; self.mode='episodes'; self.offset=0; self.query=''; self.render()
            return
        info=provider.vod_info(self.mode,item) if self.mode=='movies' else (item.get('info') or {})
        title=item.get('name') or item.get('title') or 'Video'
        plot=info.get('plot') or item.get('plot') or 'No description supplied.'
        self.getControl(16).setLabel(title); self.getControl(15).setText(str(plot))
        choice=ui.select(title,['Play','Full description'])
        if choice==0:
            ident=item.get('stream_id') if self.mode=='movies' else item.get('id')
            self.pending=(provider.stream('movie' if self.mode=='movies' else 'series',ident,item.get('container_extension') or 'mp4'),title)
            self.close()
        elif choice==1:
            ui.textviewer(title,str(plot))

    def onClick(self, ident):
        if self.number_entry:
            self.jump_number();return
        try:
            if ident in getattr(self,'vod_mapping',{}) and self.mode!='live':
                self.open_vod(self.vod_mapping[ident])
            elif ident in self.mapping:
                self.selected = self.mapping[ident]
                self.play_programme(*self.selected)
            elif ident == 116:
                android_apps.menu()
            elif ident == 117:
                guide_features.recent_channels(self)
            elif ident == 115:
                self.follow_now=True
                self.when=int(time.time())//1800*1800
                if self.mode!='live':self.switch_mode('live')
                else:self.render()
                self.setFocusId(115)
            elif ident in (112,113,114):
                self.switch_mode({112:'live',113:'movies',114:'series'}[ident])
            elif ident in (206,207):
                self.category_offset+= -6 if ident==206 else 6; self.draw_categories()
            elif 200<=ident<=205:
                self.group=self.category_list[self.category_offset+ident-200][0]; self.offset=0
                if self.mode in ('movies','series'): self.load_catalogue()
                self.render()
            elif ident == 100:
                labels=['Jump to now','Recent channels','Earlier programmes (-4 hours)','Later programmes (+4 hours)','All groups','Search','Favourites','Refresh guide','Settings','Programme information','Exit guide','Hide / restore categories','Android apps','Reorder channels','Reorder categories','Search programmes','Programme reminders','Custom collections','Back up preferences','Restore preferences','Playback mini-guide']
                choice=ui.select('Guide options',labels,'Guide, playback and organisation')
                if choice==1:guide_features.recent_channels(self)
                elif choice==11:self.manage_categories()
                elif choice==12:android_apps.menu()
                elif choice==13:self.reorder_items(True)
                elif choice==14:self.reorder_items(False)
                elif choice==15:guide_features.programme_search(self)
                elif choice==16:guide_features.reminders(self)
                elif choice==17:guide_features.collections(self)
                elif choice==18:guide_features.backup(self)
                elif choice==19:guide_features.backup(self,True)
                elif choice==20:mini_guide.show(ROOT,self.db)
                elif choice==0:
                    self.follow_now=True
                    self.when=int(time.time())//1800*1800;self.render()
                elif choice>1:self.onClick(99+choice)
            elif ident in (101,102):
                self.follow_now=False
                self.when += -14400 if ident == 101 else 14400; self.render()
            elif ident == 103:
                groups = [r[0] for r in self.db.execute('SELECT DISTINCT grp FROM channels ORDER BY grp')]
                result = ui.select('Channel groups', ['All groups']+groups)
                if result >= 0:
                    self.group = '' if result == 0 else groups[result-1]
                    self.offset=0; self.render()
            elif ident == 104:
                value = ui.input_text('Search channel names', self.query)
                if value is not None:self.query=value
                self.offset=0; self.render()
            elif ident == 105:
                self.fav = not self.fav; self.offset=0; self.render()
            elif ident == 106:
                self.start_background_refresh(manual=True)
            elif ident == 107:
                self.settings()
            elif ident == 108:
                if self.mode=='live': self.details()
            elif ident == 109:
                self.close()
            elif ident in (110,111):
                self.offset += -ROWS if ident == 110 else ROWS; self.render()
        except Exception:
            record_error('Control '+str(ident))
            ui.message('OTB TV Guide', 'This action failed. Settings > Export diagnostics will save the error details.')

    def lock_navigation(self):
        # Kodi applies native navigation before Python callbacks. Self-links keep
        # the original focus stable so every remote press is handled once.
        controls=[self.getControl(n) for n in list(range(100,118))+list(range(200,208))]
        controls += [b for line in self.lines for b in line]
        for c in controls:
            c.controlLeft(c); c.controlRight(c); c.controlUp(c); c.controlDown(c)

    def navigate(self, direction):
        focus=self.getFocusId()
        tabs=[112,113,114,116,117,100]
        categories=[206]+list(range(200,200+min(6,len(self.category_list)-self.category_offset)))+[207]
        foot=[115]
        bands=[tabs,categories,foot]
        position=next(((r,c) for r,line in enumerate(self.lines) for c,b in enumerate(line) if b.getId()==focus),None)
        if position is not None:
            r,c=position
            if self.mode=='live':
                if direction in (1,2):
                    if (direction==1 and c==0) or (direction==2 and c==len(self.lines[r])-1):
                        self.follow_now=False
                        self.when+=-14400 if direction==1 else 14400
                        self.render()
                        r=min(r,len(self.lines)-1)
                        if self.lines:self.setFocus(self.lines[r][0 if direction==1 else -1])
                        return
                    c=max(0,min(len(self.lines[r])-1,c+(-1 if direction==1 else 1)))
                else:
                    target=r+(-1 if direction==3 else 1)
                    if target<0:
                        if self.offset>0:
                            self.offset=max(0,self.offset-ROWS); self.render(); self.setFocus(self.lines[0][min(c,len(self.lines[0])-1)])
                        else: self.setFocusId(200)
                        return
                    if target>=len(self.lines):
                        self.setFocusId(115); return
                    else: r=target
                    c=min(c,len(self.lines[r])-1)
                self.setFocus(self.lines[r][c]); return
            step={1:-1,2:1,3:-4,4:4}[direction]; target=r+step
            if target<0:
                if direction==3: self.setFocusId(200)
                elif self.offset>0:
                    self.offset=max(0,self.offset-8); self.render(); self.setFocus(self.lines[-1][0])
                return
            if target>=len(self.lines):
                if self.offset+len(self.lines)<self.total:
                    self.offset+=8; self.render(); self.setFocus(self.lines[0][0])
                else: self.setFocusId(115)
                return
            self.setFocus(self.lines[target][0]); return
        for index,band in enumerate(bands):
            if focus not in band: continue
            n=band.index(focus)
            if direction in (1,2):
                self.setFocusId(band[(n+(-1 if direction==1 else 1))%len(band)])
            elif direction==3:
                if index==2 and self.lines: self.setFocus(self.lines[-1][0])
                else: self.setFocusId(115 if index==0 else bands[index-1][0])
            elif index==1:
                if self.lines: self.setFocus(self.lines[0][0])
                else: self.setFocusId(115)
            elif index==2:
                if self.mode=='live' and self.lines:
                    if self.offset+len(self.lines)<self.total:
                        self.offset+=ROWS
                        self.render()
                        self.setFocus(self.lines[0][0])
                    # At the final page, stay on Now instead of wrapping channels.
                else:self.setFocusId(112)
            else: self.setFocusId(bands[index+1][0])
            return

    def reorder_items(self, channels):
        mode='series' if self.mode=='episodes' else self.mode
        kind='channels' if channels else 'categories:'+mode
        if channels:
            items=[(r[0],r[1]) for r in self.db.execute('SELECT url,name FROM channels ORDER BY rowid')]
        elif mode=='live':
            items=[(r[0],r[0]) for r in self.db.execute('SELECT DISTINCT grp FROM channels ORDER BY grp')]
        else:
            items=[(str(c['category_id']),c['category_name']) for c in self.catalogue_groups]
        if not channels and mode=='live':items += [(r[0],r[1]) for r in self.db.execute('SELECT id,name FROM collections ORDER BY name')]
        original=list(items)
        order=dict(self.db.execute('SELECT item,position FROM display_order WHERE kind=?',(kind,)))
        items.sort(key=lambda c:order.get(c[0],2147483647))
        hidden={r[0] for r in self.db.execute('SELECT url FROM hidden')} if channels else {r[0] for r in self.db.execute('SELECT category FROM hidden_categories WHERE mode=?',(mode,))}
        result=ordering.edit(ROOT,'Organise channels' if channels else 'Organise categories',items,original,hidden)
        if result is None:return
        items,hidden=result
        with self.db:
            self.db.execute('DELETE FROM display_order WHERE kind=?',(kind,))
            self.db.executemany('INSERT INTO display_order VALUES (?,?,?)',[(kind,c[0],i) for i,c in enumerate(items)])
            if channels:
                self.db.execute('DELETE FROM hidden')
                self.db.executemany('INSERT INTO hidden VALUES (?,?)',[(key,name) for key,name in items if key in hidden])
            else:
                self.db.execute('DELETE FROM hidden_categories WHERE mode=?',(mode,))
                self.db.executemany('INSERT INTO hidden_categories VALUES (?,?)',[(mode,key) for key in hidden])
        self.group='';self.offset=0;self.category_offset=0;self.render()
        self.setFocusId(100)

    def manage_categories(self):
        mode='series' if self.mode=='episodes' else self.mode
        categories=[(r[0],r[0]) for r in self.db.execute('SELECT DISTINCT grp FROM channels ORDER BY grp')] if mode=='live' else [(str(c['category_id']),c['category_name']) for c in self.catalogue_groups]
        if mode=='live':categories += [(r[0],r[1]) for r in self.db.execute('SELECT id,name FROM collections ORDER BY name')]
        hidden={r[0] for r in self.db.execute('SELECT category FROM hidden_categories WHERE mode=?',(mode,))}
        chosen=ui.multiselect('Select categories to HIDE', [c[1] for c in categories], preselect=[i for i,c in enumerate(categories) if c[0] in hidden])
        if chosen is None:return
        with self.db:
            self.db.execute('DELETE FROM hidden_categories WHERE mode=?',(mode,))
            self.db.executemany('INSERT INTO hidden_categories VALUES (?,?)',[(mode,categories[i][0]) for i in chosen])
        self.group='';self.offset=0;self.category_offset=0;self.render()

    def close(self):
        self.save_position()
        self.active=False
        super().close()

    def cancel_number(self):
        self.number_entry='';self.number_deadline=0
        self.getControl(37).setLabel('')

    def number_digit(self,digit):
        if time.monotonic()>self.number_deadline:self.number_entry=''
        self.number_entry=(self.number_entry+str(digit))[-6:]
        self.number_deadline=time.monotonic()+1.5
        self.getControl(37).setLabel('Channel '+self.number_entry+' — wait to highlight')

    def jump_number(self):
        text=self.number_entry
        self.cancel_number()
        if not text:return
        # Search all visible channels; a number can leave a category/filter.
        row=self.db.execute("SELECT c.id FROM channels c JOIN channel_numbers n ON n.url=c.url\n          WHERE n.number=? AND NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=c.url)\n          AND NOT EXISTS(SELECT 1 FROM hidden_categories h WHERE h.mode='live' AND h.category=c.grp)",(int(text),)).fetchone()
        if not row:
            self.getControl(37).setLabel('Channel '+text+' is unavailable or hidden')
            return
        self.group='';self.query='';self.fav=False;self.category_offset=0
        where,params=self.filtered()
        rows=self.db.execute('SELECT c.id FROM channels c WHERE '+where+' ORDER BY COALESCE((SELECT position FROM display_order WHERE kind="channels" AND item=c.url),2147483647),c.rowid',params).fetchall()
        index=next((i for i,c in enumerate(rows) if c[0]==row[0]),None)
        if index is None:
            self.getControl(37).setLabel('Channel '+text+' is excluded by guide settings');return
        self.offset=index//ROWS*ROWS;self.render()
        self.setFocus(self.lines[index%ROWS][0])
        self.getControl(37).setLabel('Channel '+text+' — OK to play')

    def update_clock(self):
        # Format independently of Kodi regional settings and infolabel parsing.
        value=time.strftime('%H:%M',time.localtime())
        if value!=getattr(self,'clock_text',None):
            self.getControl(34).setLabel(value)
            self.clock_text=value

    def tick(self):
        self.apply_art_results()
        self.update_clock()
        self.update_refresh_status()
        if self.refresh_completed and self.mode=='live' and xbmcgui.getCurrentWindowId()==getattr(self,'window_id',None):
            self.refresh_completed=False
            focus=self.getFocusId();self.render();self.update_refresh_status()
            if focus in (100,112,113,114,115,116,117) or 200<=focus<=207:self.setFocusId(focus)
        if self.preview_channel and not self.preview_player.started and self.preview_started_deadline and time.time()>=self.preview_started_deadline:
            self.preview_started_deadline=0;self.preview_player.stop();self.playback_failure=self.preview_channel
        if self.preview_player.error and self.preview_channel:
            self.preview_player.error=False;self.playback_failure=self.preview_channel
        if self.playback_failure and xbmcgui.getCurrentWindowId()==getattr(self,'window_id',None):self.recover_playback()
        if self.number_entry and time.monotonic()>=self.number_deadline:
            if self.mode=="live" and xbmcgui.getCurrentWindowId()==getattr(self,"window_id",None):self.jump_number()
            else:self.cancel_number()
        if self.archive_dirty and self.mode=='live' and xbmcgui.getCurrentWindowId()==getattr(self,'window_id',None):
            self.archive_dirty=False
            focus=self.getFocusId()
            position=next(((r,c) for r,line in enumerate(self.lines) for c,b in enumerate(line) if b.getId()==focus),None)
            self.render()
            if position and self.lines:
                r,c=position;r=min(r,len(self.lines)-1);self.setFocus(self.lines[r][min(c,len(self.lines[r])-1)])
            elif focus in (100,112,113,114,115,116) or 200<=focus<=207:self.setFocusId(focus)
        if self.mode!='live' or not self.follow_now or time.time()<self.next_update:return
        if xbmcgui.getCurrentWindowId()!=getattr(self,'window_id',None):return
        focus=self.getFocusId()
        position=next(((r,c) for r,line in enumerate(self.lines) for c,b in enumerate(line) if b.getId()==focus),None)
        self.when=int(time.time())//1800*1800
        self.render()
        if position and self.lines:
            r,c=position;r=min(r,len(self.lines)-1);self.setFocus(self.lines[r][min(c,len(self.lines[r])-1)])
        elif focus in (100,112,113,114,115,116,110,111) or 200<=focus<=207:self.setFocusId(focus)

    def onAction(self, action):
        ident = action.getId()
        if self.mode=='live' and 58<=ident<=67:
            self.number_digit(ident-58);return
        if self.number_entry:
            if ident in (9,10,92):self.cancel_number();return
            if ident==110:
                self.number_entry=self.number_entry[:-1]
                self.number_deadline=time.monotonic()+1.5
                self.getControl(37).setLabel('Channel '+self.number_entry);return
            if ident in (1,2,3,4,5,6):self.cancel_number()
        if ident in (9,10,92):
            if self.getFocusId() in self.mapping and self.mode=='live':
                self.setFocusId(200); return
            if self.history:
                self.mode,self.catalogue,self.offset=self.history.pop(); self.render()
            elif self.mode!='live': self.switch_mode('live')
            else: self.close()
        elif ident == 11 and self.mode == 'live':
            guide_features.programme_information(self)
        elif ident in (101,117) and self.mode == 'live':
            self.details()
        elif ident in (104,105):
            self.onClick(110 if ident==104 else 111)
        elif ident in (1,2,3,4):
            self.navigate(ident)
        elif ident in (5,6):
            self.onClick(110 if ident == 5 else 111)

class SessionPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset()
    def reset(self):
        self.ended=False
        self.started=False
        self.error=False
    def onAVStarted(self): self.started=True;self.ended=False;self.error=False
    def onPlayBackStopped(self): self.ended=True
    def onPlayBackEnded(self): self.ended=True
    def onPlayBackError(self): self.ended=True;self.error=True

window = Guide('guide.xml', ROOT, 'Default', '720p')
monitor=xbmc.Monitor()
try:
    playback_keys.install()
    while not monitor.abortRequested():
        window.pending=None
        window.ready=False
        window.active=True
        window.show()
        while window.active and not monitor.waitForAbort(0.5):
            window.tick()
        if not window.pending: break
        url,title=window.pending
        player=SessionPlayer()
        li=xbmcgui.ListItem(label=title,path=url)
        li.getVideoInfoTag().setTitle(title)
        player.play(url,li,windowed=False)
        deadline=time.time()+30
        while not player.started and not player.ended and time.time()<deadline:
            if monitor.waitForAbort(0.2): break
        if player.started:
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            while not player.ended and not monitor.abortRequested():
                if monitor.waitForAbort(0.25): break
        elif not monitor.abortRequested():
            player.stop()
            ui.message('Playback failed','Kodi could not start this stream. Try another title or check your provider connection.')
finally:
    playback_keys.remove()
    xbmc.Player().stop()
    window.art_stop.set()
    window.db.close()
    del window
