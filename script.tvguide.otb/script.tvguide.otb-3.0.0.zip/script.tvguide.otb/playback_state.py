"""Identify guide playback without putting stream credentials in window properties."""
import hashlib
import xbmc
import xbmcgui

def digest(url):
    return hashlib.sha256(url.encode('utf-8')).hexdigest()

def remember(channel,url):
    home=xbmcgui.Window(10000)
    home.setProperty('OTB.PlayingChannel',str(channel['id']))
    home.setProperty('OTB.PlayingFile',digest(url))

def playing_index(channels):
    try:
        url=xbmc.Player().getPlayingFile()
        direct=next((i for i,c in enumerate(channels) if c['url']==url),None)
        if direct is not None:return direct
        home=xbmcgui.Window(10000)
        if digest(url)==home.getProperty('OTB.PlayingFile'):
            ident=home.getProperty('OTB.PlayingChannel')
            return next((i for i,c in enumerate(channels) if str(c['id'])==ident),0)
    except Exception:pass
    return 0
