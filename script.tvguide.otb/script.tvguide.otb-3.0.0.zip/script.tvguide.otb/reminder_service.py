"""Persisted programme notifications; no playback or provider startup actions."""
import os
import xbmc
import xbmcgui
import ui
from backend import PROFILE, record_error
from store import connect
from guide_data import initialize,due_reminders

def run():
    db=connect(os.path.join(PROFILE,'guide-v2.db'))
    initialize(db)
    monitor=xbmc.Monitor()
    try:
        while not monitor.abortRequested():
            try:
                for programme in due_reminders(db):
                    ui.message('Programme reminder',programme['name']+' - '+programme['title'])
            except Exception:record_error('Programme reminders')
            if monitor.waitForAbort(15):break
    finally:db.close()

if __name__=='__main__':run()
