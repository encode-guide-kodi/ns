"""Full-screen Android application launcher for OTB TV Guide."""
import json
import os
import re
from urllib.parse import unquote
import xbmc
import xbmcgui
import xbmcvfs
from backend import ADDON, PROFILE
import ui

ROOT=xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA=os.path.join(ROOT,'resources','media')
DIRECTORY='androidapp://sources/apps/'
LOGO_DIR=os.path.join(PROFILE,'app-logos')
LOGO_PREFS=os.path.join(PROFILE,'android-logo-overrides.json')
ANDROID_ICON='@android'
GENERIC_ICON='@generic'

# The first four entries intentionally preserve the original 2.8.0 setting slots.
SERVICES=[
    ('BBC iPlayer',('iplayer',),'Enjoy live and on demand BBC TV, news, sport, documentaries and entertainment.'),
    ('ITVX',('itvx','itv'),'Watch ITV live channels, catch-up, box sets and exclusive programmes.'),
    ('Channel 4',('channel4','channel 4','all4','all 4'),'Watch Channel 4 live and on demand, including entertainment, drama and documentaries.'),
    ('Netflix',('netflix',),'Open Netflix to continue watching films, series and your saved programmes.'),
    ('YouTube',('youtube',),'Watch YouTube videos, channels, live streams and subscriptions.'),
    ('Prime Video',('primevideo','prime video','amazon video'),'Open Prime Video for films, series and live entertainment.'),
    ('Disney+',('disneyplus','disney+','disney plus'),'Open Disney+ for films and series from Disney, Pixar, Marvel, Star Wars and more.'),
    ('My5',('my5','channel 5'),'Watch Channel 5 programmes live and on demand.'),
    ('VPN',('vpn','nordvpn','expressvpn','surfshark','ipvanish','cyberghost'),'Open your VPN app to manage privacy, regions and connection settings.'),
]

GENERIC_DESCRIPTIONS={
    'All apps':'Browse every Android application Kodi can detect on this device.',
    'Manage':'Choose the apps shown here, assign built-in shortcuts, or change shortcut logos.'
}

# User-supplied service logos are the default artwork on the Apps screen.
# Disney+ retains the clean bundled OTB fallback until replaced locally.
FALLBACK_ICONS={
    'BBC iPlayer':'bbc-iplayer-user.webp',
    'ITVX':'itvx-user.png',
    'Channel 4':'channel4-user.webp',
    'Netflix':'netflix-user.webp',
    'YouTube':'youtube-user.png',
    'Prime Video':'prime-video.png',
    'Disney+':'disneyplus.png',
    'My5':'my5-user.png',
    'VPN':'vpn-user.png',
    'All apps':'all-apps.png',
    'Manage':'manage.png',
}

HERO_ICONS={
    'Channel 4':'channel4-user-wide.png',
}


def _fallback_icon(name):
    filename=FALLBACK_ICONS.get(str(name or ''),'generic.png')
    return os.path.join(MEDIA,'app-icons',filename)


def _hero_fallback(name):
    filename=HERO_ICONS.get(str(name or ''))
    return os.path.join(MEDIA,'app-icons',filename) if filename else _fallback_icon(name)


def package(path):
    value=unquote(str(path or '').rstrip('/').rsplit('/',1)[-1])
    return value if re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+',value) else ''


def installed():
    found={}
    # VFS avoids JSON-RPC's file-media extension filtering of package entries.
    try:
        dirs,files=xbmcvfs.listdir(DIRECTORY)
        for path in dirs+files:
            ident=package(path)
            if ident:found[ident]={'file':DIRECTORY+ident,'label':ident,'thumbnail':''}
    except Exception:pass
    try:
        request={'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory','params':{'directory':DIRECTORY,'properties':['thumbnail']}}
        response=json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        for app in response.get('result',{}).get('files',[]):
            ident=package(app.get('file',''))
            if ident:
                app['package']=ident
                found[ident]=app
    except Exception:pass
    return sorted(found.values(),key=lambda a:(a.get('label') or package(a.get('file',''))).casefold())


def launch(app):
    ident=package(app.get('file','') if isinstance(app,dict) else app)
    if not ident:raise ValueError('Invalid Android app package')
    xbmc.Player().stop()
    xbmc.log('OTB Guide: launching Android package '+ident,xbmc.LOGINFO)
    xbmc.executebuiltin('StartAndroidActivity("'+ident+'")')


def custom_shortcuts():
    try:
        with open(os.path.join(PROFILE,'android-shortcuts.json'),encoding='utf-8') as f:rows=json.load(f)
        return [r for r in rows if isinstance(r,dict) and package(r.get('package','')) and isinstance(r.get('name'),str)] if isinstance(rows,list) else []
    except (OSError,ValueError):return []


def save_shortcuts(rows):
    path=os.path.join(PROFILE,'android-shortcuts.json')
    os.makedirs(PROFILE,exist_ok=True)
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(rows,f)
    os.replace(path+'.tmp',path)


def _load_logo_overrides():
    try:
        with open(LOGO_PREFS,encoding='utf-8') as f:data=json.load(f)
        if isinstance(data,dict):return {str(k):str(v) for k,v in data.items() if isinstance(v,str)}
    except (OSError,ValueError):pass
    return {}


def _save_logo_overrides(data):
    os.makedirs(PROFILE,exist_ok=True)
    with open(LOGO_PREFS+'.tmp','w',encoding='utf-8') as f:json.dump(data,f)
    os.replace(LOGO_PREFS+'.tmp',LOGO_PREFS)


def _thumb(app):
    if not isinstance(app,dict):return ''
    return app.get('thumbnail') or (app.get('art') or {}).get('thumb','') or ''


def _valid_local_logo(path):
    value=str(path or '').strip()
    if not value or value in (ANDROID_ICON,GENERIC_ICON):return value
    try:return value if xbmcvfs.exists(value) else ''
    except Exception:return ''


def _resolve_logo(name,app,override='',built_in=False):
    override=_valid_local_logo(override)
    if override and override not in (ANDROID_ICON,GENERIC_ICON):return override
    if override==ANDROID_ICON:return _thumb(app) or _fallback_icon(name)
    if override==GENERIC_ICON:return _fallback_icon('')
    # Built-in shortcuts deliberately use the supplied logos, not Kodi's Android icon.
    if built_in:return _fallback_icon(name)
    return _thumb(app) or _fallback_icon(name)


def _resolve_hero(name,app,override='',built_in=False):
    override=_valid_local_logo(override)
    if override and override not in (ANDROID_ICON,GENERIC_ICON):return override
    if override==ANDROID_ICON:return _thumb(app) or _hero_fallback(name)
    if override==GENERIC_ICON:return _fallback_icon('')
    if built_in:return _hero_fallback(name)
    return _thumb(app) or _fallback_icon(name)


def _find_service(apps,index):
    saved=ADDON.getSetting('android.shortcut.'+str(index)).strip()
    if saved:
        hit=next((a for a in apps if package(a.get('file',''))==saved),None)
        return hit or {'file':saved,'label':SERVICES[index][0],'thumbnail':''}
    terms=SERVICES[index][1]
    matches=[a for a in apps if any(t in ((a.get('label') or '')+' '+a.get('file','')).casefold() for t in terms)]
    return matches[0] if matches else None


def launcher_items():
    apps=installed();by_package={package(a.get('file','')):a for a in apps}
    logo_overrides=_load_logo_overrides()
    rows=[];used=set()
    for i,(name,_terms,description) in enumerate(SERVICES):
        app=_find_service(apps,i)
        if not app:continue
        ident=package(app.get('file',''))
        if not ident or ident in used:continue
        used.add(ident);override=logo_overrides.get(str(i),'')
        rows.append({'kind':'app','name':name,'package':ident,
                     'thumb':_resolve_logo(name,app,override,True),
                     'hero':_resolve_hero(name,app,override,True),
                     'description':description})
    for row in custom_shortcuts():
        ident=package(row.get('package',''))
        if not ident or ident in used:continue
        used.add(ident);app=by_package.get(ident,{})
        name=row.get('name','').strip() or app.get('label') or ident
        override=str(row.get('logo','') or '')
        rows.append({'kind':'app','name':name,'package':ident,
                     'thumb':_resolve_logo(name,app,override,False),
                     'hero':_resolve_hero(name,app,override,False),
                     'description':'Open {} from your Android device.'.format(name)})
    # Fill spare launcher positions with installed apps so the screen is useful without manual pinning.
    for app in apps:
        ident=package(app.get('file',''))
        if not ident or ident in used:continue
        used.add(ident);name=app.get('label') or ident
        rows.append({'kind':'app','name':name,'package':ident,'thumb':_thumb(app) or _fallback_icon(name),
                     'hero':_thumb(app) or _fallback_icon(name),
                     'description':'Open {} from your Android device.'.format(name)})
        if len(rows)>=10:break
    rows.append({'kind':'all','name':'All apps','package':'','thumb':_fallback_icon('All apps'),'hero':_fallback_icon('All apps'),'description':GENERIC_DESCRIPTIONS['All apps']})
    rows.append({'kind':'manage','name':'Manage','package':'','thumb':_fallback_icon('Manage'),'hero':_fallback_icon('Manage'),'description':GENERIC_DESCRIPTIONS['Manage']})
    return rows[:12]


class AppsWindow(xbmcgui.WindowXMLDialog):
    COLS=6
    def __init__(self,*args,**kwargs):
        self.rows=[];self.dynamic=[];self.buttons={};self.tile_buttons=[];self.ready=False

    def onInit(self):
        if self.ready:return
        self.ready=True
        self.build()

    def clear_dynamic(self):
        for control in self.dynamic:
            try:self.removeControl(control)
            except Exception:pass
        self.dynamic=[];self.buttons={};self.tile_buttons=[]

    def build(self):
        self.clear_dynamic();self.rows=launcher_items()
        # Hero mosaic mirrors the visual balance of the TV launcher reference.
        for i in range(8):
            try:self.getControl(20+i).setImage((self.rows[i%len(self.rows)].get('hero') or self.rows[i%len(self.rows)].get('thumb')) if self.rows else '')
            except Exception:pass
        tile=os.path.join(MEDIA,'apps-tile.png');focus=os.path.join(MEDIA,'apps-focus.png')
        x0,y0,w,h,gapx,gapy=40,350,186,136,16,24
        for i,row in enumerate(self.rows):
            col=i%self.COLS;line=i//self.COLS;x=x0+col*(w+gapx);y=y0+line*(h+gapy)
            button=xbmcgui.ControlButton(x,y,w,h,'',focusTexture=focus,noFocusTexture=tile,
                textColor='00FFFFFF',focusedColor='00FFFFFF',font='font13',alignment=2)
            self.addControl(button);self.dynamic.append(button);self.buttons[button.getId()]=i;self.tile_buttons.append(button)
            thumb=row.get('thumb') or ''
            if thumb:
                image=xbmcgui.ControlImage(x+18,y+13,w-36,82,thumb,aspectRatio=1)
                self.addControl(image);self.dynamic.append(image)
            label=xbmcgui.ControlLabel(x+8,y+101,w-16,27,row['name'],font='font12',textColor='FFFFFFFF',alignment=2)
            self.addControl(label);self.dynamic.append(label)
        self.lock_navigation()
        if self.rows and self.tile_buttons:
            try:self.setFocus(self.tile_buttons[0])
            except Exception:pass
            self.hero(0)
        try:self.getControl(12).setLabel('{} apps and shortcuts'.format(max(0,len(self.rows)-2)))
        except Exception:pass

    def hero(self,index):
        if not (0<=index<len(self.rows)):return
        row=self.rows[index]
        try:self.getControl(10).setLabel(row['name'])
        except Exception:pass
        try:self.getControl(11).setText(row.get('description') or '')
        except Exception:pass
        try:self.getControl(14).setImage(row.get('hero') or row.get('thumb') or _fallback_icon(row.get('name')))
        except Exception:pass

    def lock_navigation(self):
        # Dynamic Kodi controls do not get a reliable focus graph on every Android skin.
        # Keep native navigation on the current tile and move focus ourselves from onAction.
        for button in self.tile_buttons:
            try:
                button.controlLeft(button);button.controlRight(button)
                button.controlUp(button);button.controlDown(button)
            except Exception:pass

    def navigate(self,direction):
        if not self.tile_buttons:return
        focus=self.getFocusId()
        index=self.buttons.get(focus)
        if index is None:index=0
        row=index//self.COLS;col=index%self.COLS
        row_start=row*self.COLS;row_end=min(len(self.rows),(row+1)*self.COLS)
        if direction==1: # left, wrap inside current row
            index=row_end-1 if index==row_start else index-1
        elif direction==2: # right, wrap inside current row
            index=row_start if index==row_end-1 else index+1
        elif direction in (3,4):
            rows=max(1,(len(self.rows)+self.COLS-1)//self.COLS)
            target_row=(row+(-1 if direction==3 else 1))%rows
            start=target_row*self.COLS;end=min(len(self.rows),(target_row+1)*self.COLS)
            if start>=end:return
            index=min(start+col,end-1)
        try:self.setFocus(self.tile_buttons[index])
        except Exception:pass
        self.hero(index)

    def onFocus(self,controlId):
        if controlId in self.buttons:self.hero(self.buttons[controlId])

    def onClick(self,controlId):
        if controlId not in self.buttons:return
        row=self.rows[self.buttons[controlId]]
        if row['kind']=='app':
            self.close();launch({'file':row['package']});return
        if row['kind']=='all':
            _all_apps();self.build();return
        if row['kind']=='manage':
            _manage();self.build()

    def onAction(self,action):
        aid=action.getId()
        if aid in (9,10,92):self.close();return
        if aid in (1,2,3,4):
            self.navigate(aid);return
        if aid in (5,104):self.navigate(3);return
        if aid in (6,105):self.navigate(4);return
        if aid in (117,101):
            _manage();self.build();return


def menu():
    if not xbmc.getCondVisibility('System.Platform.Android'):
        ui.message('Apps','Streaming apps can be opened when this guide runs on Android.');return
    window=AppsWindow('apps.xml',ROOT,'Default','720p')
    window.doModal();del window


def _all_apps():
    apps=installed()
    if not apps:
        ui.message('All apps','Kodi could not detect Android applications on this device.')
        return
    labels=[a.get('label') or package(a.get('file','')) for a in apps]
    choice=ui.select('All installed apps',labels,'Open an Android app without leaving the OTB interface')
    if choice>=0:launch(apps[choice])


def _import_local_logo(source,name):
    source=str(source or '').strip()
    if not source:return ''
    try:
        if not xbmcvfs.exists(source):return ''
        xbmcvfs.mkdirs(LOGO_DIR)
    except Exception:return ''
    ext=os.path.splitext(source)[1].lower()
    if ext not in ('.png','.jpg','.jpeg','.webp','.gif','.bmp'):ext='.png'
    stem=re.sub(r'[^A-Za-z0-9._-]+','-',str(name or 'logo')).strip('-._') or 'logo'
    target=os.path.join(LOGO_DIR,stem+ext)
    counter=2
    while xbmcvfs.exists(target):
        target=os.path.join(LOGO_DIR,'{}-{}{}'.format(stem,counter,ext));counter+=1
    try:
        return target if xbmcvfs.copy(source,target) else source
    except Exception:return source


def _choose_logo(name,built_in=False):
    labels=['Use supplied logo','Use Android app icon','Choose a local logo'] if built_in else ['Use Android app icon','Use generic OTB logo','Choose a local logo']
    choice=ui.select('Logo for '+name,labels,'Local logos are copied into the OTB profile so the launcher can keep using them.')
    if choice<0:return None
    if built_in:
        if choice==0:return ''
        if choice==1:return ANDROID_ICON
    else:
        if choice==0:return ANDROID_ICON
        if choice==1:return GENERIC_ICON
    chosen=ui.browse_image('Choose local logo')
    if not chosen:return None
    imported=_import_local_logo(chosen,name)
    if not imported:
        ui.message('Local logo','The selected image could not be opened.');return None
    return imported


def _set_any_logo(apps,custom):
    labels=['{}  (built-in)'.format(s[0]) for s in SERVICES]+['{}  (custom)'.format(r.get('name','Shortcut')) for r in custom]
    choice=ui.select('Choose shortcut logo',labels,'Use the supplied service artwork, Android icon, or any local PNG/JPG/WebP image.')
    if choice<0:return
    if choice<len(SERVICES):
        name=SERVICES[choice][0];value=_choose_logo(name,True)
        if value is None:return
        data=_load_logo_overrides()
        if value:data[str(choice)]=value
        else:data.pop(str(choice),None)
        _save_logo_overrides(data)
        return
    idx=choice-len(SERVICES)
    if not (0<=idx<len(custom)):return
    name=custom[idx].get('name','Shortcut');value=_choose_logo(name,False)
    if value is None:return
    if value in ('',ANDROID_ICON):custom[idx].pop('logo',None)
    else:custom[idx]['logo']=value
    save_shortcuts(custom)


def _manage():
    apps=installed();custom=custom_shortcuts()
    choices=['Add your own shortcut','Manage custom shortcuts','Set or change a shortcut logo','All installed apps','Assign an app to a built-in shortcut']
    selected=ui.select('Manage apps & shortcuts',choices)
    if selected<0:return
    if selected==0:
        labels=[a.get('label') or package(a['file']) for a in apps]+['Enter Android package name']
        choice=ui.select('Choose an app',labels)
        if choice<0:return
        if choice<len(apps):
            ident=package(apps[choice]['file']);default_name=apps[choice].get('label',ident)
        else:
            value=ui.input_text('Android package name')
            ident=package((value or '').strip());default_name=ident
        if not ident:
            ui.message('Shortcut','A valid Android package name is required.');return
        value=ui.input_text('Shortcut name',default_name)
        name=(value or '').strip()
        if not name:return
        row={'name':name,'package':ident}
        if ui.confirm('Shortcut logo','Would you like to choose a local logo for this shortcut now?','Choose logo','Use app icon'):
            logo=_choose_logo(name,False)
            if logo not in (None,'',ANDROID_ICON):row['logo']=logo
        custom.append(row);save_shortcuts(custom)
        return
    if selected==1:
        if not custom:ui.message('Custom shortcuts','No custom shortcuts have been added yet.');return
        choice=ui.select('Custom shortcuts',[r['name'] for r in custom])
        if choice<0:return
        action=ui.select(custom[choice]['name'],['Rename','Change logo','Remove shortcut'])
        if action==0:
            value=ui.input_text('Shortcut name',custom[choice]['name'])
            name=(value or '').strip()
            if name:custom[choice]['name']=name;save_shortcuts(custom)
        elif action==1:
            value=_choose_logo(custom[choice]['name'],False)
            if value is None:return
            if value in ('',ANDROID_ICON):custom[choice].pop('logo',None)
            else:custom[choice]['logo']=value
            save_shortcuts(custom)
        elif action==2:custom.pop(choice);save_shortcuts(custom)
        return
    if selected==2:
        _set_any_logo(apps,custom);return
    if selected==3:
        _all_apps();return
    if selected==4:
        slot=ui.select('Choose shortcut',[s[0] for s in SERVICES])
        if slot<0:return
        if not apps:
            ui.message('Apps','Kodi could not detect Android applications on this device.');return
        choice=ui.select('Installed apps',[a.get('label') or package(a['file']) for a in apps])
        if choice>=0:ADDON.setSetting('android.shortcut.'+str(slot),package(apps[choice]['file']))


def export_shortcut_preferences():
    """Portable Android shortcut/package/logo mappings; no account data."""
    return {
        'custom': custom_shortcuts(),
        'built_in': [ADDON.getSetting('android.shortcut.'+str(i)).strip() for i in range(len(SERVICES))],
        'built_in_logos': _load_logo_overrides(),
    }


def restore_shortcut_preferences(data):
    if data is None:return
    if not isinstance(data,dict):raise ValueError('Invalid Android shortcut backup')
    custom=data.get('custom',[]);built=data.get('built_in',[]);logos=data.get('built_in_logos',{})
    if not isinstance(custom,list) or len(custom)>100 or not isinstance(built,list) or len(built)>len(SERVICES) or not isinstance(logos,dict):raise ValueError('Invalid Android shortcut backup')
    clean=[]
    for row in custom:
        if not isinstance(row,dict):raise ValueError('Invalid Android shortcut')
        ident=package(str(row.get('package','')));name=str(row.get('name','')).strip();logo=str(row.get('logo','') or '').strip()
        if not ident or not name:raise ValueError('Invalid Android shortcut')
        item={'name':name,'package':ident}
        if logo:item['logo']=logo
        clean.append(item)
    clean_built=[]
    for value in built:
        value=str(value or '').strip()
        if value and not package(value):raise ValueError('Invalid Android shortcut package')
        clean_built.append(value)
    clean_logos={}
    for key,value in logos.items():
        key=str(key);value=str(value or '').strip()
        if key.isdigit() and 0<=int(key)<len(SERVICES) and value:clean_logos[key]=value
    save_shortcuts(clean);_save_logo_overrides(clean_logos)
    for i in range(len(SERVICES)):
        ADDON.setSetting('android.shortcut.'+str(i),clean_built[i] if i<len(clean_built) else '')
