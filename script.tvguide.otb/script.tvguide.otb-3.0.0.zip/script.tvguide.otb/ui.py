"""Custom OTB full-screen UI primitives.

This module deliberately avoids Kodi's stock Dialog/Keyboard/Settings windows so the
add-on keeps one coherent TV interface from guide through settings and utilities.
"""
import os
import xbmc
import xbmcgui
import xbmcvfs
from backend import ADDON, PROFILE

ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA = os.path.join(ROOT, 'resources', 'media')
BACK = (9, 10, 92)


class ListDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = ''
        self.subtitle = ''
        self.items = []
        self.multi = False
        self.preselect = set()
        self.selected = -1
        self.result = None

    def onInit(self):
        self.getControl(10).setLabel(self.title)
        self.getControl(11).setLabel(self.subtitle)
        self.getControl(12).setLabel('OK  Select      BACK  Return' if not self.multi else 'OK  Toggle      Save  Apply      BACK  Cancel')
        self.getControl(6001).setVisible(self.multi)
        self.getControl(6002).setVisible(self.multi)
        if not self.multi:
            try:
                self.getControl(6000).controlLeft(self.getControl(6000));self.getControl(6000).controlRight(self.getControl(6000))
            except Exception:pass
        self.populate()
        self.setFocusId(6000)

    def _label(self, i):
        text = str(self.items[i])
        if self.multi:
            return ('✓  ' if i in self.preselect else '    ') + text
        return text

    def populate(self):
        control = self.getControl(6000)
        control.reset()
        control.addItems([xbmcgui.ListItem(self._label(i)) for i in range(len(self.items))])
        if self.items:
            control.selectItem(max(0, min(self.selected if self.selected >= 0 else 0, len(self.items)-1)))

    def onClick(self, ident):
        if ident == 6000:
            if not self.items:
                return
            pos = self.getControl(6000).getSelectedPosition()
            if self.multi:
                if pos in self.preselect:
                    self.preselect.remove(pos)
                else:
                    self.preselect.add(pos)
                self.getControl(6000).getListItem(pos).setLabel(self._label(pos))
            else:
                self.result = pos
                self.close()
        elif ident == 6001 and self.multi:
            self.result = sorted(self.preselect)
            self.close()
        elif ident == 6002 and self.multi:
            self.result = None
            self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK:
            self.result = None if self.multi else -1
            self.close()


class MessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = ''
        self.text = ''
        self.yesno = False
        self.yes = 'OK'
        self.no = 'Cancel'
        self.result = False

    def onInit(self):
        self.getControl(10).setLabel(self.title)
        self.getControl(20).setText(self.text)
        self.getControl(6001).setLabel(self.yes)
        self.getControl(6002).setLabel(self.no)
        self.getControl(6002).setVisible(self.yesno)
        if not self.yesno:
            try:self.getControl(6001).controlRight(self.getControl(6001))
            except Exception:pass
        self.setFocusId(6001)

    def onClick(self, ident):
        if ident == 6001:
            self.result = True
            self.close()
        elif ident == 6002:
            self.result = False
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.result = False
            self.close()


class TextDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = ''
        self.subtitle = ''
        self.text = ''
        self.scrollpos = 0

    def onInit(self):
        self.getControl(10).setLabel(self.title)
        self.getControl(11).setLabel(self.subtitle)
        self.getControl(20).setText(self.text)
        self.setFocusId(6001)

    def onClick(self, ident):
        if ident == 6001:
            self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK:
            self.close()
        elif aid in (3, 4, 5, 6):
            # Route remote scroll commands to the textbox even though Close keeps focus.
            self.scrollpos=max(0,self.scrollpos+{3:-1,4:1,5:-8,6:8}[aid])
            try:self.getControl(20).scroll(self.scrollpos)
            except Exception:pass


class KeyboardDialog(xbmcgui.WindowXMLDialog):
    ROWS = [
        list('1234567890'),
        list('qwertyuiop'),
        list('asdfghjkl') + ['@'],
        list('zxcvbnm') + ['.', '-', '_'],
        ['Aa', '/', ':', '?', '=', '&', '%', '+'],
        ['SPACE', 'DEL', 'CLEAR', 'DONE'],
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = ''
        self.value = ''
        self.hidden = False
        self.accepted = False
        self.upper = False
        self.controls = []
        self.keymap = {}
        self.grid = []
        self.centres = {}

    def display(self):
        shown = '•' * len(self.value) if self.hidden else self.value
        self.getControl(20).setLabel(shown or ' ')

    def onInit(self):
        self.getControl(10).setLabel(self.title)
        self.display()
        x0, y0 = 72, 238
        gapx, gapy = 10, 9
        keyw, keyh = 104, 56
        for r, row in enumerate(self.ROWS):
            width = len(row) * keyw + max(0, len(row)-1) * gapx
            start = max(52, (1280 - width)//2)
            current=[]
            for c, key in enumerate(row):
                w = 206 if key == 'SPACE' else (142 if key in ('CLEAR','DONE') else keyw)
                # For mixed-width last row, calculate sequentially.
                if r == len(self.ROWS)-1:
                    x = start + sum((206 if k=='SPACE' else (142 if k in ('CLEAR','DONE') else keyw)) + gapx for k in row[:c])
                else:
                    x = start + c*(keyw+gapx)
                y = y0 + r*(keyh+gapy)
                b = xbmcgui.ControlButton(x,y,w,keyh,key,
                    focusTexture=os.path.join(MEDIA,'key-focus.png'),
                    noFocusTexture=os.path.join(MEDIA,'key.png'),
                    textColor='FFF3F6FF',focusedColor='FFFFFFFF',font='font13',alignment=2)
                self.addControl(b)
                self.controls.append(b)
                self.keymap[b.getId()] = key
                self.centres[b.getId()] = x + w/2.0
                current.append(b)
            self.grid.append(current)
        # Explicit remote navigation. For vertical moves choose nearest centre in next row.
        for r,row in enumerate(self.grid):
            for c,b in enumerate(row):
                b.controlLeft(row[c-1] if c else row[-1])
                b.controlRight(row[(c+1)%len(row)])
                if r>0:
                    b.controlUp(min(self.grid[r-1], key=lambda q: abs(self.centres.get(q.getId(),0)-self.centres.get(b.getId(),0))))
                else:b.controlUp(b)
                if r<len(self.grid)-1:
                    b.controlDown(min(self.grid[r+1], key=lambda q: abs(self.centres.get(q.getId(),0)-self.centres.get(b.getId(),0))))
                else:b.controlDown(b)
        self.setFocus(self.grid[0][0])

    def relabel_letters(self):
        for b in self.controls:
            key=self.keymap[b.getId()]
            if len(key)==1 and key.isalpha():
                b.setLabel(key.upper() if self.upper else key.lower())

    def onClick(self, ident):
        key=self.keymap.get(ident)
        if key is None:return
        if key=='DONE':
            self.accepted=True;self.close();return
        if key=='DEL': self.value=self.value[:-1]
        elif key=='CLEAR': self.value=''
        elif key=='SPACE': self.value+=' '
        elif key=='Aa': self.upper=not self.upper;self.relabel_letters()
        else:
            self.value += key.upper() if self.upper and key.isalpha() else key
        self.display()

    def onAction(self, action):
        if action.getId() in BACK:
            self.accepted=False;self.close()



class ProgressDialog(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.title='OTB TV Guide';self.message='Preparing';self.cancelled=False;self.ready=False
    def onInit(self):
        self.ready=True
        self.getControl(10).setLabel(self.title)
        self.getControl(20).setLabel(self.message)
    def update(self,message):
        self.message=str(message)
        if self.ready:
            try:self.getControl(20).setLabel(self.message)
            except Exception:pass
    def onAction(self,action):
        if action.getId() in BACK:
            self.cancelled=True;self.close()


def select(title, items, subtitle=''):
    d=ListDialog('dialog-list.xml',ROOT,'Default','720p')
    d.title=title;d.items=list(items);d.subtitle=subtitle;d.multi=False
    d.doModal();result=d.result;del d
    return -1 if result is None else result


def multiselect(title, items, preselect=None, subtitle=''):
    d=ListDialog('dialog-list.xml',ROOT,'Default','720p')
    d.title=title;d.items=list(items);d.subtitle=subtitle;d.multi=True;d.preselect=set(preselect or [])
    d.doModal();result=d.result;del d
    return result


def message(title, text):
    d=MessageDialog('dialog-message.xml',ROOT,'Default','720p')
    d.title=title;d.text=str(text);d.yesno=False;d.yes='OK'
    d.doModal();del d
    return True


def confirm(title, text, yes='Yes', no='No'):
    d=MessageDialog('dialog-message.xml',ROOT,'Default','720p')
    d.title=title;d.text=str(text);d.yesno=True;d.yes=yes;d.no=no
    d.doModal();result=d.result;del d
    return bool(result)


def textviewer(title, text, subtitle=''):
    d=TextDialog('dialog-text.xml',ROOT,'Default','720p')
    d.title=title;d.text=str(text);d.subtitle=subtitle
    d.doModal();del d


def input_text(title, default='', hidden=False):
    d=KeyboardDialog('dialog-keyboard.xml',ROOT,'Default','720p')
    d.title=title;d.value=str(default or '');d.hidden=hidden
    d.doModal();result=d.value if d.accepted else None;del d
    return result


def progress(title='OTB TV Guide', message_text='Preparing'):
    d=ProgressDialog('dialog-progress.xml',ROOT,'Default','720p')
    d.title=title;d.message=message_text;d.show()
    return d


def settings(addon=ADDON):
    """OTB-skinned replacement for Kodi's add-on settings screen."""
    specs=[
        ('otb.m3u','Playlist / M3U source','text',False),
        ('otb.xmltv','XMLTV / EPG source','text',False),
        ('otb.matched','Only show channels with guide data','bool',False),
        ('otb.hours','Guide refresh interval (hours)','number',False),
        ('art.provider','Use OTB programme artwork','bool',False),
        ('art.tvmaze','Use TVmaze artwork fallback','bool',False),
        ('art.tmdb_key','TMDB API key','text',True),
    ]
    while True:
        labels=[]
        for key,label,kind,hidden in specs:
            value=addon.getSetting(key)
            if kind=='bool': shown='On' if value=='true' else 'Off'
            elif hidden: shown='Set' if value else 'Not set'
            else: shown=value or 'Automatic / OTB default'
            labels.append('{}    {}'.format(label,shown))
        labels += ['Back']
        choice=select('Guide settings',labels,'OTB interface settings. No Kodi settings screen is used.')
        if choice<0 or choice>=len(specs):return
        key,label,kind,hidden=specs[choice]
        if kind=='bool':
            addon.setSetting(key,'false' if addon.getSetting(key)=='true' else 'true')
        else:
            current=addon.getSetting(key)
            value=input_text(label,current,hidden)
            if value is not None:
                if kind=='number':
                    value=''.join(ch for ch in value if ch.isdigit()) or current or '24'
                addon.setSetting(key,value)


def browse_image(title='Choose local image'):
    """OTB-skinned local image browser. No Kodi stock file browser is opened."""
    roots=[]
    candidates=[
        ('Downloads','/storage/emulated/0/Download'),
        ('Pictures','/storage/emulated/0/Pictures'),
        ('Internal storage','/storage/emulated/0'),
        ('Kodi home',xbmcvfs.translatePath('special://home/')),
        ('Kodi profile',xbmcvfs.translatePath('special://profile/')),
    ]
    seen=set()
    for label,path in candidates:
        path=str(path or '').rstrip('/\\')
        if not path or path in seen:continue
        try:exists=xbmcvfs.exists(path)
        except Exception:exists=False
        if exists:roots.append((label,path));seen.add(path)
    root_labels=[label for label,_ in roots]+['Enter a path manually']
    choice=select(title,root_labels,'Browse PNG, JPG, JPEG or WebP images using the OTB interface.')
    if choice<0:return None
    if choice>=len(roots):
        value=input_text('Image or folder path','/storage/emulated/0/Download')
        if not value:return None
        path=str(value).strip()
        ext=os.path.splitext(path)[1].lower()
        if ext in ('.png','.jpg','.jpeg','.webp','.gif','.bmp') and xbmcvfs.exists(path):return path
        current=path
    else:current=roots[choice][1]
    image_ext=('.png','.jpg','.jpeg','.webp','.gif','.bmp')
    while current:
        try:dirs,files=xbmcvfs.listdir(current)
        except Exception:
            message('Local logo','This folder could not be opened.');return None
        dirs=sorted([d for d in dirs if d not in ('.','..')],key=str.casefold)
        files=sorted([f for f in files if os.path.splitext(f)[1].lower() in image_ext],key=str.casefold)
        labels=['..  Parent folder']+['[Folder]  '+d for d in dirs]+files
        selected=select(title,labels,current)
        if selected<0:return None
        if selected==0:
            parent=os.path.dirname(current.rstrip('/\\'))
            if not parent or parent==current:return None
            current=parent;continue
        selected-=1
        if selected<len(dirs):
            current=os.path.join(current,dirs[selected]);continue
        file_index=selected-len(dirs)
        if 0<=file_index<len(files):return os.path.join(current,files[file_index])
