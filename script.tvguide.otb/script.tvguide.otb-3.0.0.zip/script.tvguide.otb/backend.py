"""Local OTB sources, transactional import, background refresh, and migration from guide 1.x."""
import os
import sqlite3
import tempfile
import shutil
import time
import traceback
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from store import connect, import_guide

ADDON = xbmcaddon.Addon('script.tvguide.otb')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)
DB_PATH = os.path.join(PROFILE, 'guide-v2.db')


def record_error(context):
    # Keep stack frame locations, not provider URLs or exception messages.
    import sys
    typ, value, tb = sys.exc_info()
    frames = traceback.extract_tb(tb)
    text = context + ': ' + (typ.__name__ if typ else 'unknown') + '\n'
    text += '\n'.join('%s:%s in %s' % (os.path.basename(f.filename), f.lineno, f.name) for f in frames)
    xbmc.log('[OTB Guide] ' + text, xbmc.LOGERROR)
    with open(os.path.join(PROFILE, 'diagnostics.txt'), 'a', encoding='utf-8') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + text + '\n')


def database():
    db = connect(DB_PATH)
    if not db.execute('SELECT 1 FROM channels LIMIT 1').fetchone():
        old = os.path.join(PROFILE, 'source-omega.db')
        if os.path.exists(old):
            source = None
            try:
                source = sqlite3.connect('file:' + old.replace('\\', '/') + '?mode=ro', uri=True)
                source.row_factory = sqlite3.Row
                with db:
                    for c in source.execute("SELECT * FROM channels WHERE source='otb' AND stream_url IS NOT NULL AND stream_url!='catchup'"):
                        db.execute('INSERT OR REPLACE INTO channels VALUES (?,?,?,?,?,?,?)', (c['id'], c['title'], c['id'], c['title'], c['lineup'] or 'All', c['logo'] or '', c['stream_url']))
                    for p in source.execute("SELECT * FROM programs WHERE source='otb'"):
                        db.execute('INSERT INTO programmes VALUES (?,?,?,?,?)', (p['channel'], int(float(p['start_date'])), int(float(p['end_date'])), p['title'] or 'No listing', p['description'] or ''))
                    db.execute("INSERT OR REPLACE INTO meta VALUES ('updated',?)", (str(int(time.time())),))
            except Exception:
                record_error('Migration')
            finally:
                if source:
                    source.close()
    return db


def sources():
    m, e = ADDON.getSetting('otb.m3u').strip(), ADDON.getSetting('otb.xmltv').strip()
    if not m or not e:
        try:
            otb = xbmcaddon.Addon('plugin.video.kodiotb')
        except RuntimeError:
            raise ValueError('Configure OTB Kodi, or enter both sources in Settings.')
        server = otb.getSetting('DNS').strip().rstrip('/')
        user, password = otb.getSetting('Username').strip(), otb.getSetting('Password').strip()
        query = urlencode({'username': user, 'password': password})
        ready = bool(server and user and password)
        output = 'm3u8' if otb.getSetting('pvr_output') == '1' else 'ts'
        m = m or otb.getSetting('pvr_playlist_url').strip() or (server + '/get.php?' + query + '&type=m3u_plus&output=' + output if ready else '')
        e = e or otb.getSetting('pvr_epg_url').strip() or (server + '/xmltv.php?' + query if ready else '')
    if not m or not e:
        raise ValueError('OTB account details or playlist/XMLTV sources are missing.')
    return m, e


class Cancelled(Exception):
    pass


def _download(url, target, label, update, cancelled=lambda: False):
    remote = urlsplit(url).scheme.lower() in ('http', 'https')
    reader = urlopen(Request(url, headers={'User-Agent': 'OTB-Guide/2.8', 'Accept-Encoding': 'identity'}), timeout=25) if remote else xbmcvfs.File(url)
    size = 0
    try:
        with open(target, 'wb') as f:
            while True:
                if cancelled():
                    raise Cancelled()
                block = reader.read(262144) if remote else reader.readBytes(262144)
                if not block:
                    break
                size += len(block)
                if size > 512 * 1048576:
                    raise ValueError('Source exceeds the 512 MB limit.')
                f.write(block)
                update('Downloading {}: {:.1f} MB'.format(label, size / 1048576))
    finally:
        reader.close()


def refresh(db):
    """Interactive first-import/maintenance refresh using the OTB full-screen UI."""
    import ui
    dialog = ui.progress('OTB TV Guide', 'Preparing sources')
    monitor = xbmc.Monitor()
    scratch = tempfile.mkdtemp(prefix='import-', dir=PROFILE)

    def cancelled():
        return dialog.cancelled or monitor.abortRequested()

    def update(message):
        if cancelled():
            raise Cancelled()
        dialog.update(message)

    try:
        m, e = sources()
        mp, ep = os.path.join(scratch, 'm3u'), os.path.join(scratch, 'xmltv')
        _download(m, mp, 'channels', update, cancelled)
        _download(e, ep, 'XMLTV', update, cancelled)
        result = import_guide(db, mp, ep, m, True, 7, update)
        dialog.close()
        ui.message('Import complete', '{:,} channels; {:,} programmes; {:,} channels with listings.'.format(*result[:3]))
        return True
    except Cancelled:
        return False
    except Exception as exc:
        record_error('Import')
        dialog.close()
        ui.message('Import failed', str(exc) if type(exc) is ValueError else 'Could not download or parse the sources. Previous guide retained.')
        return False
    finally:
        try:dialog.close()
        except Exception:pass
        shutil.rmtree(scratch, ignore_errors=True)


def refresh_background(status=lambda state, detail='': None):
    """Build a new guide off-line, then replace live EPG tables in a short transaction.

    The caller owns threading. While download/parsing occurs the existing database is
    untouched, so guide browsing and playback continue against the old listings.
    """
    scratch = tempfile.mkdtemp(prefix='background-import-', dir=PROFILE)
    stage_path = os.path.join(scratch, 'stage.db')
    stage = None
    live = None
    try:
        status('updating', 'Preparing guide update')
        m, e = sources()
        mp, ep = os.path.join(scratch, 'm3u'), os.path.join(scratch, 'xmltv')
        _download(m, mp, 'channels', lambda message: status('updating', message))
        _download(e, ep, 'XMLTV', lambda message: status('updating', message))
        stage = connect(stage_path)
        result = import_guide(stage, mp, ep, m, True, 7, lambda message: status('updating', message))
        stage.close(); stage = None

        status('updating', 'Applying guide update')
        live = connect(DB_PATH)
        # ATTACH cannot use a parameter in every SQLite build Kodi ships, so escape
        # single quotes in our own locally-created staging path before interpolation.
        quoted = stage_path.replace("'", "''")
        live.execute("ATTACH DATABASE '{}' AS stage".format(quoted))
        try:
            with live:
                live.execute('DELETE FROM channels')
                live.execute('INSERT INTO channels SELECT * FROM stage.channels')
                live.execute('DELETE FROM programmes')
                live.execute('INSERT INTO programmes SELECT * FROM stage.programmes')
                live.execute('DELETE FROM programme_metadata')
                live.execute('INSERT INTO programme_metadata SELECT * FROM stage.programme_metadata')
                updated = live.execute("SELECT value FROM stage.meta WHERE key='updated'").fetchone()
                if updated:
                    live.execute("INSERT OR REPLACE INTO meta VALUES ('updated',?)", (updated[0],))
        finally:
            live.execute('DETACH DATABASE stage')
        status('done', '')
        return result
    except Exception:
        record_error('Background import')
        status('failed', '')
        return None
    finally:
        if stage is not None:
            stage.close()
        if live is not None:
            live.close()
        shutil.rmtree(scratch, ignore_errors=True)
