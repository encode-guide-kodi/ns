"""Guide collections, portable preferences, recent channels and programme reminders."""
import time
import uuid


def initialize(db):
    db.executescript('''
    CREATE TABLE IF NOT EXISTS hidden(url TEXT PRIMARY KEY,name TEXT);
    CREATE TABLE IF NOT EXISTS channel_numbers(url TEXT PRIMARY KEY,number INTEGER UNIQUE);
    CREATE TABLE IF NOT EXISTS hidden_categories(mode TEXT,category TEXT,PRIMARY KEY(mode,category));
    CREATE TABLE IF NOT EXISTS display_order(kind TEXT,item TEXT,position INTEGER,PRIMARY KEY(kind,item));
    CREATE TABLE IF NOT EXISTS collections(id TEXT PRIMARY KEY,name TEXT);
    CREATE TABLE IF NOT EXISTS collection_members(collection TEXT,url TEXT,PRIMARY KEY(collection,url));
    CREATE TABLE IF NOT EXISTS reminders(id TEXT PRIMARY KEY,epg TEXT,title TEXT,start INTEGER,series INTEGER);
    CREATE TABLE IF NOT EXISTS reminder_sent(reminder TEXT,start INTEGER,PRIMARY KEY(reminder,start));
    CREATE TABLE IF NOT EXISTS recent_channels(url TEXT PRIMARY KEY,watched INTEGER NOT NULL);
    ''')


def search(db,term,offset=0,limit=100):
    escaped=term.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
    return db.execute('''SELECT p.*,c.id AS channel_id,c.name AS channel_name FROM programmes p
      JOIN channels c ON c.epg=p.epg WHERE p.title LIKE ? ESCAPE '\\'
      AND NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=c.url)
      AND NOT EXISTS(SELECT 1 FROM hidden_categories h WHERE h.mode='live' AND h.category=c.grp)
      ORDER BY p.start,c.name LIMIT ? OFFSET ?''',('%'+escaped+'%',limit,offset)).fetchall()


def add_reminder(db,programme,series=False):
    start=0 if series else programme['start']
    old=db.execute('SELECT id FROM reminders WHERE epg=? AND title=? AND start=? AND series=?',(programme['epg'],programme['title'],start,int(series))).fetchone()
    if old:return old[0]
    ident=uuid.uuid4().hex
    with db:db.execute('INSERT INTO reminders VALUES (?,?,?,?,?)',(ident,programme['epg'],programme['title'],start,int(series)))
    return ident


def due_reminders(db,now=None):
    now=int(time.time()) if now is None else int(now)
    rows=db.execute('''SELECT DISTINCT r.id,p.start,p.stop,p.title,c.name FROM reminders r
      JOIN programmes p ON p.epg=r.epg AND p.title=r.title AND (r.series=1 OR r.start=p.start)
      JOIN channels c ON c.epg=p.epg
      WHERE p.start<=? AND p.start>=? AND p.stop>?
      AND NOT EXISTS(SELECT 1 FROM reminder_sent s WHERE s.reminder=r.id AND s.start=p.start)
      GROUP BY r.id,p.start''',(now+60,now-300,now)).fetchall()
    with db:
        db.executemany('INSERT OR IGNORE INTO reminder_sent VALUES (?,?)',[(r['id'],r['start']) for r in rows])
        db.execute('DELETE FROM reminder_sent WHERE start<?',(now-86400*30,))
    return rows


def remember_channel(db,channel,limit=8):
    """Store a small MRU list without duplicating the currently watched channel."""
    now=int(time.time()*1000)
    with db:
        db.execute('INSERT OR REPLACE INTO recent_channels(url,watched) VALUES (?,?)',(channel['url'],now))
        db.execute('''DELETE FROM recent_channels WHERE url IN (
          SELECT url FROM recent_channels ORDER BY watched DESC LIMIT -1 OFFSET ?)''',(max(1,int(limit)),))


def recent_channels(db,limit=8):
    return db.execute('''SELECT c.*,r.watched FROM recent_channels r JOIN channels c ON c.url=r.url
      WHERE NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=c.url)
      AND NOT EXISTS(SELECT 1 FROM hidden_categories h WHERE h.mode='live' AND h.category=c.grp)
      ORDER BY r.watched DESC LIMIT ?''',(max(1,int(limit)),)).fetchall()


def export_preferences(db):
    hidden={r[0] for r in db.execute('SELECT url FROM hidden')}
    favourites={r[0] for r in db.execute('SELECT id FROM favourites')}
    numbers=dict(db.execute('SELECT url,number FROM channel_numbers'))
    order=dict(db.execute("SELECT item,position FROM display_order WHERE kind='channels'"))
    channels=[]
    for c in db.execute('SELECT * FROM channels'):
        channels.append(dict(epg=c['epg'],name=c['name'],hidden=c['url'] in hidden,favourite=c['id'] in favourites,number=numbers.get(c['url']),position=order.get(c['url']),collections=[r[0] for r in db.execute('SELECT collection FROM collection_members WHERE url=?',(c['url'],))]))
    reminders=[dict(epg=r['epg'],title=r['title'],start=int(r['start']),series=int(r['series'])) for r in db.execute('SELECT epg,title,start,series FROM reminders ORDER BY title,start')]
    recent=[]
    for r in db.execute('''SELECT c.epg,c.name,x.watched FROM recent_channels x JOIN channels c ON c.url=x.url ORDER BY x.watched DESC LIMIT 20'''):
        recent.append(dict(epg=r['epg'],name=r['name'],watched=int(r['watched'])))
    return dict(
        format='otb-preferences',version=2,channels=channels,
        collections=[dict(r) for r in db.execute('SELECT * FROM collections')],
        category_order=[list(r) for r in db.execute("SELECT kind,item,position FROM display_order WHERE kind LIKE 'categories:%'")],
        hidden_categories=[list(r) for r in db.execute('SELECT * FROM hidden_categories')],
        reminders=reminders,recent_channels=recent)


def _validate_list(data,key,required=True):
    value=data.get(key)
    if value is None and not required:return []
    if not isinstance(value,list) or len(value)>100000:raise ValueError('Invalid backup data')
    return value


def restore_preferences(db,data):
    if not isinstance(data,dict) or data.get('format')!='otb-preferences' or data.get('version') not in (1,2):raise ValueError('Unsupported backup format')
    channels=_validate_list(data,'channels')
    collections=_validate_list(data,'collections')
    category_order=_validate_list(data,'category_order')
    hidden_categories=_validate_list(data,'hidden_categories')
    reminders=_validate_list(data,'reminders',False) if data.get('version')==2 else []
    recent=_validate_list(data,'recent_channels',False) if data.get('version')==2 else []
    matched=[]
    for entry in channels:
        if not isinstance(entry,dict):raise ValueError('Invalid channel preference')
        rows=db.execute('SELECT * FROM channels WHERE epg=? AND name=?',(entry.get('epg',''),entry.get('name',''))).fetchall()
        if len(rows)==1:matched.append((rows[0],entry))
    # Resolve recent channels before the transaction so malformed backup entries fail cleanly.
    recent_matches=[]
    for entry in recent:
        if not isinstance(entry,dict):raise ValueError('Invalid recent channel')
        rows=db.execute('SELECT * FROM channels WHERE epg=? AND name=?',(entry.get('epg',''),entry.get('name',''))).fetchall()
        if len(rows)==1:recent_matches.append((rows[0]['url'],int(entry.get('watched',0))))
    clean_reminders=[]
    for entry in reminders:
        if not isinstance(entry,dict):raise ValueError('Invalid reminder')
        epg=str(entry.get('epg',''));title=str(entry.get('title','')).strip();start=int(entry.get('start',0));series=int(bool(entry.get('series',0)))
        if not epg or not title or start<0:raise ValueError('Invalid reminder')
        clean_reminders.append((uuid.uuid4().hex,epg,title,0 if series else start,series))
    with db:
        db.execute('DELETE FROM collections');db.execute('DELETE FROM collection_members')
        db.executemany('INSERT INTO collections VALUES (?,?)',[(str(c['id']),str(c['name'])) for c in collections])
        db.execute('DELETE FROM hidden_categories')
        db.executemany('INSERT INTO hidden_categories VALUES (?,?)',[(str(r[0]),str(r[1])) for r in hidden_categories])
        db.execute("DELETE FROM display_order WHERE kind LIKE 'categories:%'")
        for kind,item,position in category_order:
            if kind not in ('categories:live','categories:movies','categories:series'):raise ValueError('Invalid category section')
            db.execute('INSERT INTO display_order VALUES (?,?,?)',(kind,str(item),int(position)))
        # Remove numbers for all matched channels first, allowing number swaps.
        db.execute('DELETE FROM channel_numbers WHERE url NOT IN (SELECT url FROM channels)')
        db.executemany('DELETE FROM channel_numbers WHERE url=?',[(c['url'],) for c,e in matched])
        for c,e in matched:
            url=c['url']
            db.execute('DELETE FROM hidden WHERE url=?',(url,));db.execute('DELETE FROM favourites WHERE id=?',(c['id'],))
            db.execute("DELETE FROM display_order WHERE kind='channels' AND item=?",(url,))
            if e.get('hidden'):db.execute('INSERT INTO hidden VALUES (?,?)',(url,c['name']))
            if e.get('favourite'):db.execute('INSERT INTO favourites VALUES (?)',(c['id'],))
            if e.get('position') is not None:db.execute("INSERT INTO display_order VALUES ('channels',?,?)",(url,int(e['position'])))
            if e.get('number') is not None:db.execute('INSERT OR IGNORE INTO channel_numbers VALUES (?,?)',(url,int(e['number'])))
            db.executemany('INSERT OR IGNORE INTO collection_members VALUES (?,?)',[(str(k),url) for k in e.get('collections',[])])
        if data.get('version')==2:
            db.execute('DELETE FROM reminders');db.execute('DELETE FROM reminder_sent')
            db.executemany('INSERT INTO reminders VALUES (?,?,?,?,?)',clean_reminders)
            db.execute('DELETE FROM recent_channels')
            db.executemany('INSERT OR REPLACE INTO recent_channels VALUES (?,?)',recent_matches)
    return len(matched),len(channels)-len(matched)
