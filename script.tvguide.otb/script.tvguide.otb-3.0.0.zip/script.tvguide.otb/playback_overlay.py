#
#       Copyright (C) 2015-
#       Sean Poyser (seanpoyser@gmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

# Python 3 / Kodi 21 adaptation of On-Tapp change.py's guarded OSD launcher.
# Uses OTB's programme database and overlay; no legacy provider modules.
import os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

RUNNING='OTB.PlaybackOverlayRunning'

def main(key='UP'):
    if key.upper()!='UP' or not xbmc.Player().isPlayingVideo():return
    home=xbmcgui.Window(10000)
    if home.getProperty(RUNNING)=='true':return
    home.setProperty(RUNNING,'true')
    db=None
    try:
        addon=xbmcaddon.Addon('script.tvguide.otb')
        root=xbmcvfs.translatePath(addon.getAddonInfo('path'))
        # RunScript may invoke this file without the guide's module search path.
        if root not in sys.path:sys.path.insert(0,root)
        from backend import PROFILE
        from store import connect
        from guide_data import initialize
        from mini_guide import show
        db=connect(os.path.join(PROFILE,'guide-v2.db'))
        initialize(db)
        show(root,db)
    except Exception:
        xbmc.log('OTB: Playback overlay could not open',xbmc.LOGERROR)
        try:
            import ui
            ui.message('OTB mini-guide','Could not open the playback overlay.')
        except Exception:pass
    finally:
        if db is not None:db.close()
        home.clearProperty(RUNNING)

if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else 'UP')
