"""Kodi UI for programme search, collections and preferences transfer."""
import json
import time
import uuid
import xbmcgui
import xbmcvfs
import guide_data

def programme_search(guide):
    dialog=xbmcgui.Dialog()
    term=dialog.input('Search programme titles')
    if not term.strip():return
    offset=0
    while True:
        rows=guide_data.search(guide.db,term,offset,101)
        visible=rows[:100];now=time.time()
        labels=[]
        for r in visible:
            state='Past' if r['stop']<=now else 'Live' if r['start']<=now else 'Upcoming'
            labels.append('%s | %s | %s | %s'%(state,time.strftime('%a %d %b %H:%M',time.localtime(r['start'])),r['channel_name'],r['title']))
        if not rows and offset==0:dialog.ok('Programme search','No matching programmes in the imported guide.');return
        navigation=[]
        if offset:navigation.append(('Previous results',-100))
        if len(rows)>100:navigation.append(('Next results',100))
        selected=dialog.select('Programme results',labels+[n[0] for n in navigation])
        if selected<0:return
        if selected>=len(visible):offset+=navigation[selected-len(visible)][1];continue
        p=visible[selected];c=guide.db.execute('SELECT * FROM channels WHERE id=?',(p['channel_id'],)).fetchone()
        guide.selected=(c,p)
        guide.details()
        if not guide.active:return

def reminders(guide):
    rows=guide.db.execute('SELECT * FROM reminders ORDER BY title,start').fetchall()
    if not rows:xbmcgui.Dialog().ok('Reminders','Select a programme, open Programme information, then choose a reminder.');return
    labels=[r['title']+(' (series on this channel)' if r['series'] else ' - '+time.strftime('%d %b %H:%M',time.localtime(r['start']))) for r in rows]
    selected=xbmcgui.Dialog().select('Select a reminder to remove',labels)
    if selected>=0:
        with guide.db:
            guide.db.execute('DELETE FROM reminders WHERE id=?',(rows[selected]['id'],))
            guide.db.execute('DELETE FROM reminder_sent WHERE reminder=?',(rows[selected]['id'],))

def add_reminder(guide,series):
    if not guide.selected or not guide.selected[1]:return
    p=guide.selected[1]
    if not series and p['start']<=time.time():xbmcgui.Dialog().ok('Reminder','Choose an upcoming programme.');return
    guide_data.add_reminder(guide.db,p,series)
    xbmcgui.Dialog().notification('Reminder saved','One minute before '+p['title'])

def collections(guide):
    dialog=xbmcgui.Dialog()
    rows=guide.db.execute('SELECT * FROM collections ORDER BY name').fetchall()
    choice=dialog.select('Custom channel collections',['Create collection']+[r['name'] for r in rows])
    if choice<0:return
    if choice==0:
        name=dialog.input('Collection name').strip()
        if not name:return
        ident='collection:'+uuid.uuid4().hex
        with guide.db:guide.db.execute('INSERT INTO collections VALUES (?,?)',(ident,name))
    else:
        ident=rows[choice-1]['id'];name=rows[choice-1]['name']
        action=dialog.select(name,['Choose channels','Rename','Delete collection'])
        if action<0:return
        if action==1:
            name=dialog.input('Collection name',name).strip()
            if name:
                with guide.db:guide.db.execute('UPDATE collections SET name=? WHERE id=?',(name,ident))
            guide.render();return
        if action==2:
            with guide.db:
                guide.db.execute('DELETE FROM collections WHERE id=?',(ident,))
                guide.db.execute('DELETE FROM collection_members WHERE collection=?',(ident,))
                guide.db.execute("DELETE FROM display_order WHERE kind='categories:live' AND item=?",(ident,))
                guide.db.execute("DELETE FROM hidden_categories WHERE mode='live' AND category=?",(ident,))
            guide.group='';guide.render();return
    channels=guide.db.execute('SELECT * FROM channels ORDER BY name').fetchall()
    members={r[0] for r in guide.db.execute('SELECT url FROM collection_members WHERE collection=?',(ident,))}
    selection=dialog.multiselect('Channels in '+name,[c['name'] for c in channels],preselect=[i for i,c in enumerate(channels) if c['url'] in members])
    if selection is not None:
        with guide.db:
            guide.db.execute('DELETE FROM collection_members WHERE collection=?',(ident,))
            guide.db.executemany('INSERT INTO collection_members VALUES (?,?)',[(ident,channels[i]['url']) for i in selection])
    guide.render()

def backup(guide,restore=False):
    dialog=xbmcgui.Dialog()
    if restore:
        path=dialog.browseSingle(1,'Choose OTB preferences backup','files','.json')
        if not path:return
        f=xbmcvfs.File(path)
        try:raw=f.read(8*1024*1024+1)
        finally:f.close()
        if len(raw)>8*1024*1024:raise ValueError('Backup is too large')
        data=json.loads(raw)
        if not dialog.yesno('Restore preferences','Replace saved collections and category preferences, and apply backed-up channel preferences to matching channels?'):return
        matched,skipped=guide_data.restore_preferences(guide.db,data)
        guide.group='';guide.offset=0;guide.render()
        dialog.ok('Preferences restored','%d channels matched; %d unmatched or ambiguous channels skipped.'%(matched,skipped))
    else:
        folder=dialog.browseSingle(0,'Choose backup folder','files')
        if not folder:return
        path=folder.rstrip('/\\')+'/OTB-preferences-'+time.strftime('%Y%m%d-%H%M%S')+'.json'
        f=xbmcvfs.File(path,'w')
        try:success=f.write(json.dumps(guide_data.export_preferences(guide.db),ensure_ascii=False,indent=2))
        finally:f.close()
        if not success:raise ValueError('Could not write backup')
        dialog.ok('Preferences backed up',path+'\nAccount credentials and stream URLs are excluded.')
