# OTB TV Guide 2.7.4

Playback-control correction: ported the guarded On-Tapp change.py overlay entry point to Python 3, with its copyright/GPL notices retained. The session keymap calls the standalone overlay from Kodi fullscreen playback. Keymap installation and removal now use Action(reloadkeymaps), correcting the invalid standalone command in previous builds. Covers keyboard, remote and joystick Up.

Fully exit the old guide before installing, then reopen OTB. Select a live channel, wait for playback, and press Up. Back closes the mini-guide; Back from fullscreen returns to the guide preview.

Install the ZIP through Kodi > Add-ons > Install from zip file. Keep your working OTB video addon configured. Restart Kodi after updating so the reminder service is running.

Changes in 2.7.3:

- Reworked the fullscreen Up shortcut: it now signals the running guide rather than starting a second script. Added FullscreenLiveTV and modern joystick mappings alongside keyboard/remote support. The request is handled even when the timeline is showing earlier/later programmes. Close the old guide before updating, then reopen it to load the revised session binding. This revision has automated checks but has not been tested on the affected device.

Previous playback changes:

- Selecting a live channel starts fullscreen playback. Back returns to the still-open guide with the stream continuing in its picture-in-picture panel. Selecting the same playing channel opens fullscreen again without restarting it. Full guide exit still stops the stream.

Previous changes:

- Press Up during fullscreen video in an open OTB guide session to open the mini-guide. This temporarily maps fullscreen keyboard/remote/gamepad Up and restores the previous mappings on normal guide exit. Other keymap files are not changed. If Kodi is forcibly terminated, reopen and normally exit the guide to clear a leftover session binding.
- Apps > Add your own shortcut chooses an installed Android app or accepts its package name, then lets you name the shortcut. Manage custom shortcuts renames/removes them. Apps must be installed to launch; manually entering a package does not install it.
- Removed More to discover from Movies and TV Shows.
- At the left/right edge of a programme row, another Left/Right pages the timeline by four hours. Earlier/Later programme options also move four hours. Arrow presses within a row continue selecting adjacent cells. Jump to now resumes automatic current-time tracking.

New features adapted from the interaction patterns reviewed in On-Tapp.EPG:

- Options > Search programmes: search imported programme titles, with past/live/upcoming labels, channel and date/time. Results are paged in groups of 100. Select a result for information, live playback, provider-eligible catch-up or reminders.
- Programme information > Remind me / Remind for this series: notifications one minute before the start, while Kodi is running. Series matches use the same exact programme title and XMLTV channel; they are not season-ID matching. Options > Programme reminders removes subscriptions. Notifications persist across Kodi restarts. A startup within five minutes of a programme's start can show its reminder if the programme is still running. No recording or automatic channel switching is enabled.
- Options > Custom collections: create, rename and delete your own Live TV categories; choose multiple channels for each. A channel can belong to several collections. Collections appear in the Live TV category bar and can be hidden/reordered like provider groups.
- Options > Back up preferences / Restore preferences: portable JSON containing channel numbering, order, visibility, favourites, collections and category preferences. Configure/import channels on the destination first. Restore matches exact guide ID and channel name, skips ambiguous/unmatched channels, and reports the count. It replaces collections/category preferences and updates matching channels. Stream URLs, passwords, source settings, Android app shortcuts and reminders are not exported. Movies/TV Shows category IDs need to match the provider on the destination.
- Options > Playback mini-guide: browse channels over the video panel, Left/Right to browse their programmes, OK to tune live, Back to dismiss without stopping playback. Also adds an OTB playback mini-guide entry to Kodi's main item context menu when video is playing; availability depends on where the skin exposes that menu. This is not a replacement for every skin's fullscreen playback controls.
- Ordering editor: swipe Left to pick up, swipe Up/Down to move, swipe Right to place. Remote ordering, visibility and Save/Cancel remain available. Page moves use ten rows in the editor; the main guide retains eight-channel paging.

Previous Android app shortcuts, landscape artwork matching, TMDB setting, guide auto-refresh, Apps centring and stop-on-full-guide-exit remain included. Android app launching and swipe gestures need device testing.

The features were reimplemented for our Python 3 / Kodi 21 architecture. Inspiration: On-Tapp.EPG 4.1.3; source headers credit On-Tapp-Networks Limited, Sean Poyser and Richard Dean and declare GPL v2 or later. Its old startup logic, provider integrations and Python 2 modules were not imported. OTB remains GPL-2.0-or-later; see LICENSE.txt.

TMDB: https://developer.themoviedb.org/docs/getting-started
This product uses the TMDB API but is not endorsed or certified by TMDB.
Optional TVmaze metadata: https://www.tvmaze.com/api (CC BY-SA).

Verification: 33 automated checks passed, including saved ordering, touch action handling, collections, programme search, reminder persistence/deduplication, backup restore rollback, custom Android shortcuts, four-hour timeline paging, keymap cleanup, artwork matching and playback/catch-up logic. Python 3.8 syntax and XML packaging are validated. The 2.7.0 mini-guide was exercised in local Windows Kodi over live video: next-programme browsing, channel browsing and return to the guide worked. The new 2.7.3 Up binding has automated coverage but has not been exercised in Kodi. Physical Android launching/swipes and a timed notification after a real Kodi restart remain unverified. No live test of the final 2.7.3 ZIP is claimed.
