"""Discover Android applications through Kodi's native VFS, then launch packages."""
import json
import os
import re
from urllib.parse import unquote
import xbmc
import xbmcgui
import xbmcvfs
from backend import ADDON, PROFILE

SERVICES=[('BBC iPlayer',('iplayer',)),('ITVX',('itvx','itv')),('Channel 4',('channel4','channel 4','all4','all 4')),('Netflix',('netflix',))]
DIRECTORY='androidapp://sources/apps/'

def package(path):
    value=unquote(path.rstrip('/').rsplit('/',1)[-1])
    return value if re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+',value) else ''

def installed():
    found={}
    # VFS avoids JSON-RPC's file-media extension filtering of package entries.
    try:
        dirs,files=xbmcvfs.listdir(DIRECTORY)
        for path in dirs+files:
            ident=package(path)
            if ident:found[ident]={'file':DIRECTORY+ident,'label':ident}
    except Exception:pass
    try:
        response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory','params':{'directory':DIRECTORY}})))
        for app in response.get('result',{}).get('files',[]):
            ident=package(app.get('file',''))
            if ident:found[ident]=app
    except Exception:pass
    return sorted(found.values(),key=lambda a:a.get('label','').casefold())

def launch(app):
    ident=package(app.get('file',''))
    if not ident:raise ValueError('Invalid Android app package')
    xbmc.Player().stop()
    xbmc.log('OTB Guide: launching Android package '+ident,xbmc.LOGINFO)
    xbmc.executebuiltin('StartAndroidActivity("'+ident+'")')

def custom_shortcuts():
    try:
        with open(os.path.join(PROFILE,'android-shortcuts.json'),encoding='utf-8') as f:rows=json.load(f)
        return [r for r in rows if isinstance(r,dict) and package(r.get('package','')) and isinstance(r.get('name'),str)] if isinstance(rows,list) else []
    except (OSError,ValueError):return []

def save_shortcuts(rows):
    path=os.path.join(PROFILE,'android-shortcuts.json')
    with open(path+'.tmp','w',encoding='utf-8') as f:json.dump(rows,f)
    os.replace(path+'.tmp',path)

def menu():
    dialog=xbmcgui.Dialog()
    if not xbmc.getCondVisibility('System.Platform.Android'):
        dialog.ok('Apps','Streaming apps can be opened when this guide runs on Android.');return
    apps=installed();custom=custom_shortcuts()
    labels=[s[0] for s in SERVICES]+[r['name'] for r in custom]
    base=len(labels)
    selected=dialog.select('Streaming apps',labels+['Add your own shortcut','Manage custom shortcuts','All installed apps','Assign an app to a built-in shortcut'])
    if selected<0:return
    if 4<=selected<base:
        launch({'file':custom[selected-4]['package']});return
    if selected==base:
        choice=dialog.select('Choose an app',[a.get('label') or package(a['file']) for a in apps]+['Enter Android package name'])
        if choice<0:return
        ident=package(apps[choice]['file']) if choice<len(apps) else package(dialog.input('Android package name, e.g. com.example.app').strip())
        if not ident:dialog.ok('Shortcut','A valid Android package name is required.');return
        name=dialog.input('Shortcut name',apps[choice].get('label',ident) if choice<len(apps) else ident).strip()
        if name:
            custom.append({'name':name,'package':ident});save_shortcuts(custom)
        return
    if selected==base+1:
        choice=dialog.select('Custom shortcuts',[r['name'] for r in custom])
        if choice<0:return
        action=dialog.select(custom[choice]['name'],['Rename','Remove shortcut'])
        if action==0:
            name=dialog.input('Shortcut name',custom[choice]['name']).strip()
            if name:custom[choice]['name']=name;save_shortcuts(custom)
        elif action==1:custom.pop(choice);save_shortcuts(custom)
        return
    if selected in (base+2,base+3):
        slot=dialog.select('Choose shortcut',[s[0] for s in SERVICES]) if selected==base+3 else -1
        if selected==base+3 and slot<0:return
        if not apps:
            dialog.ok('Apps','Kodi could not list apps. Opening its Android applications browser.');xbmc.executebuiltin('ActivateWindow(programs,androidapp://sources/apps/,return)');return
        choice=dialog.select('Installed apps',[a.get('label') or package(a['file']) for a in apps])
        if choice<0:return
        if selected==base+3:ADDON.setSetting('android.shortcut.'+str(slot),package(apps[choice]['file']))
        else:launch(apps[choice])
        return
    saved=ADDON.getSetting('android.shortcut.'+str(selected))
    matches=[a for a in apps if package(a['file'])==saved] if saved else [a for a in apps if any(t in (a.get('label','')+' '+a['file']).casefold() for t in SERVICES[selected][1])]
    if not matches:
        dialog.ok(SERVICES[selected][0],'No matching app was found. Use Add your own shortcut or Assign an app to a built-in shortcut to select your installed version.');return
    choice=dialog.select('Choose installed version',[a.get('label','') for a in matches]) if len(matches)>1 else 0
    if choice>=0:launch(matches[choice])
