"""Browse live channels and their schedules over ongoing video."""
import time
import xbmc
import xbmcgui

class MiniGuide(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.db=None;self.channels=[];self.shift=0;self.programme=None
    def onInit(self):
        self.channels=self.db.execute('''SELECT c.* FROM channels c
          WHERE NOT EXISTS(SELECT 1 FROM hidden h WHERE h.url=c.url)
          AND NOT EXISTS(SELECT 1 FROM hidden_categories h WHERE h.mode='live' AND h.category=c.grp)
          ORDER BY COALESCE((SELECT position FROM display_order WHERE kind='channels' AND item=c.url),2147483647),c.rowid''').fetchall()
        self.getControl(6000).addItems([xbmcgui.ListItem(c['name']) for c in self.channels])
        if not self.channels:self.close();return
        self.setFocusId(6000);self.update()
    def update(self):
        if not self.channels:return
        c=self.channels[self.getControl(6000).getSelectedPosition()]
        now=int(time.time())
        if self.shift>=0:
            rows=self.db.execute('SELECT * FROM programmes WHERE epg=? AND stop>? ORDER BY start LIMIT 1 OFFSET ?',(c['epg'],now,self.shift)).fetchall()
        else:
            rows=self.db.execute('SELECT * FROM programmes WHERE epg=? AND stop<=? ORDER BY start DESC LIMIT 1 OFFSET ?',(c['epg'],now,-self.shift-1)).fetchall()
        self.programme=rows[0] if rows else None
        p=self.programme
        self.getControl(10).setLabel(p['title'] if p else 'No programme data')
        self.getControl(11).setText((time.strftime('%a %H:%M',time.localtime(p['start']))+' - '+time.strftime('%H:%M',time.localtime(p['stop']))+'\n'+p['description']) if p else '')
    def onFocus(self,ident):
        if ident==6000:self.update()
    def onAction(self,action):
        ident=action.getId()
        if ident in (9,10,92):self.close()
        elif ident in (1,2):
            previous=self.shift;self.shift+=-1 if ident==1 else 1;self.update()
            if self.programme is None:self.shift=previous;self.update()
        elif ident in (3,4,5,6):self.shift=0;self.update()
    def onClick(self,ident):
        if ident!=6000 or not self.channels:return
        c=self.channels[self.getControl(6000).getSelectedPosition()]
        # Selecting always tunes live; browsing dates never triggers catch-up.
        item=xbmcgui.ListItem(label=c['name'],path=c['url'])
        item.getVideoInfoTag().setTitle(c['name'])
        xbmc.Player().play(c['url'],item,windowed=False)
        self.close()

def show(root,db):
    window=MiniGuide('mini.xml',root,'Default','720p');window.db=db
    window.doModal();del window
